package uo.ri.ui.util;

import java.util.List;

import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;
import uo.ri.cws.application.service.vehicle.VehicleCrudService.VehicleDto;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;
import uo.ri.util.console.Console;

public class Printer {

	public static void printWorkOrderDetail(WorkOrderDto wo) {

		Console.printf("%s for vehicle %s\n\t%-25.25s\n\t%tm/%<td/%<tY\n\t%s\n",
				wo.id
				, wo.vehicleId
				, wo.description
				, wo.date
				, wo.state
			);
	}

	public static void printVehicleDetail(VehicleDto v) {

		Console.printf("%s\t%-8.8s\t%s\t%s\n",
				v.id
				, v.plate
				, v.make
				, v.model
			);
	}

	public static void printWorkOrdersDetail(List<WorkOrderDto> findAllWO) {
		for(WorkOrderDto dto : findAllWO) {
			printWorkOrderDetail(dto);
		}
	}

	public static void printMechanics(List<MechanicDto> dtos) {
		for(MechanicDto dto : dtos) {
			printMechanic(dto);
		}
	}

	public static void printMechanic(MechanicDto dto) {
		Console.printf("dni: "+dto.dni+" name: "+dto.name+" surname: "+dto.surname);

		
	}

	public static void printClients(List<ClientDto> findAllClients) {
		for(ClientDto dto : findAllClients) {
			printClient(dto);
		}
	}
	public static void printClient(ClientDto arg) {

		Console.printf("\t%s \t%s \t%s \t%s \t%s \t%s \t%s \\%s\n",  
				arg.dni
				, arg.name
				, arg.surname
				, arg.phone
				, arg.email
				, arg.addressCity
				, arg.addressStreet
				, arg.addressZipcode
			);	
		
	}

	public static void printVehiclesDetail(List<VehicleDto> findAll) {
		for(VehicleDto dto: findAll) {
			printVehicleDetail(dto);
		}
	}
}
