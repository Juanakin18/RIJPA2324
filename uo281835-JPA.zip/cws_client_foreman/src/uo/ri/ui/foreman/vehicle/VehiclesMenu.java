package uo.ri.ui.foreman.vehicle;

import uo.ri.ui.foreman.vehicle.actions.DisableVehicleAction;
import uo.ri.ui.foreman.vehicle.actions.ListAllVehicleAction;
import uo.ri.ui.foreman.vehicle.actions.RegisterNewVehicleAction;
import uo.ri.ui.foreman.vehicle.actions.UpdateVehicleAction;
import uo.ri.util.menu.BaseMenu;

public class VehiclesMenu extends BaseMenu {

	public VehiclesMenu() {
		menuOptions = new Object[][] { 
			{ "Foreman > Vehicle management", null },

			{ "Register new vehicle", 	RegisterNewVehicleAction.class }, 
			{ "Update vehicle", 		UpdateVehicleAction.class }, 
			{ "Disable vehicle", 		DisableVehicleAction.class }, 
			{ "List all vehicles", 		ListAllVehicleAction.class }, 
		};
	}

}
