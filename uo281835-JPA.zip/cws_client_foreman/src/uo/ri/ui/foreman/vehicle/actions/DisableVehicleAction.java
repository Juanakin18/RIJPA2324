package uo.ri.ui.foreman.vehicle.actions;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.vehicle.VehicleCrudService;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class DisableVehicleAction implements Action {

	@Override
	public void execute() throws Exception {
		String plate = Console.readString("Introduzca la matrícula");
		VehicleCrudService vts = Factory.service.forVehicleCrudService();
		vts.removeVehicle(plate);
		Console.println("Se ha borrado");
		
	}

}
