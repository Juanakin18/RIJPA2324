package uo.ri.ui.foreman.vehicle.actions;

import uo.ri.conf.Factory;
import uo.ri.ui.util.Printer;
import uo.ri.util.menu.Action;

public class ListAllVehicleAction implements Action {

	@Override
	public void execute() throws Exception {
		Printer.printVehiclesDetail(Factory.service.forVehicleCrudService().findAll());
	}

}
