package uo.ri.ui.foreman.vehicle.actions;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.client.ClientCrudService;
import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.cws.application.service.vehicle.VehicleCrudService.VehicleDto;
import uo.ri.cws.application.service.vehicletype.VehicleTypeCrudService;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class RegisterNewVehicleAction implements Action {

	@Override
	public void execute() throws Exception {
		String plate = Console.readString("Introduzca la matrícula");
		String make = Console.readString("Introduzca la marca");
		String model = Console.readString("Introduzca el modelo");
		String tipo = Console.readString("Introduzca el tipo de vehículo");
		String propietario = Console.readString("Introduzca el dni del propietario");
		
		VehicleTypeCrudService vts = Factory.service.forVehicleTypeCrudService();
		ClientCrudService cs = Factory.service.forClienteCrudService();
		Optional<ClientDto> cdto = cs.findClientByDNI(propietario);
		
		if(!vts.findById(tipo).isEmpty()) {
			if(cdto.isPresent()) {
				VehicleDto dto = new VehicleDto();
				
				dto.plate = plate;
				dto.make = make;
				dto.model = model;
				dto.vehicleTypeId = tipo;
				dto.clientId = cdto.get().id;
				
				Factory.service.forVehicleCrudService().addVehicle(dto);
				Console.println("Se ha añadido el vehículo");
			}
			
		}
		
		
	}

}
