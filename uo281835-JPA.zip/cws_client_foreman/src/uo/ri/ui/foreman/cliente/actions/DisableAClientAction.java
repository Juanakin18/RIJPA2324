package uo.ri.ui.foreman.cliente.actions;

import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.client.ClientCrudService;
import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.cws.application.service.vehicle.VehicleCrudService;
import uo.ri.cws.application.service.vehicle.VehicleCrudService.VehicleDto;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class DisableAClientAction implements Action {

	@Override
	public void execute() throws Exception {
		String dni = Console.readString("Introduzca el dni");
		
		ClientCrudService service = Factory.service.forClienteCrudService();
		VehicleCrudService vservice = Factory.service.forVehicleCrudService();
		WorkOrderCrudService wservice = Factory.service.forWorkOrderCrudService();
		
		Optional<ClientDto> dto1 = service.findClientByDNI(dni);
		
		if(dto1.isPresent()) {
			List<VehicleDto> dtos =vservice.findVehicleByDni(dni);
			boolean hasWorkOrders = false;
			for(VehicleDto vehicle : dtos) {
				if(wservice.findWorkordersByVehicle(vehicle.plate).size()>0) {
					hasWorkOrders = true;
					break;
				}
			}
			if(!hasWorkOrders) {
				service.deleteClient(dni);
				Console.println("Se ha borrado el cliente");
			}else {
				Console.println("No se puede borrar el cliente: tiene WorkOrders");
			}
			
		
		}else {
			Console.println("Este cliente no existe");
		}
	}

}
