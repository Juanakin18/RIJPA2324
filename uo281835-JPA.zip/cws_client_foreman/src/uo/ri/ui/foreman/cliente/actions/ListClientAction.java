package uo.ri.ui.foreman.cliente.actions;

import uo.ri.conf.Factory;
import uo.ri.ui.util.Printer;
import uo.ri.util.menu.Action;

public class ListClientAction implements Action {

	@Override
	public void execute() throws Exception {
		Printer.printClients(Factory.service.forClienteCrudService().findAllClients());

	}

}
