package uo.ri.ui.foreman.cliente;

import uo.ri.ui.foreman.cliente.actions.DisableAClientAction;
import uo.ri.ui.foreman.cliente.actions.ListClientAction;
import uo.ri.ui.foreman.cliente.actions.RegisterClientAction;
import uo.ri.ui.foreman.cliente.actions.UpdateClientAction;
import uo.ri.util.menu.BaseMenu;

public class ClientsMenu extends BaseMenu {

	public ClientsMenu() {
		menuOptions = new Object[][] { { "Foreman > Client management", null },

				{ "Register a client", RegisterClientAction.class },
				{ "Update a client", UpdateClientAction.class },
				{ "Disable a client", DisableAClientAction.class },
				{ "List all clients", ListClientAction.class }, };
	}

}
