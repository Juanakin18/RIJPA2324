package uo.ri.ui.foreman.cliente.actions;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.client.ClientCrudService;
import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class UpdateClientAction implements Action {

	@Override
	public void execute() throws Exception {
		String dni = Console.readString("Introduzca el dni");
		String name = Console.readString("Introduzca el nombre");
		String surname = Console.readString("Introduzca el apellido");
		String email = Console.readString("Introduzca el email");
		String phone = Console.readString("Introduzca el telefono");
		String ciudad = Console.readString("Introduzca la ciudad");
		String calle = Console.readString("Introduzca la calle");
		String cp = Console.readString("Introduzca el cp");
		
		ClientCrudService service = Factory.service.forClienteCrudService();
		
		Optional<ClientDto> dto1 = service.findClientByDNI(dni);
		
		if(dto1.isPresent()) {
			ClientDto dto = dto1.get();
			dto.dni = dni;
			dto.name = name;
			dto.surname = surname;
			dto.email = email;
			dto.phone = phone;
			dto.addressCity = ciudad;
			dto.addressStreet = calle;
			dto.addressZipcode = cp;

		service.updateClient(dto);
		Console.println("Se ha actualizado el cliente");
		}else {
			Console.println("Este cliente no existe");
		}
		
	}

}
