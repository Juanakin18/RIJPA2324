/**
 * 
 */
package uo.ri.ui.foreman.reception.actions;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

/**
 * @author juani
 *
 */
public class UpdateWorkOrderAction implements Action {

	@Override
	public void execute() throws Exception {
		String plateNumber = Console.readString("plate number");
		String description = Console.readString("Description");
		String state = Console.readString("State");
		WorkOrderDto dto = new WorkOrderDto();
		dto.vehicleId = Factory.service.forVehicleCrudService().findVehicleByPlate(plateNumber).get().id;
		dto.description = description;
		dto.state = state;
		Factory.service.forWorkOrderCrudService().updateWorkOrder(dto);
	}

}
