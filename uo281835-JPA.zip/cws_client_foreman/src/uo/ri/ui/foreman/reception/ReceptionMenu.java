package uo.ri.ui.foreman.reception;

import uo.ri.ui.foreman.reception.actions.AssignWorkOrderAction;
import uo.ri.ui.foreman.reception.actions.ListCertifiedMechanicsAction;
import uo.ri.ui.foreman.reception.actions.ListWorkOrdersAction;
import uo.ri.ui.foreman.reception.actions.RegisterWorkOrderAction;
import uo.ri.ui.foreman.reception.actions.RemoveWorkOrderAction;
import uo.ri.ui.foreman.reception.actions.UpdateWorkOrderAction;
import uo.ri.ui.foreman.reception.actions.ViewWorkOrderDetailAction;
import uo.ri.util.menu.BaseMenu;

public class ReceptionMenu extends BaseMenu {

	public ReceptionMenu() {
		menuOptions = new Object[][] { 
			{"Foreman > Vehicle reception", null},
			
			{"Register work order", 	RegisterWorkOrderAction.class }, 
			{"Update workorder", 		UpdateWorkOrderAction.class },
			{"Remove workorder", 		RemoveWorkOrderAction.class },
			{"", null},
			{"List work orders", 		ListWorkOrdersAction.class }, 
			{"View work order detail", 	ViewWorkOrderDetailAction.class },
			{"", null},
			{"List certified mechanics",ListCertifiedMechanicsAction.class }, 
			{"Assign a work order",  	AssignWorkOrderAction.class },
		};
	}

}
