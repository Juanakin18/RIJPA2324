package uo.ri.ui.foreman.reception.actions;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class RegisterWorkOrderAction implements Action {

	@Override
	public void execute() throws Exception {
		String plateNumber = Console.readString("plate number");
		String description = Console.readString("Description");
		
		WorkOrderDto dto = new WorkOrderDto();
		dto.vehicleId = Factory.service.forVehicleCrudService().findVehicleByPlate(plateNumber).get().id;
		dto.description = description;
		dto.state = "Open";
		Factory.service.forWorkOrderCrudService().addWorkOrder(dto);
		
	}

}
