package uo.ri.ui.foreman.reception.actions;

import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;
import uo.ri.ui.util.Printer;
import uo.ri.util.menu.Action;

public class ListCertifiedMechanicsAction implements Action {

	@Override
	public void execute() throws Exception {
		List<MechanicDto> dtos = Factory.service.forMechanicCrudService().findAllMechanics();
		Printer.printMechanics(dtos);
	}

}
