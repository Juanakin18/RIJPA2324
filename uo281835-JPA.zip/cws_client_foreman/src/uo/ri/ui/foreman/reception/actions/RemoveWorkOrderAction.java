/**
 * 
 */
package uo.ri.ui.foreman.reception.actions;

import uo.ri.conf.Factory;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

/**
 * @author juani
 *
 */
public class RemoveWorkOrderAction implements Action {

	@Override
	public void execute() throws Exception {
		String plateNumber = Console.readString("plate number");
		Factory.service.forWorkOrderCrudService().deleteWorkOrder(plateNumber);
	
	}

}
