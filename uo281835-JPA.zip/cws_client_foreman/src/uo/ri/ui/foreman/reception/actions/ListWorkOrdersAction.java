package uo.ri.ui.foreman.reception.actions;

import uo.ri.conf.Factory;
import uo.ri.ui.util.Printer;
import uo.ri.util.menu.Action;

public class ListWorkOrdersAction implements Action {

	@Override
	public void execute() throws Exception {
		Printer.printWorkOrdersDetail(Factory.service.forWorkOrderCrudService().findAllWO());
	}

}
