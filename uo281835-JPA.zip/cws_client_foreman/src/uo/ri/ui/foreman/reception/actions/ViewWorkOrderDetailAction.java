/**
 * 
 */
package uo.ri.ui.foreman.reception.actions;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;
import uo.ri.ui.util.Printer;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

/**
 * @author juani
 *
 */
public class ViewWorkOrderDetailAction implements Action {

	@Override
	public void execute() throws Exception {
		String id = Console.readString("Introduzca el identificador");
		Optional<WorkOrderDto> dto = Factory.service.forWorkOrderCrudService().findWorkorderByID(id);
		if(dto.isPresent()) {
			Printer.printWorkOrderDetail(dto.get());
		}
		
		

	}

}
