/**
 * 
 */
package uo.ri.ui.foreman.reception.actions;

import java.time.LocalDateTime;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

/**
 * @author juani
 *
 */
public class AssignWorkOrderAction implements Action {

	@Override
	public void execute() throws Exception {
		String plateNumber = Console.readString("plate number");
		LocalDateTime date = Console.readDate("date").atStartOfDay();
		String dni = Console.readString("mechanic dni");
		
		WorkOrderCrudService wservice = Factory.service.forWorkOrderCrudService();
	
		WorkOrderDto dto = wservice.findWorkorderByDateAndVehicle(plateNumber, date).get();
		dto.mechanicId = dni;
		wservice.updateWorkOrder(dto);
		
	}

}
