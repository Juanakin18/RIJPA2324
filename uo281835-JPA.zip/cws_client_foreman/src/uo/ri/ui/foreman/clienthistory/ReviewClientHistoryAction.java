package uo.ri.ui.foreman.clienthistory;

import uo.ri.ui.foreman.clienthistory.actions.ListClientHistoryAction;
import uo.ri.ui.foreman.clienthistory.actions.SearchClientAction;
import uo.ri.util.menu.BaseMenu;

public class ReviewClientHistoryAction extends BaseMenu {

	public ReviewClientHistoryAction() {
		menuOptions = new Object[][] { { "Foreman > Client history", null },

				{ "List a clients history", ListClientHistoryAction.class },
				{ "Search a client", SearchClientAction.class }
				};
		
	}
}
