package uo.ri.ui.foreman.clienthistory.actions;

import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.client.ClientCrudService;
import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.cws.application.service.vehicle.VehicleCrudService;
import uo.ri.cws.application.service.vehicle.VehicleCrudService.VehicleDto;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;
import uo.ri.ui.util.Printer;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class ListClientHistoryAction implements Action{

	@Override
	public void execute() throws Exception {
		
		ClientCrudService service = Factory.service.forClienteCrudService();
		VehicleCrudService vservice = Factory.service.forVehicleCrudService();
		WorkOrderCrudService wservice = Factory.service.forWorkOrderCrudService();
		List<ClientDto> dtos1 =(service.findAllClients());
		
		for(ClientDto dto: dtos1) {
			Console.println("Cliente");
			Printer.printClient(dto);
			List<VehicleDto> dtos =vservice.findVehicleByDni(dto.dni);
			Console.println("Vehículos del cliente");
			for(VehicleDto vehicle : dtos) {
				Printer.printVehicleDetail(vehicle);
				List<WorkOrderDto> workorders = wservice.findWorkordersByVehicle(vehicle.plate);
				Console.println("Workorders del vehículo");
				Printer.printWorkOrdersDetail(workorders);
			}
			
		}
		
	}

}
