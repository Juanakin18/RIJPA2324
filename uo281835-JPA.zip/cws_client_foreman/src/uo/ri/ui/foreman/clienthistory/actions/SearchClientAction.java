package uo.ri.ui.foreman.clienthistory.actions;

import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.client.ClientCrudService;
import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.ui.util.Printer;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class SearchClientAction implements Action {

	@Override
	public void execute() throws Exception {
		

		if(Console.readString("¿Quiere buscar por nombre?").equalsIgnoreCase("Si")) {
			String nombre = Console.readString("Introduzca el nombre");
			buscarPorNombre(nombre);
		}else if(Console.readString("¿Quiere buscar por apellido?").equalsIgnoreCase("Si")) {
			String nombre = Console.readString("Introduzca el apellido");
			buscarPorApellido(nombre);
		}else if(Console.readString("¿Quiere buscar por dni?").equalsIgnoreCase("Si")) {
			String nombre = Console.readString("Introduzca el dni");
			buscarPorDni(nombre);
		}else if(Console.readString("¿Quiere buscar por vehículo?").equalsIgnoreCase("Si")) {
			String nombre = Console.readString("Introduzca la matrícula");
			buscarPorVehiculo(nombre);
		}
		
	}

	private void buscarPorVehiculo(String nombre) throws Exception{
		ClientCrudService service = Factory.service.forClienteCrudService();
		Optional<ClientDto> dtos1 =(service.findClientsByPlate(nombre));
		if(dtos1.isPresent())
			Printer.printClient(dtos1.get());
		else
			Console.println("Este cliente no existe");
	}

	private void buscarPorDni(String nombre) throws Exception{
		ClientCrudService service = Factory.service.forClienteCrudService();
		Optional<ClientDto> dtos1 =(service.findClientByDNI(nombre));
		if(dtos1.isPresent())
			Printer.printClient(dtos1.get());
		else
			Console.println("Este cliente no existe");
	}

	private void buscarPorApellido(String nombre) throws Exception{
		ClientCrudService service = Factory.service.forClienteCrudService();
		List<ClientDto> dtos1 =(service.findClientsBySurname(nombre));
		Printer.printClients(dtos1);

	}

	private void buscarPorNombre(String nombre)throws Exception {
		ClientCrudService service = Factory.service.forClienteCrudService();
		List<ClientDto> dtos1 =(service.findClientsByName(nombre));
		Printer.printClients(dtos1);
	}

}
