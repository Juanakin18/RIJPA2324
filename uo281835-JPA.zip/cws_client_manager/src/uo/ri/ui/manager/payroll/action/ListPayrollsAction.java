package uo.ri.ui.manager.payroll.action;

import java.util.List;
import uo.ri.conf.Factory;
import uo.ri.util.menu.Action;
import uo.ri.cws.application.service.payroll.PayrollService.PayrollSummaryBLDto;
import uo.ri.ui.util.Printer;

public class ListPayrollsAction implements Action {

	@Override
	public void execute() throws Exception {
		List<PayrollSummaryBLDto> payrolls = Factory.service	.forPayrollService()
															.getAllPayrolls();
		for (PayrollSummaryBLDto dto : payrolls) {
			Printer.printPayroll(dto);
		}
	}

}
