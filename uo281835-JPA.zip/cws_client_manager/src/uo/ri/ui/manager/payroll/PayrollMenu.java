package uo.ri.ui.manager.payroll;

import uo.ri.ui.manager.payroll.action.DeleteLastPayrollAction;
import uo.ri.ui.manager.payroll.action.DeleteMechanicPayrollAction;
import uo.ri.ui.manager.payroll.action.GeneratePayrollAction;
import uo.ri.ui.manager.payroll.action.ListAPayrollAction;
import uo.ri.ui.manager.payroll.action.ListAllGroupPayrollAction;
import uo.ri.ui.manager.payroll.action.ListAllMechanicPayrollAction;
import uo.ri.ui.manager.payroll.action.ListPayrollsAction;
import uo.ri.util.menu.BaseMenu;

public class PayrollMenu extends BaseMenu {

	public PayrollMenu() {
		menuOptions = new Object[][] { { "Manager > Payroll management", null },

				{ "Generate payrolls", GeneratePayrollAction.class },
				{ "Delete payrolls for mechanic",
						DeleteMechanicPayrollAction.class },
				{ "Delete payrolls for month", DeleteLastPayrollAction.class },
				{ "Show all payrolls", ListPayrollsAction.class },
				{ "Show a payroll", ListAPayrollAction.class },
				{ "Show all payrolls by mechanic",
						ListAllMechanicPayrollAction.class },
				{ "Show all payrolls by professional group",
						ListAllGroupPayrollAction.class },

		};
	}
}
