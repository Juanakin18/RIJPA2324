package uo.ri.ui.manager.payroll.action;

import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;
import uo.ri.cws.application.service.payroll.PayrollService.PayrollSummaryBLDto;
import uo.ri.ui.util.Printer;

public class ListAllGroupPayrollAction implements Action {

	@Override
	public void execute() throws Exception {
		String grupo = Console.readString(
				"Introduzca el nombre del grupo profesional");
		List<PayrollSummaryBLDto> dtos = Factory.service	.forPayrollService()
														.getAllPayrollsForProfessionalGroup(
																grupo);
		for (PayrollSummaryBLDto dto : dtos) {
			Printer.printPayroll(dto);
		}

	}

}
