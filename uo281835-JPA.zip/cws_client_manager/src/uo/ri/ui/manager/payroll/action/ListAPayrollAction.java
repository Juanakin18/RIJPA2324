package uo.ri.ui.manager.payroll.action;

import uo.ri.conf.Factory;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;
import uo.ri.cws.application.service.payroll.PayrollService.PayrollBLDto;
import uo.ri.ui.util.Printer;

public class ListAPayrollAction implements Action {

	@Override
	public void execute() throws Exception {
		String id = Console.readString("Introduzca el identificador");
		PayrollBLDto d = Factory.service	.forPayrollService()
										.getPayrollDetails(id)
										.get();
		Printer.printPayroll(d);

	}

}
