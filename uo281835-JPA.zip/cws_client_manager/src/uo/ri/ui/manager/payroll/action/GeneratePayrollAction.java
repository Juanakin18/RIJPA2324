package uo.ri.ui.manager.payroll.action;

import uo.ri.conf.Factory;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;
public class GeneratePayrollAction implements Action {

	@Override
	public void execute() throws Exception {
		Factory.service.forPayrollService().generatePayrolls();
		Console.println("Se han generado las payrolls");

	}

}
