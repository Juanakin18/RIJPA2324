package uo.ri.ui.manager.payroll.action;
import uo.ri.conf.Factory;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class DeleteMechanicPayrollAction implements Action {

	@Override
	public void execute() throws Exception {
		String dni = Console.readString("Introduzca el dni del empleado");
		Factory.service.forPayrollService().deleteLastPayrollFor(dni);
		Console.println("Se han borrado");
	}

}
