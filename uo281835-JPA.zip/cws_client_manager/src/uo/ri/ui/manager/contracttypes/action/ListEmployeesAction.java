package uo.ri.ui.manager.contracttypes.action;

import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.contract.ContractService.ContractSummaryDto;
import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class ListEmployeesAction implements Action {

	@Override
	public void execute() throws Exception {
		String nombre = Console.readString("Introduzca el nombre");
		List<MechanicDto> dtos = Factory.service.forMechanicCrudService()
												.findMechanicsWithContractInForceInContractType(
														nombre);
		double accumulate = 0;
		for (MechanicDto dto : dtos) {
			Console.println(dto);
			List<ContractSummaryDto> lista = Factory.service.forContractService()
															.findContractsByMechanicDni(
																	dto.dni);
			for (ContractSummaryDto contract : lista) {
				accumulate += contract.settlement;
			}
		}
		Console.println("En total el settlement es: " + accumulate);

	}

}
