package uo.ri.ui.manager.contracttypes.action;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.contracttype.ContractTypeService.ContractTypeDto;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class AddContractTypeAction implements Action {

	@Override
	public void execute() throws Exception {
		String nombre = Console.readString("Introduzca el nombre");
		double compensacion = Console.readDouble("Introduzca la compensaci�n");
		ContractTypeDto dto = new ContractTypeDto();
		dto.name = nombre;
		dto.compensationDays = compensacion;
		Factory.service.forContractTypeService().addContractType(dto);
		Console.println("Se ha a�adido el tipo de contrato");

	}

}
