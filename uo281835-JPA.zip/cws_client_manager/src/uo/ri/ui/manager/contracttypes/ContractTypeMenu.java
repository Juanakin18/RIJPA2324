package uo.ri.ui.manager.contracttypes;

import uo.ri.ui.manager.contracttypes.action.AddContractTypeAction;
import uo.ri.ui.manager.contracttypes.action.DeleteContractTypeAction;
import uo.ri.ui.manager.contracttypes.action.ListEmployeesAction;
import uo.ri.ui.manager.contracttypes.action.UpdateContractTypeAction;
import uo.ri.util.menu.BaseMenu;

public class ContractTypeMenu extends BaseMenu {

	public ContractTypeMenu() {
		menuOptions = new Object[][] {
				{ "Manager > ContractType management", null },

				{ "Add contract type", AddContractTypeAction.class },
				{ "List employees with contract in force for contract type",
						ListEmployeesAction.class },
				{ "Remove contract type mechanic",
						DeleteContractTypeAction.class },
				{ "Update contract type", UpdateContractTypeAction.class }

		};
	}
}
