package uo.ri.ui.manager.contracttypes.action;

import uo.ri.conf.Factory;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class DeleteContractTypeAction implements Action {

	@Override
	public void execute() throws Exception {
		String nombre = Console.readString("Introduzca el nombre");
		Factory.service.forContractTypeService().deleteContractType(nombre);
		Console.println("Se ha borrado el tipo de contrato");
	}

}
