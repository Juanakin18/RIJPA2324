package uo.ri.ui.manager.sparepart.action;


import uo.ri.conf.Factory;
import uo.ri.cws.application.service.sparepart.SparePartCrudService;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;
public class RemoveSparePartsAction implements Action {

	@Override
	public void execute() throws Exception {
		// Get info
		String dni = Console.readString("code"); 
		
	//	MechanicService service = new MechanicServiceImpl();
		SparePartCrudService service = Factory.service.forSparePartCrudService();
		service.deleteSparePart(dni);
		// Print result
		Console.println("SparePart removed");

	}

}
