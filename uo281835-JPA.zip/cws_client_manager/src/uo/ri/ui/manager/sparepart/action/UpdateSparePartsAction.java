package uo.ri.ui.manager.sparepart.action;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.sparepart.SparePartCrudService;
import uo.ri.cws.application.service.sparepart.SparePartDto;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class UpdateSparePartsAction implements Action {

	@Override
	public void execute() throws Exception {
		// Get info
		String dni = Console.readString("code"); 
		String name = Console.readString("description"); 
		double surname = Console.readDouble("price");
		
		SparePartDto dto = new SparePartDto();
		dto.code=dni;
		dto.description=name;
		dto.price=surname;
		
	//	MechanicService service = new MechanicServiceImpl();
		SparePartCrudService service = Factory.service.forSparePartCrudService();
		service.updateSparePart(dto);
		// Print result
		Console.println("SparePart updated");

	}

}
