package uo.ri.ui.manager.sparepart.action;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.sparepart.SparePartCrudService;
import uo.ri.ui.util.Printer;
import uo.ri.util.menu.Action;

public class ListAllSparePartAction implements Action {

	@Override
	public void execute() throws Exception {
		SparePartCrudService service = Factory.service.forSparePartCrudService();
		Printer.printSpareParts(service.findAll());
	}

}
