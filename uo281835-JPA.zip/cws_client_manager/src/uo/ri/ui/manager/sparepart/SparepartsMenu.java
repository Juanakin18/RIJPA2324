package uo.ri.ui.manager.sparepart;


import uo.ri.ui.manager.sparepart.action.AddSparePartsAction;
import uo.ri.ui.manager.sparepart.action.ListAllSparePartAction;
import uo.ri.ui.manager.sparepart.action.RemoveSparePartsAction;
import uo.ri.ui.manager.sparepart.action.UpdateSparePartsAction;
import uo.ri.util.menu.BaseMenu;

public class SparepartsMenu extends BaseMenu {

	public SparepartsMenu() {
		menuOptions = new Object[][] { 
			{"Manager > Parts management", null},
			
			{ "Add", 		AddSparePartsAction.class }, 
			{ "Update", 	UpdateSparePartsAction.class }, 
			{ "Remove", 	RemoveSparePartsAction.class }, 
			{ "List all", 	ListAllSparePartAction.class },
		};
	}

}
