package uo.ri.ui.manager.vehicletype;

import uo.ri.ui.manager.vehicletype.action.AddVehicleTypeAction;
import uo.ri.ui.manager.vehicletype.action.DeleteVehicleTypeAction;
import uo.ri.ui.manager.vehicletype.action.ListAllVehicleTypesAction;
import uo.ri.ui.manager.vehicletype.action.UpdateVehicleTypeAction;
import uo.ri.util.menu.BaseMenu;

public class VehicleTypesMenu extends BaseMenu {

	public VehicleTypesMenu() {
		menuOptions = new Object[][] { 
			{"Manager > Vehicle types management", null},
			
			{ "Add vehicle type", 	AddVehicleTypeAction.class }, 
			{ "Update", 			UpdateVehicleTypeAction.class }, 
			{ "Delete", 			DeleteVehicleTypeAction.class }, 
			{ "List all",			ListAllVehicleTypesAction.class },
		};
	}

}
