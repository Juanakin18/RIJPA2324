package uo.ri.ui.manager.vehicletype.action;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.vehicletype.VehicleTypeCrudService;
import uo.ri.cws.application.service.vehicletype.VehicleTypeCrudService.VehicleTypeDto;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;
public class UpdateVehicleTypeAction implements Action {

	@Override
	public void execute() throws Exception {
		// Get info
		String id = Console.readString("id");
				String dni = Console.readString("name"); 
				double name = Console.readDouble("price"); 		
				
				
			//	MechanicService service = new MechanicServiceImpl();
				VehicleTypeCrudService service = Factory.service.forVehicleTypeCrudService();
				VehicleTypeDto dto = service.findById(id).get();
				dto.name = dni;
				dto.pricePerHour = name;
				service.update(dto);
				// Print result
				Console.println("VT updated");
	}

}
