package uo.ri.ui.manager.vehicletype.action;


import uo.ri.conf.Factory;
import uo.ri.cws.application.service.vehicletype.VehicleTypeCrudService;
import uo.ri.ui.util.Printer;
import uo.ri.util.menu.Action;

public class ListAllVehicleTypesAction implements Action {

	@Override
	public void execute() throws Exception {
		// Get info
		VehicleTypeCrudService service = Factory.service.forVehicleTypeCrudService();
		Printer.printVehicleTypes(service.findAll());
	}

}
