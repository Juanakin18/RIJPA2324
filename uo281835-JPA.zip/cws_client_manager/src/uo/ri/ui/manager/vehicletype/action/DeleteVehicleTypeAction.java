package uo.ri.ui.manager.vehicletype.action;


import uo.ri.conf.Factory;
import uo.ri.cws.application.service.vehicletype.VehicleTypeCrudService;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;
public class DeleteVehicleTypeAction implements Action {

	@Override
	public void execute() throws Exception {
		// Get info
				String dni = Console.readString("name"); 
				
				
				
			//	MechanicService service = new MechanicServiceImpl();
				VehicleTypeCrudService service = Factory.service.forVehicleTypeCrudService();
				service.deleteVehicleType(dni);
				// Print result
				Console.println("VT removed");
	}

}
