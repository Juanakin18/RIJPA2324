package uo.ri.ui.manager.contracts.action;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.contract.ContractService;
import uo.ri.ui.util.Printer;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class EndContractAction implements Action {

	@Override
	public void execute() throws Exception {
		ContractService cs = Factory.service.forContractService();
		Printer.printContracts(cs.findAllContracts());
		String id = Console.readString("Introduzca el id");
		cs.terminateContract(id);
		Console.print("Se ha finalizado el contrato");
	}

}
