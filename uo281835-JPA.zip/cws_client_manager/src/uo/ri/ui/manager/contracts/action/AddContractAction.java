package uo.ri.ui.manager.contracts.action;

import java.time.LocalDate;
import uo.ri.conf.Factory;
import uo.ri.cws.application.service.contract.ContractService.ContractDto;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;
public class AddContractAction implements Action {

	@Override
	public void execute() throws Exception {
		String dni = Console.readString("Introduzca el dni");
		String name = Console.readString("Introduzca el nombre del tipo de contrato");
		String surname = Console.readString("Introduzca el nombre del grupo profesional");
		double email = Console.readDouble("Introduzca el salario base anual");
		int month = LocalDate.now().getMonthValue()+1;
		int year = LocalDate.now().getYear();
		if(month ==13) {
			month = 1;
			year++;
		}
		LocalDate date = LocalDate.of(year, month, 1);
		if(surname.equalsIgnoreCase("FIXED_TERM")) {
			LocalDate endDate = Console.readDate("Introduzca la fecha de inicio");
			ContractDto dto = new ContractDto();
			dto.dni = dni;
			dto.contractTypeName = name;
			dto.professionalGroupName = surname;
			dto.annualBaseWage = email;
			dto.startDate = date;
			dto.endDate = endDate;
			Factory.service.forContractService().addContract(dto);
			Console.println("Se ha a�adido el contrato");
		}else {
			ContractDto dto = new ContractDto();
			dto.dni = dni;
			dto.contractTypeName = name;
			dto.professionalGroupName = surname;
			dto.annualBaseWage = email;
			dto.startDate = date;
			Factory.service.forContractService().addContract(dto);
			Console.println("Se ha a�adido el contrato");
		}
		
	}

}
