package uo.ri.ui.manager.contracts.action;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.contract.ContractService;
import uo.ri.ui.util.Printer;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class ListContractsAction implements Action {

	@Override
	public void execute() throws Exception {
		ContractService cs = Factory.service.forContractService();
		int option = Console.readInt("1)Un contrato"
				+ " 2)Todos los de un trabajador"
				+ " 3) Todos");
		switch(option) {
		case 1:
			long id = Console.readLong("Introduzca el Id");
			Printer.printFullContract(cs.findContractById(id+"").get());
			break;
		case 2: 
			String dni = Console.readString("Introduzca el DNI");
			Printer.printContracts(cs.findContractsByMechanicDni(dni));
			break;
		case 3:
			Printer.printContracts(cs.findAllContracts());
			break;
		}
		
		String id = Console.readString("Introduzca el id");
		cs.deleteContract(id);
	}

}
