package uo.ri.ui.manager.contracts.action;

import java.time.LocalDate;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.contract.ContractService;
import uo.ri.cws.application.service.contract.ContractService.ContractDto;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class UpdateContractAction implements Action {

	@Override
	public void execute() throws Exception {
		String dni = Console.readString("Introduzca el id");
		double email = Console.readDouble("Introduzca el salario base anual");
		
		ContractService service = Factory.service.forContractService();
		ContractDto dto = service.findContractById(dni).get();
		if(dto.contractTypeName.equalsIgnoreCase("FIXED_TERM")) {
			LocalDate endDate = Console.readDate("Introduzca la fecha de inicio");
			dto.annualBaseWage = email;
			dto.endDate = endDate;
			Factory.service.forContractService().updateContract(dto);
			Console.println("Se ha actualizado el contrato");
		}else {
			dto.annualBaseWage = email;
			Factory.service.forContractService().updateContract(dto);
			Console.println("Se ha actualizado el contrato");
		}
	}

}
