package uo.ri.ui.manager.contracts;

import uo.ri.ui.manager.contracts.action.AddContractAction;
import uo.ri.ui.manager.contracts.action.DeleteContractAction;
import uo.ri.ui.manager.contracts.action.EndContractAction;
import uo.ri.ui.manager.contracts.action.ListContractsAction;
import uo.ri.ui.manager.contracts.action.UpdateContractAction;
import uo.ri.util.menu.BaseMenu;

public class ContractMenu extends BaseMenu {

	public ContractMenu() {
		menuOptions = new Object[][] {
				{ "Manager > Contract management", null },

				{ "Add contract ", AddContractAction.class },
				{ "Remove contract ",
						DeleteContractAction.class },
				{ "Update contract ", UpdateContractAction.class },
				{ "List contracts ", ListContractsAction.class },
				{ "End contract ", EndContractAction.class },
		};
	}

}
