package uo.ri.ui.manager.professionalgroups.action;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.professionalgroup.ProfessionalGroupService;
import uo.ri.cws.application.service.professionalgroup.ProfessionalGroupService.ProfessionalGroupBLDto;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class AddProfessionalGroupAction implements Action {

	@Override
	public void execute() throws Exception {
		String surname = Console.readString("Introduzca el nombre del grupo profesional");
		double email = Console.readDouble("Introduzca el triennium payment");
		double productivity = Console.readDouble("Introduzca el productivity rate");
		ProfessionalGroupService service = Factory.service.forProfessionalGroupService();
		ProfessionalGroupBLDto dto = new ProfessionalGroupBLDto();
		dto.name=surname;
		dto.productivityRate = productivity;
		dto.trieniumSalary = email;
		service.addProfessionalGroup(dto);
		Console.println("Se ha a�adido el grupo profesional");
	}

}
