package uo.ri.ui.manager.professionalgroups.action;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.professionalgroup.ProfessionalGroupService;
import uo.ri.cws.application.service.professionalgroup.ProfessionalGroupService.ProfessionalGroupBLDto;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class UpdateProfessionalGroupAction implements Action {

	@Override
	public void execute() throws Exception {
		String id = Console.readString("Introduzca el id");
		String surname = Console.readString("Introduzca el nombre del grupo profesional");
		double email = Console.readDouble("Introduzca el triennium payment");
		double productivity = Console.readDouble("Introduzca el productivity rate");
		ProfessionalGroupService service = Factory.service.forProfessionalGroupService();
		Optional<ProfessionalGroupBLDto> dto1 = service.findProfessionalGroupById(id);
		ProfessionalGroupBLDto dto = dto1.get();
		dto.name=surname;
		dto.productivityRate = productivity;
		dto.trieniumSalary = email;
		service.updateProfessionalGroup(dto);
		Console.println("Se ha actualizado el grupo profesional");
	
	}

}
