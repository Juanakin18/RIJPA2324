package uo.ri.ui.manager.professionalgroups.action;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.professionalgroup.ProfessionalGroupService;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class DeleteProfessionalGroupAction implements Action {

	@Override
	public void execute() throws Exception {
		String surname = Console.readString("Introduzca el id");
		ProfessionalGroupService service = Factory.service.forProfessionalGroupService();
		service.deleteProfessionalGroup(surname);
	
	}

}
