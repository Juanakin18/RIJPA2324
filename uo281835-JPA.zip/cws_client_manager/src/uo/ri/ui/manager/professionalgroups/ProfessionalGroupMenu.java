package uo.ri.ui.manager.professionalgroups;

import uo.ri.ui.manager.professionalgroups.action.AddProfessionalGroupAction;
import uo.ri.ui.manager.professionalgroups.action.DeleteProfessionalGroupAction;
import uo.ri.ui.manager.professionalgroups.action.ListProfessionalGroupAction;
import uo.ri.ui.manager.professionalgroups.action.UpdateProfessionalGroupAction;
import uo.ri.util.menu.BaseMenu;

public class ProfessionalGroupMenu extends BaseMenu {
	public ProfessionalGroupMenu() {
		menuOptions = new Object[][] {
				{ "Manager > Professional Groups management", null },

				{ "Add Professional group", AddProfessionalGroupAction.class },
				{ "List employees with contract in force for professional group",
						ListProfessionalGroupAction.class },
				{ "Remove professional group",
						DeleteProfessionalGroupAction.class },
				{ "Update professional group", UpdateProfessionalGroupAction.class }

		};
	}
}
