package uo.ri.ui.manager.professionalgroups.action;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.professionalgroup.ProfessionalGroupService;
import uo.ri.ui.util.Printer;
import uo.ri.util.menu.Action;

public class ListProfessionalGroupAction implements Action {

	@Override
	public void execute() throws Exception {
		ProfessionalGroupService service = Factory.service.forProfessionalGroupService();
		Printer.printProfessionalGroups(service.findAllProfessionalGroups());
	}

}
