package uo.ri.ui.util;

import java.util.List;

import uo.ri.cws.application.service.contract.ContractService.ContractDto;
import uo.ri.cws.application.service.contract.ContractService.ContractSummaryDto;
import uo.ri.cws.application.service.invoice.InvoicingService.InvoiceDto;
import uo.ri.cws.application.service.invoice.InvoicingService.PaymentMeanDto;
import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;
import uo.ri.cws.application.service.payroll.PayrollService.PayrollBLDto;
import uo.ri.cws.application.service.payroll.PayrollService.PayrollSummaryBLDto;
import uo.ri.cws.application.service.professionalgroup.ProfessionalGroupService.ProfessionalGroupBLDto;
import uo.ri.cws.application.service.sparepart.SparePartDto;
import uo.ri.cws.application.service.vehicletype.VehicleTypeCrudService.VehicleTypeDto;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;
import uo.ri.util.console.Console;

public class Printer {

	public static void printInvoice(InvoiceDto invoice) {

		double importeConIVa = invoice.total;
		double iva = invoice.vat;
		double importeSinIva = importeConIVa / (1 + iva / 100);

		Console.printf("Invoice #: %d\n", invoice.number);
		Console.printf("\tDate: %1$td/%1$tm/%1$tY\n", invoice.date);
		Console.printf("\tTotal: %.2f �\n", importeSinIva);
		Console.printf("\tTax: %.1f %% \n", invoice.vat);
		Console.printf("\tTotal, tax inc.: %.2f �\n", invoice.total);
		Console.printf("\tStatus: %s\n", invoice.state);
	}

	public static void printPaymentMeans(List<PaymentMeanDto> medios) {
		Console.println();
		Console.println("Available payment means");

		Console.printf("\t%s \t%-8.8s \t%s \n", "Id", "Type", "Acummulated");
		for (PaymentMeanDto medio : medios) {
			printPaymentMean(medio);
		}
	}

	private static void printPaymentMean(PaymentMeanDto medio) {
		Console.printf("\t%s \t%-8.8s \t%s \n", medio.id,
				medio.getClass().getName() // not the best...
				, medio.accumulated);
	}

	public static void printWorkOrder(WorkOrderDto rep) {

		Console.printf("\t%s \t%-40.40s \t%td/%<tm/%<tY \t%-12.12s \t%.2f\n",
				rep.id, rep.description, rep.date, rep.state, rep.total);
	}

	public static void printMechanic(MechanicDto m) {

		Console.printf("\t%s %-10.10s %-15.15s %-25.25s\n", m.id, m.dni, m.name,
				m.surname);
	}

	public static void printVehicleType(VehicleTypeDto vt) {

		Console.printf("\t%s %-10.10s %5.2f %d\n", vt.id, vt.name,
				vt.pricePerHour, vt.minTrainigHours);
	}

	public static void printPayroll(PayrollSummaryBLDto dto) {
		Console.println(dto.id + " " + dto.version + " " + dto.netWage + " "
				+ dto.date);

	}

	public static void printPayroll(PayrollBLDto dto) {
		Console.println(dto.id + " " + dto.version + " " + dto.netWage + " "
				+ dto.date + " " + dto.monthlyWage + " " + dto.bonus + " "
				+ dto.productivityBonus + " " + dto.trienniumPayment + " "
				+ dto.incomeTax + " " + dto.nic + " " + dto.netWage);

	}

	public static void printSpareParts(List<SparePartDto> dtos) {
		for (SparePartDto dto : dtos) {
			printSparePart(dto);
		}

	}
	public static void printSparePart(SparePartDto dto) {
		Console.println(dto.id + " " + dto.code + " " + dto.description
				+ " " + dto.price);
	}

	public static void printContracts(List<ContractSummaryDto> findAllContracts) {
		for(ContractSummaryDto dto : findAllContracts) {
			printContract(dto);
		}
		
	}

	public static void printContract(ContractSummaryDto dto) {
		Console.println(dto.id + " " + dto.settlement + " " + dto.state
				+ " " + dto.numPayrolls);
	}

	public static void printFullContract(ContractDto dto) {
	
		Console.println(dto.id + " "+ dto.dni+" "+dto.contractTypeName+"" 
				+dto.professionalGroupName+" "  
				+dto.startDate+" " 
				+ dto.annualBaseWage + " " + dto.state
				+ " " + dto.settlement);
		
	}

	public static void printProfessionalGroups(List<ProfessionalGroupBLDto> findAllProfessionalGroups) {
		for(ProfessionalGroupBLDto dto : findAllProfessionalGroups) {
			printProfessionalGroup(dto);
		}
		
	}

	public static void printProfessionalGroup(ProfessionalGroupBLDto dto) {
		Console.println(dto.id+" "+dto.name+" "+dto.productivityRate+" "+dto.trieniumSalary);
	}

	public static void printVehicleTypes(List<VehicleTypeDto> findAll) {
		for(VehicleTypeDto dto : findAll) {
			printVehicleType(dto);
		}
		
	}

}
