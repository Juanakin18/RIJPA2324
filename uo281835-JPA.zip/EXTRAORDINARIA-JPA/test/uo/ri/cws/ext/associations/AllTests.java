package uo.ri.cws.ext.associations;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ FireTests.class, GroupTests.class, HireTests.class, RunTests.class, TypeTests.class })
public class AllTests {

}
