package uo.ri.cws.domain;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table(name = "tclients")
public class Client extends BaseEntity {
	 @Column(unique = true)
	    private String dni; // identidad natural
	    @Basic(optional = false)
	    private String name;
	    @Basic(optional = false)
	    private String surname;
	    @Basic(optional = false)
	    private String email;
	    @Basic(optional = false)
	    private String phone;

	    Address address;// tabla embeddable

	    /*
	     * Atributos accidentales
	     */
	    @OneToMany(mappedBy = "client")
	    private Set<Vehicle> vehicles = new HashSet<>();
	    @OneToMany(mappedBy = "client")
	    private Set<PaymentMean> paymentMeans = new HashSet<>();

	public void setDni(String dni) {
		this.dni = dni;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setVehicles(Set<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

	public void setPaymentMeans(Set<PaymentMean> paymentMeans) {
		this.paymentMeans = paymentMeans;
	}
	Set<PaymentMean> _getPaymentMeans() {
		return paymentMeans;
	}

	public Set<PaymentMean> getPaymentMeans() {
		return new HashSet<PaymentMean>(paymentMeans);
	}

	public Client() {
	}

	public Client(String dni) {
		this.dni = dni;
	}

	public Client(String dni, String nombre, String apellidos) {
		ArgumentChecks.isNotNull(dni, "The dni can't be null");
		ArgumentChecks.isNotNull(nombre, "The name can't be null");
		ArgumentChecks.isNotNull(apellidos, "The surname can't be null");
		ArgumentChecks.isNotEmpty(dni, "The dni can't be empty");
		ArgumentChecks.isNotEmpty(nombre, "The name can't be empty");
		ArgumentChecks.isNotNull(apellidos, "The surname can't be empty");
		this.dni = dni;
		this.name = nombre;
		this.surname = apellidos;
	}

	@Override
	public String toString() {
		return "Client [dni=" + dni + ", name=" + name + ", surname=" + surname
				+ ", email=" + email + ", phone=" + phone + ", address="
				+ address + "]";
	}

	public String getDni() {
		return dni;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(dni);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Client other = (Client) obj;
		return Objects.equals(dni, other.dni);
	}

	public String getSurname() {
		return surname;
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public String getPhone() {
		return phone;
	}

	public Address getAddress() {
		return address;
	}

	Set<Vehicle> _getVehicles() {
		return vehicles;
	}

	public void addVehicle(Vehicle vehicle) {
		vehicles.add(vehicle);
	}

	public void removeVehicle(Vehicle vehicle) {
		vehicles.remove(vehicle);
	}

	public Set<Vehicle> getVehicles() {
		return new HashSet<Vehicle>(vehicles);
	}

	public void setAddress(Address address2) {
		this.address = address2;
	}

	public void setName(String name2) {
		// TODO Auto-generated method stub

	}

	public void setSurname(String surname2) {
		// TODO Auto-generated method stub

	}

	public void setEmail(String email2) {
		// TODO Auto-generated method stub

	}
}
