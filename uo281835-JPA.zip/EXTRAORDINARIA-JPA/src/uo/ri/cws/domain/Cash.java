package uo.ri.cws.domain;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "tcashes")
public class Cash extends PaymentMean {

	public Cash() {
	}
	
	public Cash(Client c) {
		Associations.Pay.link(this,c);
		
	}

	@Override
	public void pay(double importe) {
		this.accumulated += importe;

	}


}
