package uo.ri.cws.domain;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;
@Entity
@Table(name = "tspareparts")
public class SparePart extends BaseEntity{
	  // natural attributes
    @Column(unique = true)
    private String code;
    @Basic(optional = false)
    private String description;
    @Basic(optional = false)
    private double price;

    // accidental attributes
    @OneToMany(mappedBy = "sparePart")
    private Set<Substitution> substitutions = new HashSet<>();

	public SparePart() {}
	public SparePart(String code, String description, double price) {
		ArgumentChecks.isNotNull(code, "The code can't be null");
		ArgumentChecks.isNotNull(description, "The description can't be null");
		ArgumentChecks.isNotEmpty(code, "The code can't be empty");
		ArgumentChecks.isNotEmpty(description, "The description can't be empty");
		ArgumentChecks.isTrue(price > 0, "The price can't be negative");
		
		this.code = code;
		this.description = description;
		this.price = price;
	}

	public SparePart(String code2) {
		this(code2, "no description",0.0);
	}

	@Override
	public String toString() {
		return "SparePart [code=" + code + ", description=" + description
				+ ", price=" + price + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(code);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SparePart other = (SparePart) obj;
		return Objects.equals(code, other.code);
	}

	public String getCode() {
		return code;
	}

	public String getDescription() {
		return description;
	}

	public double getPrice() {
		return price;
	}

	public Set<Substitution> getSustitutions() {
		return new HashSet<>(substitutions);
	}

	Set<Substitution> _getSubstitutions() {
		return substitutions;
	}

	public void setCode(String code2) {
		this.code = code2;
		
	}

	public void setDescription(String description2) {
		this.description = description2;
		
	}

	public void setPrice(double price2) {
		this.price = price2;
		
	}

}
