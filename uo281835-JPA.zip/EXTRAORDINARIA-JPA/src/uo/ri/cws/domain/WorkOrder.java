package uo.ri.cws.domain;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table(name = "tworkorders", uniqueConstraints = @UniqueConstraint(columnNames = {
	"date", "vehicle_id" }))

public class WorkOrder extends BaseEntity {
	public enum WorkOrderState {
		OPEN, ASSIGNED, FINISHED, INVOICED
	}


    // natural attributes
    @Basic(optional = false)
    private LocalDateTime date;
    @Basic(optional = false)
    private String description;
    @Basic(optional = false)
    private double amount = 0.0;
    @Enumerated(EnumType.STRING)
    @Basic(optional = false)
    private WorkOrderState status = WorkOrderState.OPEN;

    // accidental attributes
    @ManyToOne(optional = false)
    private Vehicle vehicle;
    @ManyToOne(optional = false)
    private Mechanic mechanic;
    @ManyToOne(optional = false)
    private Invoice invoice;
    @OneToMany(mappedBy = "workOrder")
    private Set<Intervention> interventions = new HashSet<>();

	
	public WorkOrder() {
	}

	public WorkOrder(Vehicle vehicle, String string) {
		this(vehicle, LocalDateTime.now(), string);

	}

	public WorkOrder(Vehicle vehicle2) {
		this(vehicle2, "vacio");
	}

	public WorkOrder(Vehicle vehicle2, LocalDateTime now, String string) {
		ArgumentChecks.isNotNull(vehicle2, "The vehicle can't be null");
		ArgumentChecks.isNotNull(now, "The date can't be null");
		ArgumentChecks.isNotNull(string, "The description can't be null");
		ArgumentChecks.isNotEmpty(string, "The date can't be empty");
		
		this.vehicle = vehicle2;
		this.date = now;
		this.description = string;
		Associations.Fix.link(vehicle, this);
	}

	public WorkOrder(Vehicle v, LocalDateTime atStartOfDay) {
		this(v, atStartOfDay, "sin descripción");
	}

	void _setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}

	/**
	 * Changes it to INVOICED state given the right conditions This method is
	 * called from Invoice.addWorkOrder(...)
	 * 
	 * @see UML_State diagrams on the problem statement document
	 * @throws IllegalStateException if - The work order is not FINISHED, or -
	 *                               The work order is not linked with the
	 *                               invoice
	 */
	public void markAsInvoiced() {
		if (status != WorkOrderState.FINISHED || invoice == null)
			throw new IllegalStateException("Estado inválido");
		status = WorkOrderState.INVOICED;

	}

	/**
	 * Changes it to FINISHED state given the right conditions and computes the
	 * amount
	 *
	 * @see UML_State diagrams on the problem statement document
	 * @throws IllegalStateException if - The work order is not in ASSIGNED
	 *                               state, or - The work order is not linked
	 *                               with a mechanic
	 */
	public void markAsFinished() {
		if (status != WorkOrderState.ASSIGNED || mechanic == null)
			throw new IllegalStateException("Estado inválido");
		status = WorkOrderState.FINISHED;
		amount = computeAmount();
	}

	/**
	 * Calcula el total de esta workOrder
	 * 
	 * @return El total
	 */
	private double computeAmount() {
		double amount = 0;
		for (Intervention i : interventions) {
			amount += i.getAmount();
		}
		return Math.round(amount * 100.00) / 100.00;
	}

	/**
	 * Changes it back to FINISHED state given the right conditions This method
	 * is called from Invoice.removeWorkOrder(...)
	 * 
	 * @see UML_State diagrams on the problem statement document
	 * @throws IllegalStateException if - The work order is not INVOICED, or -
	 *                               The work order is still linked with the
	 *                               invoice
	 */
	public void markBackToFinished() {
		if (status != WorkOrderState.INVOICED || invoice != null)
			throw new IllegalStateException("Estado inválido");
		status = WorkOrderState.FINISHED;
	}

	/**
	 * Links (assigns) the work order to a mechanic and then changes its state
	 * to ASSIGNED
	 * 
	 * @see UML_State diagrams on the problem statement document
	 * @throws IllegalStateException if - The work order is not in OPEN state,
	 *                               or - The work order is already linked with
	 *                               another mechanic
	 */
	public void assignTo(Mechanic mechanic) {
		if (status != WorkOrderState.OPEN || this.mechanic != null)
			throw new IllegalStateException("Estado inválido");
		Associations.Assign.link(mechanic, this);
		this.status = WorkOrderState.ASSIGNED;
	}

	/**
	 * Unlinks (deassigns) the work order and the mechanic and then changes its
	 * state back to OPEN
	 * 
	 * @see UML_State diagrams on the problem statement document
	 * @throws IllegalStateException if - The work order is not in ASSIGNED
	 *                               state
	 */
	public void desassign() {
		if (status != WorkOrderState.ASSIGNED)
			throw new IllegalStateException("Estado inválido");
		Associations.Assign.unlink(mechanic, this);
		this.status = WorkOrderState.OPEN;
	}

	/**
	 * In order to assign a work order to another mechanic is first have to be
	 * moved back to OPEN state and unlinked from the previous mechanic.
	 * 
	 * @see UML_State diagrams on the problem statement document
	 * @throws IllegalStateException if - The work order is not in FINISHED
	 *                               state
	 */
	public void reopen() {
		if (status != WorkOrderState.FINISHED)
			throw new IllegalStateException("Estado inválido");
		Associations.Assign.unlink(mechanic, this);
		this.status = WorkOrderState.OPEN;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public String getDescription() {
		return description;
	}

	public double getAmount() {
		if (amount == 0)
			this.amount = computeAmount();
		return amount;
	}

	public WorkOrderState getStatus() {
		return status;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ Objects.hash(date.truncatedTo(ChronoUnit.MILLIS), vehicle);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		WorkOrder other = (WorkOrder) obj;
		return Objects.equals(date.truncatedTo(ChronoUnit.MILLIS),
				other.date.truncatedTo(ChronoUnit.MILLIS))
				&& Objects.equals(vehicle, other.vehicle);
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public Invoice getInvoice() {
		return invoice;
	}

	public Set<Intervention> getInterventions() {
		return new HashSet<>(interventions);
	}

	Set<Intervention> _getInterventions() {
		return interventions;
	}

	void _setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	void _setMechanic(Mechanic mechanic) {
		this.mechanic = mechanic;
	}

	public Mechanic getMechanic() {
		return mechanic;
	}

	public boolean isInvoiced() {
		return WorkOrderState.INVOICED.equals(status);
	}

	public boolean isFinished() {
		return WorkOrderState.FINISHED.equals(status);
	}

	@Override
	public String toString() {
		return "WorkOrder [date=" + date + ", description=" + description
				+ ", amount=" + amount + ", state=" + status + "]";
	}

	public void setState(WorkOrderState s) {
		this.status = s;
	}

	public void unmark() {
		status = WorkOrderState.FINISHED;

	}

	public void setStatusForTesting(WorkOrderState invoiced) {
		this.status = invoiced;

	}

	public void setAmountForTesting(double money) {
		this.amount = money;

	}

}
