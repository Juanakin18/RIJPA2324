package uo.ri.cws.domain;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table(name = "tvehicles")
public class Vehicle extends BaseEntity {
	@Column(unique = true)
    private String plateNumber;
    @Basic(optional = false)
    private String brand;
    @Basic(optional = false)
    private String model;

    /*
     * Atributo accidental
     */
    @ManyToOne
    private Client client;
    @ManyToOne
    private VehicleType vehicleType;
    @OneToMany(mappedBy = "vehicle")
    private Set<WorkOrder> workOrders = new HashSet<>();

	public void setPlateNumber(String plateNumber) {
		this.plateNumber = plateNumber;
	}

	public void setMake(String make) {
		this.brand = make;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Vehicle() {
	}

	public Vehicle(String plateNumber, String make, String model) {
		ArgumentChecks.isNotNull(plateNumber, "The plateNumber can't be null");
		ArgumentChecks.isNotNull(make, "The make can't be null");
		ArgumentChecks.isNotNull(model, "The model can't be null");
		ArgumentChecks.isNotEmpty(plateNumber);
		ArgumentChecks.isNotEmpty(make);
		ArgumentChecks.isNotEmpty(model);
		this.plateNumber = plateNumber;
		this.brand = make;
		this.model = model;
	}

	public Vehicle(String plateNumber2) {
		this(plateNumber2, "no make", "no model");
	}

	@Override
	public String toString() {
		return "Vehicle [plateNumber=" + plateNumber + ", make=" + brand
				+ ", model=" + model + "]";
	}

	public String getPlateNumber() {
		return plateNumber;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(plateNumber);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vehicle other = (Vehicle) obj;
		return Objects.equals(plateNumber, other.plateNumber);
	}

	public String getMake() {
		return brand;
	}

	public String getModel() {
		return model;
	}

	public VehicleType getVehicleType() {
		return vehicleType;
	}

	public Client getClient() {
		return client;
	}

	void _setCliente(Client cliente) {
		this.client = cliente;
	}

	void _setVehicleType(VehicleType vehicleType2) {
		this.vehicleType = vehicleType2;

	}

	Set<WorkOrder> _getWorkOrders() {
		return workOrders;

	}

	public Set<WorkOrder> getWorkOrders() {

		return new HashSet<WorkOrder>(workOrders);
	}

}
