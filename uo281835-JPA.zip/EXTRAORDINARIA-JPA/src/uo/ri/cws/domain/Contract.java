package uo.ri.cws.domain;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import uo.ri.cws.application.service.contract.ContractService.ContractState;
import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table(name = "tcontracts", uniqueConstraints = @UniqueConstraint(columnNames = {
	"mechanic_id", "startdate", "firedmechanic_id" }))
public class Contract extends BaseEntity {

	  // naturales
    @Basic(optional = false)
    private LocalDate startDate;
    @Basic(optional = false)
    private double annualBaseWage;
    @Basic(optional = false)
    private LocalDate endDate;
    @Basic(optional = false)
    private double settlement;
    @Enumerated(EnumType.STRING)
    @Basic(optional = false)
    private ContractState state;

    // accidentales

    @OneToOne()
    private Mechanic mechanic;
    @ManyToOne
    private Mechanic firedMechanic;
    @ManyToOne
    private ContractType contractType;
    @ManyToOne
    private ProfessionalGroup professionalGroup;
    @OneToMany(mappedBy = "contract")
    private Set<Payroll> payrolls = new HashSet<>();

    
	public double getProductivityBonus() {
		return productivityBonus;
	}
	@Transient
	private double productivityBonus;
	
	public Contract() {}
	public Contract(Mechanic mechanic2, ContractType type, ProfessionalGroup group, double wage) {
		this(mechanic2, type,group,getLastDayOfNextMonth(), wage);
		
	}
	public Contract(Mechanic mechanic2, ContractType contractType2, ProfessionalGroup pg, LocalDate endDate2,
			double d) {
		
		this( LocalDate.now(),d,endDate2,0,ContractState.IN_FORCE,mechanic2,null,contractType2, pg,0);
		
	}
	public Contract( LocalDate startDate, double annualWage, LocalDate endDate, double settlement,
			ContractState state, Mechanic mechanic, Mechanic firedMechanic, ContractType contractType,
			ProfessionalGroup group, double productivityBonus) {
		super();
		ArgumentChecks.isNotNull(startDate);
		ArgumentChecks.isNotNull(endDate);
		ArgumentChecks.isTrue(startDate.isBefore(endDate)||startDate.isEqual(endDate));
		ArgumentChecks.isNotNull(contractType);
		ArgumentChecks.isNotNull(group);
		ArgumentChecks.isNotNull(mechanic);
		this.startDate = startDate;
		this.annualBaseWage = annualWage;
		this.endDate = endDate;
		this.state = state;
		Associations.Hire.link(this, mechanic);
		Associations.Type.link(this, contractType);
		Associations.Group.link(this, group);
		this.firedMechanic = firedMechanic;
		this.productivityBonus = productivityBonus;
		this.settlement = calculateSettlement();
	}
	public Contract(LocalDate startDate2, Mechanic _getMechanic, ContractType contractType2,
			ProfessionalGroup professionalGroup2, double annualBaseWage2) {
		this( startDate2 ,annualBaseWage2,getLastDayOfNextMonth(),0,ContractState.IN_FORCE,_getMechanic,null,contractType2, professionalGroup2,0);
	}
	public Contract(LocalDate startDate2, Mechanic mechanic2, ContractType contractType2,
			ProfessionalGroup professionalGroup2, LocalDate endDate2, double annualBaseWage2) {
		this( startDate2 ,annualBaseWage2,endDate2,0,ContractState.IN_FORCE,mechanic2,null,contractType2, professionalGroup2,0);
		
	}
	public static LocalDate getLastDayOfNextMonth() {
		int day = LocalDate.now().getDayOfMonth();
		int month = LocalDate.now().getMonth().getValue()+1;
		int year = LocalDate.now().getYear();
		if(month ==13) {
			month =1;
			year++;
		}
		return LocalDate.of(year, month, day);
	}
	private double calculateSettlement() {
		double a = getA();
		double compensationDays = contractType.getCompensationDays();
		int years = LocalDate.now().getYear()- startDate.getYear();
		int month =  LocalDate.now().getDayOfYear()- startDate.getDayOfYear();
		if(month<1) {
			years--;
		}
		double total =a*compensationDays*years;
		if(total<1)
			return 0.00;
		else
			return total;
		/*if(endDate.getYear()==LocalDate.now().getYear() && 
				endDate.getMonth() == LocalDate.now().getMonth())
			return a*compensationDays*years;
		else
			return 0;*/
	}
	private double getA() {
		double a = 0;
		for(Payroll r : payrolls) {
			if(ChronoUnit.DAYS.between( r.getDate() , LocalDate.now() )<365) {
				a+=r.calculateGrossWage();
			}
		}
		return a/365;
	}
	public Optional<Mechanic> getFiredMechanic() {
		if(firedMechanic == null)
			return Optional.empty();
		return Optional.of(firedMechanic);
	}
	public Optional<Mechanic> getMechanic() {
		if(mechanic==null)
			return Optional.empty();
		return Optional.of(mechanic);
	}
	public void setFiredMechanic(Mechanic mechanic) {
		ArgumentChecks.isNotNull(mechanic, "no puede ser nulo");
		Associations.Fire.link(this, mechanic);
		
	}
	public ProfessionalGroup getProfessionalGroup() {
		return professionalGroup;
	}
	public ContractType getContractType() {
		return contractType;
	}
	public void _setFiredMechanic(Mechanic object) {
		this.firedMechanic = object;
		
	}
	public Mechanic _getMechanic() {
		return mechanic;
	}
	public void _setContractType(ContractType type) {
		this.contractType = type;
		
	}
	public void _setMechanic(Mechanic mechanic) {
		this.mechanic = mechanic;
		
	}
	public void _setProfessionalGroup(ProfessionalGroup group) {
		this.professionalGroup = group;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(firedMechanic, mechanic, startDate);
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Contract other = (Contract) obj;
		return Objects.equals(firedMechanic, other.firedMechanic) && Objects.equals(mechanic, other.mechanic)
				&& Objects.equals(startDate, other.startDate);
	}
	
	public LocalDate getStartDate() {
		return startDate;
	}
	public double getAnnualWage() {
		return annualBaseWage;
	}
	public Optional<LocalDate> getEndDate() {
		if(endDate==null)
			return Optional.empty();
		return Optional.of(endDate);
	}
	public double getSettlement() {
		this.settlement = calculateSettlement();
		return settlement;
	}
	public ContractState getState() {
		return state;
	}
	public ProfessionalGroup getGroup() {
		return professionalGroup;
	}
	public Set<Payroll> getPayrolls() {
		return new HashSet<Payroll>(payrolls);
	}
	public Set<Payroll> _getPayrolls() {
		return payrolls;
	}
	public void terminate() {
		state = ContractState.TERMINATED;
		this.settlement = calculateSettlement();
		this.endDate = getLastDayOfThisMonth();
		Associations.Fire.link(this, mechanic);
		Associations.Hire.unlink(this, mechanic);
	}
	private LocalDate getLastDayOfThisMonth() {
		int day = LocalDate.now().lengthOfMonth();
		int month = LocalDate.now().getMonth().getValue();
		int year = LocalDate.now().getYear();
		
		return LocalDate.of(year, month, day);
	}
	public double getAnnualBaseWage() {
		return annualBaseWage;
	}
	public void setStartDate(LocalDate startDate2) {
		ArgumentChecks.isNotNull(startDate2);
		this.startDate = startDate2;
	}
	public void setProductivityBonus(double d) {
		this.productivityBonus=d;
		
	}
	public void setWage(double annualBaseWage) {
		this.annualBaseWage = annualBaseWage;
	}
	public void setEndDate(LocalDate endDate2) {
		this.endDate = endDate2;
	}

}
