package uo.ri.cws.domain;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;
@Entity
@Table(name = "tprofessionalgroups")
public class ProfessionalGroup extends BaseEntity {


    // atributos naturales
    @Column(unique = true)
    private String name;
    @Basic(optional = false)
    private double productivityBonusPercentage;
    @Basic(optional = false)
    private double trienniumPayment;

    // accidentales
    @OneToMany(mappedBy = "professionalGroup")
    private Set<Contract> contracts = new HashSet<>();
@Override
	public String toString() {
		return "ProfessionalGroup [name=" + name + ", productivityRate=" + productivityBonusPercentage + ", trienniumPayment="
				+ trienniumPayment + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(name);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProfessionalGroup other = (ProfessionalGroup) obj;
		return Objects.equals(name, other.name);
	}

	
	
	public ProfessionalGroup() {
		this("no name", 10, 10);
	}
	public ProfessionalGroup(String string, double e, double d) {
		ArgumentChecks.isNotNull(string);
		ArgumentChecks.isNotEmpty(string);
		ArgumentChecks.isTrue(d>0, "Debe ser mayor que 0");
		ArgumentChecks.isTrue(e>0, "Debe ser mayor que 0");
		this.setName(string);
		this.setProductivityRate(d);
		this.setTrienniumPayment(e);
	}

	public Set<Contract> getContracts() {
		return new HashSet<Contract>(contracts);
	}

	public Set<Contract> _getContracts() {
		return contracts;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getProductivityRate() {
		return productivityBonusPercentage;
	}

	public void setProductivityRate(double productivityRate) {
		this.productivityBonusPercentage = productivityRate;
	}

	public double getTrienniumPayment() {
		return trienniumPayment;
	}

	public void setTrienniumPayment(double trienniumPayment) {
		this.trienniumPayment = trienniumPayment;
	}

	public double getProductivityBonusPercentage() {
		return productivityBonusPercentage;
	}


}
