package uo.ri.cws.domain;

import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table(name = "tcreditcards")
public class CreditCard extends PaymentMean {
	  @Column(unique = true)
	    private String number;
	    @Basic(optional = false)
	    private String type;
	    @Basic(optional = false)
	    private LocalDate validThru;

	public CreditCard() {}
	public CreditCard(String number) {
		
		this(number, "UNKNOWN", LocalDate.now().plusDays(1));
	}

	public CreditCard(String number, String type, LocalDate minusDays) {
		ArgumentChecks.isNotEmpty(number, "el número no puede ser nulo");
		ArgumentChecks.isNotEmpty(type,"El tipo no puede estar vacío");
		ArgumentChecks.isNotNull(number);
		ArgumentChecks.isNotEmpty(number);
		ArgumentChecks.isNotNull(type);
		ArgumentChecks.isNotEmpty(type);
		ArgumentChecks.isNotNull(minusDays);
		
		this.number = number;
		this.type = type;
		this.validThru = minusDays;
		setValidThru(minusDays);
	}

	@Override
	public String toString() {
		return "CreditCard [number=" + number + ", type=" + type
				+ ", validThru=" + validThru + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(number);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		CreditCard other = (CreditCard) obj;
		return Objects.equals(number, other.number);
	}

	public String getNumber() {
		return number;
	}

	public String getType() {
		return type;
	}

	public LocalDate getValidThru() {
		return validThru;
	}

	public boolean isValidNow() {

		return validThru.isAfter(LocalDate.now());
	}

	public void setValidThru(LocalDate minusDays) {
	
		this.validThru = minusDays;

	}

	private boolean isValidNow(LocalDate minusDays) {
		return minusDays.isAfter(LocalDate.now());
	}

	@Override
	public void pay(double importe) {
		if (!isValidNow(validThru))
			throw new IllegalStateException("a");
		this.accumulated += importe;
		
	}

}
