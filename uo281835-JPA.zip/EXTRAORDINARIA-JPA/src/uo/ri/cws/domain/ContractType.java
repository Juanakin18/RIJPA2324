package uo.ri.cws.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import uo.ri.cws.domain.base.BaseEntity;
import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table(name = "tcontracttypes")
public class ContractType extends BaseEntity {

	// atributos naturales
    @Column(unique = true)
    private String name;
    @Basic(optional = false)
    private double compensationDays;

    // accidentales
    @OneToMany(mappedBy = "contractType")
    private Set<Contract> contracts = new HashSet<>();
	public ContractType() {}
	public ContractType(String string, double d) {
		ArgumentChecks.isNotNull(string);
		
		ArgumentChecks.isNotEmpty(string);
		ArgumentChecks.isTrue(d>=0);
		this.name = string;
		this.compensationDays = d;
	}

	public Set<Contract> getContracts() {
		return new HashSet<Contract>(contracts);
	}

	public Set<Contract> _getContracts() {
		return contracts;
	}

	public String getName() {
		return name;
	}

	public double getCompensationDays() {
		return compensationDays;
	}

	public void setName(String name2) {
		this.name = name2;
		
	}

	public void setCompensationDays(double compensationDays2) {
		this.compensationDays = compensationDays2;
		
	}

}
