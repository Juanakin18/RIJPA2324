package uo.ri.cws.infrastructure.persistence.jpa.repository;

import java.util.Optional;

import uo.ri.cws.application.repository.VehicleTypeRepository;
import uo.ri.cws.domain.VehicleType;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;
import uo.ri.cws.infrastructure.persistence.jpa.util.Jpa;

public class VehicleTypeRepositoryImpl extends BaseJpaRepository<VehicleType> implements VehicleTypeRepository {


	@Override
	public Optional<VehicleType> findByName(String name) {
		return Optional.of(
				Jpa	.getManager()
					.createNamedQuery("VehicleType.findByName", VehicleType.class)
					.setParameter(1, name)
					.getResultList()
					.get(0));
	}


}
