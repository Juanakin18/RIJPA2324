package uo.ri.cws.infrastructure.persistence.jpa.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.service.contract.ContractService.ContractState;
import uo.ri.cws.domain.Contract;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;
import uo.ri.cws.infrastructure.persistence.jpa.util.Jpa;

public class ContractJpaRepository extends BaseJpaRepository<Contract>
		implements ContractRepository {

	@Override
	public List<Contract> findAllInForce() {
		List<Contract> p = Jpa	.getManager()
								.createNamedQuery("Contract.findInForce",
										Contract.class)
								.setParameter(1, ContractState.IN_FORCE)
								.getResultList();
		return p;
	}

	@Override
	public List<Contract> findByMechanicId(String id) {
		List<Contract> p = Jpa	.getManager()
								.createNamedQuery("Contract.findByMechId",
										Contract.class)
								.setParameter(1, id)
								.getResultList();
		return p;
	}

	@Override
	public List<Contract> findByProfessionalGroupId(String id) {
		List<Contract> p = Jpa	.getManager()
								.createNamedQuery(
										"Contract.findByProfessionalGroupId",
										Contract.class)
								.setParameter(1, id)
								.getResultList();
		return p;
	}

	@Override
	public List<Contract> findByContractTypeId(String id2Del) {
		List<Contract> p = Jpa	.getManager()
								.createNamedQuery(
										"Contract.findByContractTypeId",
										Contract.class)
								.setParameter(1, id2Del)
								.getResultList();
		return p;
	}

	@Override
	public List<Contract> findAllInForceThisMonth(LocalDate present) {
		List<Contract> p = Jpa	.getManager()
								.createNamedQuery(
										"Contract.findByMonth",
										Contract.class)
								.setParameter(1,
										LocalDate.of(LocalDate.now().getYear(),
												LocalDate.now().getMonth(), 1))
								.setParameter(2, LocalDate.of(
										LocalDate.now().getYear(),
										LocalDate.now().getMonth(),
										LocalDate	.now()
													.getMonth()
													.length(LocalDate	.now()
																		.isLeapYear())))
								.setParameter(3, ContractState.IN_FORCE)
								.getResultList();
		return p;
	}

	@Override
	public List<Contract> findTerminated() {
		List<Contract> p = Jpa	.getManager()
								.createNamedQuery("Contract.findTerminated",
										Contract.class)
								.setParameter(1, ContractState.TERMINATED)
								.getResultList();
		return p;
	}

	
	@Override
	public Optional<Contract> findAllInForceByMechanic(String dni) {
		List<Contract> c = Jpa.getManager()
				.createNamedQuery("Contract.findInForceByDni", Contract.class)
				.setParameter(1, dni)
				.setParameter(2, ContractState.IN_FORCE)
				.getResultList();
		if(c.size()>0)
		return Optional.of(c.get(0));
		else
			return Optional.empty();
	}

}
