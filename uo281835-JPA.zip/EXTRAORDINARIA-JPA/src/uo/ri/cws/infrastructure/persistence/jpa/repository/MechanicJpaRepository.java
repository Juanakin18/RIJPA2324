package uo.ri.cws.infrastructure.persistence.jpa.repository;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.repository.MechanicRepository;
import uo.ri.cws.application.service.contract.ContractService.ContractState;
import uo.ri.cws.domain.ContractType;
import uo.ri.cws.domain.Mechanic;
import uo.ri.cws.domain.ProfessionalGroup;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;
import uo.ri.cws.infrastructure.persistence.jpa.util.Jpa;

public class MechanicJpaRepository extends BaseJpaRepository<Mechanic>
		implements MechanicRepository {

	@Override
	public Optional<Mechanic> findByDni(String dni) {
		List<Mechanic> a = Jpa	.getManager()
								.createNamedQuery("Mechanic.findByDni",
										Mechanic.class)
								.setParameter(1, dni)
								.getResultList();
		if (a.size() > 0)
			return Optional.of(a.get(0));
		return Optional.ofNullable(null);
	}

	@Override
	public List<Mechanic> findAllInForce() {
		return Jpa	.getManager()
					.createNamedQuery("Mechanic.findInForce", Mechanic.class)
					.setParameter(1, ContractState.IN_FORCE)
					.getResultList();
	}

	@Override
	public List<Mechanic> findInForceInContractType(ContractType contractType) {

		return Jpa	.getManager()
					.createNamedQuery("Mechanic.findInContractType",
							Mechanic.class)
					.setParameter(1, contractType)
					.getResultList();
	}

	@Override
	public List<Mechanic> findAllInProfessionalGroup(ProfessionalGroup group) {

		return Jpa	.getManager()
					.createNamedQuery("Mechanic.findInProfessionalGroup",
							Mechanic.class)
					.setParameter(1, group)
					.getResultList();
	}
}
