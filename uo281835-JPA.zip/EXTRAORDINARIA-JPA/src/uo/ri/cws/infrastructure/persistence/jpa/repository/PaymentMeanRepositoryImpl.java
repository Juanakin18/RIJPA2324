package uo.ri.cws.infrastructure.persistence.jpa.repository;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.domain.CreditCard;
import uo.ri.cws.domain.PaymentMean;
import uo.ri.cws.domain.Voucher;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;
import uo.ri.cws.infrastructure.persistence.jpa.util.Jpa;

public class PaymentMeanRepositoryImpl extends BaseJpaRepository<PaymentMean>
		implements PaymentMeanRepository {

	@Override
	public List<PaymentMean> findPaymentMeansByClientId(String id) {
		return Jpa	.getManager()
					.createNamedQuery("PaymentMean.findByClient",
							PaymentMean.class)
					.setParameter(1, id)
					.getResultList();
	}

	@Override
	public List<PaymentMean> findPaymentMeansByInvoiceId(String idFactura) {
		return Jpa	.getManager()
					.createNamedQuery("PaymentMean.findByInvoiceId",
							PaymentMean.class)
					.setParameter(1, idFactura)
					.getResultList();
	}

	@Override
	public List<PaymentMean> findByClientId(String id) {
		return Jpa	.getManager()
					.createNamedQuery("PaymentMean.findByClient",
							PaymentMean.class)
					.setParameter(1, id)
					.getResultList();
	}

	@Override
	public Object[] findAggregateVoucherDataByClientId(String id) {
		List<Voucher> v = Jpa	.getManager()
								.createNamedQuery("Voucher.findByClient",
										Voucher.class)
								.setParameter(1, id)
								.getResultList();
		Object[] result = new Object[3];
		int number = 0;
		double amount = 0;
		double consumed = 0;
		for (Voucher v1 : v) {
			number++;
			amount += v1.getAccumulated();
			consumed += v1.getAccumulated() - v1.getAvailable();
		}
		result[0] = number;
		result[1] = amount;
		result[2] = consumed;
		return result;
	}

	@Override
	public Optional<CreditCard> findCreditCardByNumber(String pan) {
		return Optional.of(Jpa	.getManager()
								.createNamedQuery("CreditCard.findByNumber",
										CreditCard.class)
								.setParameter(1, pan)
								.getResultList()
								.get(0));
	}

	@Override
	public List<Voucher> findVouchersByClientId(String id) {

		return Jpa	.getManager()
					.createNamedQuery("Voucher.findByClient", Voucher.class)
					.setParameter(1, id)
					.getResultList();
	}

	@Override
	public Optional<Voucher> findVoucherByCode(String code) {
		return Optional.of(
				Jpa	.getManager()
					.createNamedQuery("Voucher.findByCode", Voucher.class)
					.setParameter(1, code)
					.getResultList()
					.get(0));
	}

	@Override
	public List<Voucher> findVoucherByClientId(String id) {
		return Jpa	.getManager()
				.createNamedQuery("Voucher.findByClient", Voucher.class)
				.setParameter(1, id)
				.getResultList();
	}

	@Override
	public Optional<Voucher> findVoucherById(String id) {
		return  Optional.of(
					Jpa	.getManager()
						.createNamedQuery("Voucher.findById", Voucher.class)
						.setParameter(1, id)
						.getResultList()
						.get(0));
	}

}
