package uo.ri.cws.infrastructure.persistence.jpa.repository;

import uo.ri.cws.application.repository.ChargeRepository;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.repository.ContractTypeRepository;
import uo.ri.cws.application.repository.InterventionRepository;
import uo.ri.cws.application.repository.InvoiceRepository;
import uo.ri.cws.application.repository.MechanicRepository;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.repository.PayrollRepository;
import uo.ri.cws.application.repository.ProfessionalGroupRepository;
import uo.ri.cws.application.repository.RepositoryFactory;
import uo.ri.cws.application.repository.SparePartRepository;
import uo.ri.cws.application.repository.SubstitutionRepository;
import uo.ri.cws.application.repository.VehicleRepository;
import uo.ri.cws.application.repository.VehicleTypeRepository;
import uo.ri.cws.application.repository.WorkOrderRepository;

public class JpaRepositoryFactory implements RepositoryFactory {

	@Override
	public MechanicRepository forMechanic() {
		return new MechanicJpaRepository();
	}

	@Override
	public WorkOrderRepository forWorkOrder() {
		return new WorkOrderRepositoryImpl();
	}

	@Override
	public PaymentMeanRepository forPaymentMean() {
		return new PaymentMeanRepositoryImpl();
	}

	@Override
	public InvoiceRepository forInvoice() {
		return new InvoiceRepositoryImpl();
	}

	@Override
	public ClientRepository forClient() {
		return new ClientRepositoryImpl();
	}

	@Override
	public SparePartRepository forSparePart() {
		return new SparePartRepositoryImpl();
	}

	@Override
	public InterventionRepository forIntervention() {
		return new InterventionRepositoryImpl();
	}

	@Override
	public VehicleRepository forVehicle() {
		return new VehicleRepositoryImpl();
	}

	@Override
	public VehicleTypeRepository forVehicleType() {
		return new VehicleTypeRepositoryImpl();
	}

	@Override
	public ChargeRepository forCharge() {
		return new ChargeJpaRepository();
	}

	@Override
	public ContractRepository forContract() {
		return new ContractJpaRepository();
	}

	@Override
	public ProfessionalGroupRepository forProfessionalGroup() {
		return new ProfessionalGroupJpaRepository();
	}

	@Override
	public ContractTypeRepository forContractType() {
		return new ContractTypeJpaRepository();
	}

	@Override
	public PayrollRepository forPayroll() {
		return new PayrollJpaRepository();
	}

	@Override
	public SubstitutionRepository forSubstitution() {
		return new SubstitutionRepositoryImpl();
	}

}
