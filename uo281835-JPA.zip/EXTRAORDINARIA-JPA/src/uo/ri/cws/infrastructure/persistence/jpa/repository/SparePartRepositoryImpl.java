package uo.ri.cws.infrastructure.persistence.jpa.repository;

import java.util.Optional;

import uo.ri.cws.application.repository.SparePartRepository;
import uo.ri.cws.domain.SparePart;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;
import uo.ri.cws.infrastructure.persistence.jpa.util.Jpa;

public class SparePartRepositoryImpl extends BaseJpaRepository<SparePart> implements SparePartRepository {

	

	@Override
	public Optional<SparePart> findByCode(String code) {
		return Optional.of(
				Jpa	.getManager()
					.createNamedQuery("SparePart.findByCode", SparePart.class)
					.setParameter(1, code)
					.getResultList()
					.get(0));
	}

	@Override
	public Optional<SparePart> findByMarca(String code) {
		return Optional.of(
				Jpa	.getManager()
					.createNamedQuery("SparePart.findByMake", SparePart.class)
					.setParameter(1, code)
					.getResultList()
					.get(0));
	}

	@Override
	public Optional<SparePart> findByDescription(String code) {
		return Optional.of(
				Jpa	.getManager()
					.createNamedQuery("SparePart.findByDescription", SparePart.class)
					.setParameter(1, code)
					.getResultList()
					.get(0));
	}

	@Override
	public Optional<SparePart> findByModel(String code) {
		return Optional.of(
				Jpa	.getManager()
					.createNamedQuery("SparePart.findByModel", SparePart.class)
					.setParameter(1, code)
					.getResultList()
					.get(0));
	}


}
