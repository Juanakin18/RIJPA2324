package uo.ri.cws.infrastructure.persistence.jpa.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.TypedQuery;

import uo.ri.cws.application.repository.InvoiceRepository;
import uo.ri.cws.domain.Invoice;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;
import uo.ri.cws.infrastructure.persistence.jpa.util.Jpa;

public class InvoiceRepositoryImpl extends BaseJpaRepository<Invoice>
		implements InvoiceRepository {

	@Override
	public Optional<Invoice> findByNumber(Long numero) {
		return Optional.of(
				Jpa	.getManager()
					.createNamedQuery("Invoice.findByNumber", Invoice.class)
					.setParameter(1, numero)
					.getResultList()
					.get(0));
	}

	@Override
    public Long getNextInvoiceNumber() {
	// Comprobar que no hay un mecanico con el mismo dni
	TypedQuery<Long> tq = Jpa.getManager()
		.createNamedQuery("Invoice.getNextInvoiceNumber", Long.class);

	Long aux = null;
	// Obtenemos los resultados NO USAR getSingleResult()
	List<Long> result = tq.getResultList();

	if (!result.isEmpty())
	    aux = result.get(0);

	return aux;
    }

}
