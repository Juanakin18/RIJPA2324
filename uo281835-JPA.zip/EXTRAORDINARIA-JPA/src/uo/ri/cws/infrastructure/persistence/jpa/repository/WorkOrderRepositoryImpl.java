package uo.ri.cws.infrastructure.persistence.jpa.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.repository.WorkOrderRepository;
import uo.ri.cws.domain.WorkOrder;
import uo.ri.cws.domain.WorkOrder.WorkOrderState;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;
import uo.ri.cws.infrastructure.persistence.jpa.util.Jpa;

public class WorkOrderRepositoryImpl extends BaseJpaRepository<WorkOrder>
		implements WorkOrderRepository {

	@Override
	public List<WorkOrder> findNotInvoicedWorkOrdersByClientDni(String dni) {
		return Jpa	.getManager()
					.createNamedQuery("WorkOrder.findNotInvoicedByDni",
							WorkOrder.class)
					.setParameter(1, dni)
					.setParameter(2,WorkOrderState.FINISHED )
					.getResultList();
	}

	@Override
	public List<WorkOrder> findByMechanic(String mechanic_id) {
		return Jpa	.getManager()
					.createNamedQuery("WorkOrder.findByMechanic",
							WorkOrder.class)
					.setParameter(1, mechanic_id)
					.setParameter(2,WorkOrderState.FINISHED )
					.getResultList();
	}

	@Override
	public List<WorkOrder> findByIds(List<String> workOrderIds) {
		return Jpa	.getManager()
					.createNamedQuery("WorkOrder.findByIds", WorkOrder.class)
					.setParameter(1, workOrderIds)
					.getResultList();
	}

	
	@Override
	public List<WorkOrder> findNotInvoicedWorkOrdersByPlate(String dni) {
		return Jpa	.getManager()
				.createNamedQuery("WorkOrder.findNotInvoicedByPlate",
						WorkOrder.class)
				.setParameter(1, dni)
				.setParameter(2,WorkOrderState.FINISHED )
				.getResultList();
	}

	@Override
	public Optional<WorkOrder> findByDateAndVehicle(String plate, LocalDateTime date) {
		return Optional.of(
				Jpa	.getManager()
					.createNamedQuery("WorkOrder.findByDateAndVehicle", WorkOrder.class)
					.setParameter(1, plate)
					.setParameter(2, date)
					.setParameter(3,WorkOrderState.FINISHED )
					.getResultList()
					.get(0));
	}

	@Override
	public List<WorkOrder> findByVehicle(String id) {
		return Jpa	.getManager()
				.createNamedQuery("WorkOrder.findByVehicle",
						WorkOrder.class)
				.setParameter(1, id)
				.getResultList();
	}
}
