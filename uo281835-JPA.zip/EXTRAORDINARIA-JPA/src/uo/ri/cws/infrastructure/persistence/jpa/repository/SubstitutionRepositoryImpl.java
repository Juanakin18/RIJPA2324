package uo.ri.cws.infrastructure.persistence.jpa.repository;


import uo.ri.cws.application.repository.SubstitutionRepository;
import uo.ri.cws.domain.Substitution;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;

public class SubstitutionRepositoryImpl extends BaseJpaRepository<Substitution> implements SubstitutionRepository {


}
