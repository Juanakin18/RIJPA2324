package uo.ri.cws.infrastructure.persistence.jpa.repository;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.domain.Client;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;
import uo.ri.cws.infrastructure.persistence.jpa.util.Jpa;

public class ClientRepositoryImpl extends BaseJpaRepository<Client>
		implements ClientRepository {

	@Override
	public Optional<Client> findByDni(String dni) {
		return Optional.of(
				Jpa	.getManager()
					.createNamedQuery("Client.findByDni", Client.class)
					.setParameter(1, dni)
					.getSingleResult());

	}

	

	@Override
	public List<Client> findByName(String nombre) {
		return (
				Jpa	.getManager()
					.createNamedQuery("Client.findByName", Client.class)
					.setParameter(1, nombre)
					.getResultList());
	}

	@Override
	public List<Client> findBySurname(String nombre) {
		return (
				Jpa	.getManager()
					.createNamedQuery("Client.findBySurname", Client.class)
					.setParameter(1, nombre)
					.getResultList());
	}

}
