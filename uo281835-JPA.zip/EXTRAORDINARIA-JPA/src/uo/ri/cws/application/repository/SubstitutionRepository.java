package uo.ri.cws.application.repository;

import uo.ri.cws.domain.Substitution;

public interface SubstitutionRepository extends Repository<Substitution> {

}
