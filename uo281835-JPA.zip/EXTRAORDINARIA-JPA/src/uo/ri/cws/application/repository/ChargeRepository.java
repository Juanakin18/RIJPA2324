package uo.ri.cws.application.repository;

import uo.ri.cws.domain.Charge;

public interface ChargeRepository extends Repository<Charge> {

}
