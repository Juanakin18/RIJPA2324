package uo.ri.cws.application.service.workorder.view.commands;

import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.WorkOrderRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.util.assertion.ArgumentChecks;

public class FindByDni implements Command<List<WorkOrderDto>> {

	private String dni;
	private WorkOrderRepository repo = Factory.repository.forWorkOrder();
	
	public FindByDni(String readString) {
		ArgumentChecks.isNotBlank(readString);
		this.dni = readString;
	}

	@Override
	public List<WorkOrderDto> execute() throws BusinessException {
		return DtoAssembler.toWorkOrderDtoList(repo.findByMechanic(dni));
	}

}
