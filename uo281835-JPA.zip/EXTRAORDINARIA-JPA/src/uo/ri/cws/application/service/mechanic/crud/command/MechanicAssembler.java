package uo.ri.cws.application.service.mechanic.crud.command;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.domain.Mechanic;

public class MechanicAssembler {

	public static Optional<MechanicDto> toOptionalDto(Mechanic mecanico) {

		return Optional.of(DtoAssembler.toDto(mecanico));
	}

	public static List<MechanicDto> toDtoList(List<Mechanic> mecanico) {
		// TODO Auto-generated method stub
		return null;
	}

}
