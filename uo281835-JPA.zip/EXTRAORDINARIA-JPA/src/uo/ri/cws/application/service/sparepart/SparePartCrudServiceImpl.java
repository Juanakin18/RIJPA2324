package uo.ri.cws.application.service.sparepart;

import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.sparepart.crud.commands.AddSparePart;
import uo.ri.cws.application.service.sparepart.crud.commands.DeleteSparePart;
import uo.ri.cws.application.service.sparepart.crud.commands.FindAll;
import uo.ri.cws.application.service.sparepart.crud.commands.FindByCodigo;
import uo.ri.cws.application.service.sparepart.crud.commands.FindByDescription;
import uo.ri.cws.application.service.sparepart.crud.commands.UpdateSparePart;
import uo.ri.cws.application.util.command.CommandExecutor;

public class SparePartCrudServiceImpl implements SparePartCrudService {

	private CommandExecutor executor = Factory.executor.forExecutor();
	@Override
	public void addSparePart(SparePartDto dto) throws BusinessException{
		 executor.execute(new AddSparePart(dto));

	}

	@Override
	public void deleteSparePart(String dni) throws BusinessException{
		 executor.execute(new DeleteSparePart(dni));

	}

	@Override
	public void updateSparePart(SparePartDto dto) throws BusinessException{
		 executor.execute(new UpdateSparePart(dto));

	}

	@Override
	public List<SparePartDto> findAll() throws BusinessException{
		return executor.execute(new FindAll());
	}

	@Override
	public Optional<SparePartDto> findByCodigo(String nombre) throws BusinessException{
		return executor.execute(new FindByCodigo(nombre));
	}

	@Override
	public Optional<SparePartDto> findByModel(String nombre) throws BusinessException{
		return null;
	}

	@Override
	public Optional<SparePartDto> findByMarca(String nombre)throws BusinessException {
		return null;
	}

	@Override
	public Optional<SparePartDto> findByDescription(String nombre) throws BusinessException{
		return executor.execute(new FindByDescription(nombre));
	}

}
