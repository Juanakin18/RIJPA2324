package uo.ri.cws.application.service.vehicletype.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.VehicleTypeRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.vehicletype.VehicleTypeCrudService.VehicleTypeDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.VehicleType;
import uo.ri.util.assertion.ArgumentChecks;

public class FindVHId implements Command<Optional<VehicleTypeDto>> {

	private VehicleTypeRepository g = Factory.repository.forVehicleType();
	private String dni;
	public FindVHId(String dni) {
		ArgumentChecks.isNotBlank(dni);
		this.dni = dni;
	}

	@Override
	public Optional<VehicleTypeDto> execute() throws BusinessException {
		Optional<VehicleType> v = g.findById(dni);
		if(v.isEmpty())
			return Optional.empty();
		else
			return Optional.of(DtoAssembler.toDto(v.get()));
	}

}
