package uo.ri.cws.application.service.contract.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contract.ContractService.ContractDto;
import uo.ri.cws.application.service.contract.assembler.ContractAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.util.assertion.ArgumentChecks;

public class FindContractById implements Command<Optional<ContractDto>> {

	private String dto;
	private ContractRepository repo = Factory.repository.forContract(); 
	
	public FindContractById(String id) {
		ArgumentChecks.isNotNull(id);
		ArgumentChecks.isNotBlank(id);
		this.dto = id;
	}

	@Override
	public Optional<ContractDto> execute() throws BusinessException {
		Optional<Contract> c = repo.findById(dto);
		if(c.isEmpty())
			return Optional.empty();
		else
			return Optional.of(ContractAssembler.toDto(c.get()));
		
	}

}
