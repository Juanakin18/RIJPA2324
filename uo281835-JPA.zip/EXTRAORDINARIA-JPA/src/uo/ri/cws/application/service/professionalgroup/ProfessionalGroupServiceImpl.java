package uo.ri.cws.application.service.professionalgroup;

import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.professionalgroup.commands.AddProfessionalGroup;
import uo.ri.cws.application.service.professionalgroup.commands.DeleteProfessionalGroup;
import uo.ri.cws.application.service.professionalgroup.commands.FindAllProfessionalGroups;
import uo.ri.cws.application.service.professionalgroup.commands.FindProfessionalGroupById;
import uo.ri.cws.application.service.professionalgroup.commands.FindProfessionalGroupByName;
import uo.ri.cws.application.service.professionalgroup.commands.UpdateProfessionalGroup;
import uo.ri.cws.application.util.command.CommandExecutor;

public class ProfessionalGroupServiceImpl implements ProfessionalGroupService {

	private CommandExecutor executor = Factory.executor.forExecutor();

	@Override
	public ProfessionalGroupBLDto addProfessionalGroup(ProfessionalGroupBLDto dto) throws BusinessException {
		return executor.execute(new AddProfessionalGroup(dto));
	}

	@Override
	public void deleteProfessionalGroup(String name) throws BusinessException {
		 executor.execute(new DeleteProfessionalGroup(name));

	}

	@Override
	public void updateProfessionalGroup(ProfessionalGroupBLDto dto) throws BusinessException {
		 executor.execute(new UpdateProfessionalGroup(dto));

	}

	@Override
	public Optional<ProfessionalGroupBLDto> findProfessionalGroupByName(String id) throws BusinessException {
		return executor.execute(new FindProfessionalGroupByName(id));
	}

	@Override
	public List<ProfessionalGroupBLDto> findAllProfessionalGroups() throws BusinessException {
		return executor.execute(new FindAllProfessionalGroups());
	}

	@Override
	public Optional<ProfessionalGroupBLDto> findProfessionalGroupById(String id) throws BusinessException {
		return executor.execute(new FindProfessionalGroupById(id));
	}

}
