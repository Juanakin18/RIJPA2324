package uo.ri.cws.application.service.client.crud.commands;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Client;
import uo.ri.util.assertion.ArgumentChecks;


public class AddClient implements Command<ClientDto> {

	private ClientRepository gtw = Factory.repository.forClient();
	private ClientDto client;
	public AddClient(ClientDto client, String recommenderId) {
		ArgumentChecks.isNotNull(client);
		ArgumentChecks.isNotEmpty(recommenderId);
		this.client = client;
	}

	public AddClient(ClientDto client2) {
		ArgumentChecks.isNotNull(client);
		this.client = client2;
	}

	@Override
	public ClientDto execute() throws BusinessException {
		checkNotExists();
		Client c = new Client(client.dni,client.name, client.surname);
		gtw.add(c);
		return client;
	}

	private void checkNotExists() throws BusinessException {
		if(gtw.findById(client.id).isPresent())
			throw new BusinessException("DNI repetido");
		
	}

}
