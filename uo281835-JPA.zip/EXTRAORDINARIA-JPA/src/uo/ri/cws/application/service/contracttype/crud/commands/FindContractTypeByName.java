package uo.ri.cws.application.service.contracttype.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractTypeRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contracttype.ContractTypeService.ContractTypeDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.util.assertion.ArgumentChecks;

public class FindContractTypeByName
		implements Command<Optional<ContractTypeDto>> {

	private String name;
	private ContractTypeRepository gtw = Factory.repository.forContractType();
	private Optional<ContractTypeDto> result;

	public FindContractTypeByName(String name) {
		ArgumentChecks.isNotEmpty(name);
		ArgumentChecks.isNotBlank(name);
		ArgumentChecks.isNotEmpty(name, "El nombre est� vac�o");
		this.name = name;

	}

	@Override
	public Optional<ContractTypeDto> execute() throws BusinessException {

		if (gtw.findByName(name).isEmpty()) {
			result = Optional.empty();
		}

		else {
			ContractTypeDto dto = DtoAssembler.toDto(
					gtw.findByName(name).get());
			result = Optional.of(dto);
		}
		return result;

	}

	public Optional<ContractTypeDto> get() {
		return result;
	}

}
