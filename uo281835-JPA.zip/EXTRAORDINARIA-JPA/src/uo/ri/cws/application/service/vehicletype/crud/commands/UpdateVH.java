package uo.ri.cws.application.service.vehicletype.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.VehicleTypeRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.vehicletype.VehicleTypeCrudService.VehicleTypeDto;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.VehicleType;
import uo.ri.util.assertion.ArgumentChecks;

public class UpdateVH implements Command<Void> {

	private VehicleTypeRepository g = Factory.repository.forVehicleType();
	private VehicleTypeDto dto;
	public UpdateVH(VehicleTypeDto dto) {
		ArgumentChecks.isNotNull(dto);
		ArgumentChecks.isNotBlank(dto.name, "El nombre no puede ser nulo");
		this.dto = dto;
	}

	@Override
	public Void execute() throws BusinessException {
		Optional<VehicleType> v = g.findByName(dto.name);
		if(v.isEmpty())
			throw new BusinessException("El tipo no existe");
		else {
			VehicleType vt = v.get();
			vt.setPricePerHour(dto.pricePerHour);
		}
		return null;
	}

}
