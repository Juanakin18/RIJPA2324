package uo.ri.cws.application.service.payroll.crud.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ProfessionalGroupRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.payroll.PayrollService.PayrollSummaryBLDto;
import uo.ri.cws.application.service.payroll.assembler.PayrollAssembler;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.cws.domain.Payroll;
import uo.ri.cws.domain.ProfessionalGroup;
import uo.ri.util.assertion.ArgumentChecks;


public class GetAllPayrollsForProfessionalGroup implements Command<List<PayrollSummaryBLDto>> {

	private String name;
	private ProfessionalGroupRepository pg = Factory.repository.forProfessionalGroup();
	public GetAllPayrollsForProfessionalGroup(String string) {
		ArgumentChecks.isNotNull(string, "The group id can't be null");
		ArgumentChecks.isNotEmpty(string, "The group id can't be empty");
		ArgumentChecks.isNotBlank(string, "The group can't be blank");
		
		this.name = string;
	}

	@Override
	public List<PayrollSummaryBLDto> execute() throws BusinessException {
		Optional<ProfessionalGroup> group = pg.findByName(name);
		BusinessChecks.isTrue(group.isPresent(), "group must exist");
		List<Contract> contracts = new ArrayList<>(group.get().getContracts());
		List<Payroll> payrolls = new ArrayList<>();
		for (Contract c : contracts) {
		    List<Payroll> pC = new ArrayList<>(c.getPayrolls());
		    for (Payroll p : pC) {
			payrolls.add(p);
		    }
		}
		return PayrollAssembler.toBlSummaryDtoList(payrolls);

	}
	

}
