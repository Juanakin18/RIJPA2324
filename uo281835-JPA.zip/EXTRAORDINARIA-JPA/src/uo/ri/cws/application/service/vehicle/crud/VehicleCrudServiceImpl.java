package uo.ri.cws.application.service.vehicle.crud;

import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.vehicle.VehicleCrudService;
import uo.ri.cws.application.service.vehicle.crud.commands.AddVehicle;
import uo.ri.cws.application.service.vehicle.crud.commands.FindAllVehicles;
import uo.ri.cws.application.service.vehicle.crud.commands.FindVehicleByDni;
import uo.ri.cws.application.service.vehicle.crud.commands.FindVehicleByPlate;
import uo.ri.cws.application.service.vehicle.crud.commands.RemoveVehicle;
import uo.ri.cws.application.service.vehicle.crud.commands.UpdateVehicle;
import uo.ri.cws.application.util.command.CommandExecutor;

public class VehicleCrudServiceImpl implements VehicleCrudService {

	private CommandExecutor executor = Factory.executor.forExecutor();

	@Override
	public Optional<VehicleDto> findVehicleByPlate(String plate)
			throws BusinessException {
		return executor.execute(new FindVehicleByPlate(plate));
	}

	@Override
	public List<VehicleDto> findVehicleByDni(String dni)  throws BusinessException {
		return executor.execute(new FindVehicleByDni(dni));
	}

	@Override
	public void addVehicle(VehicleDto dto)throws BusinessException  {
		 executor.execute(new AddVehicle(dto));
	}

	@Override
	public void updateVehicle(VehicleDto dto)throws BusinessException  {
		 executor.execute(new UpdateVehicle(dto));
	}

	@Override
	public List<VehicleDto> findAll() throws BusinessException {
		return executor.execute(new FindAllVehicles());
	}

	@Override
	public void removeVehicle(String plate)throws BusinessException  {
		 executor.execute(new RemoveVehicle(plate));
		
	}

}
