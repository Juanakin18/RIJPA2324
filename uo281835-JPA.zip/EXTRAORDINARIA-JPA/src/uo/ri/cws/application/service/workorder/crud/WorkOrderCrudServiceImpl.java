package uo.ri.cws.application.service.workorder.crud;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.intervention.InterventionService.InterventionDto;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService;
import uo.ri.cws.application.service.workorder.crud.commands.AddInterventionToAWorkOrder;
import uo.ri.cws.application.service.workorder.crud.commands.AddWorkOrder;
import uo.ri.cws.application.service.workorder.crud.commands.DeleteWorkOrder;
import uo.ri.cws.application.service.workorder.crud.commands.FindAllWO;
import uo.ri.cws.application.service.workorder.crud.commands.FindWorkorderByDateAndVehicle;
import uo.ri.cws.application.service.workorder.crud.commands.FindWorkorderByID;
import uo.ri.cws.application.service.workorder.crud.commands.FindWorkordersByDni;
import uo.ri.cws.application.service.workorder.crud.commands.FindWorkordersByVehicle;
import uo.ri.cws.application.service.workorder.crud.commands.UpdateWorkOrder;
import uo.ri.cws.application.util.command.CommandExecutor;

public class WorkOrderCrudServiceImpl implements WorkOrderCrudService {

	private CommandExecutor executor = Factory.executor.forExecutor();
	@Override
	public List<WorkOrderDto> findWorkordersByVehicle(String plate) throws BusinessException {
		return executor.execute(new FindWorkordersByVehicle(plate));
	}

	@Override
	public List<WorkOrderDto> findAllWO() throws BusinessException {
		return executor.execute(new FindAllWO());
	}

	@Override
	public void addWorkOrder(WorkOrderDto dto) throws BusinessException {
		 executor.execute(new AddWorkOrder(dto));
	}

	@Override
	public void deleteWorkOrder(String dto) throws BusinessException {
		 executor.execute(new DeleteWorkOrder(dto));
	}

	@Override
	public void updateWorkOrder(WorkOrderDto dto) throws BusinessException {
		 executor.execute(new UpdateWorkOrder(dto));
	}

	

	@Override
	public Optional<WorkOrderDto> findWorkorderByID(String id) throws BusinessException{
		return executor.execute(new FindWorkorderByID(id));
	}

	@Override
	public Optional<WorkOrderDto> findWorkorderByDateAndVehicle(String plateNumber, LocalDateTime date) throws BusinessException{
		return executor.execute(new FindWorkorderByDateAndVehicle(plateNumber, date));
	}

	@Override
	public List<WorkOrderDto> findWorkOrdersByDni(String readString) throws BusinessException{
		return executor.execute(new FindWorkordersByDni(readString));
	}

	@Override
	public void addInterventionToAWorkOrder(String workOrderId, InterventionDto idto) throws BusinessException{
		 executor.execute(new AddInterventionToAWorkOrder(workOrderId, idto));

	}

}
