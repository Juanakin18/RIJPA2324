package uo.ri.cws.application.service.voucher;

import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.paymentmean.VoucherService;
import uo.ri.cws.application.service.voucher.commands.FindVouchersByClientId;
import uo.ri.cws.application.service.voucher.commands.FindVouchersById;
import uo.ri.cws.application.service.voucher.commands.GetVoucherSummary;
import uo.ri.cws.application.util.command.CommandExecutor;

public class VoucherServiceImpl implements VoucherService {

	private CommandExecutor exe = Factory.executor.forExecutor();

	@Override
	public int generateVouchers() throws BusinessException {
		return 0;
	}

	@Override
	public Optional<VoucherDto> findVouchersById(String id) throws BusinessException {
		return exe.execute(new FindVouchersById(id));
	}

	@Override
	public List<VoucherDto> findVouchersByClientId(String id) throws BusinessException {
		return exe.execute(new FindVouchersByClientId(id));
		
	}

	@Override
	public List<VoucherSummaryDto> getVoucherSummary() throws BusinessException {
		return exe.execute(new GetVoucherSummary());
		
	}

}
