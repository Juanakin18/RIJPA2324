package uo.ri.cws.application.service.workorder.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.WorkOrderRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.WorkOrder;
import uo.ri.util.assertion.ArgumentChecks;

public class DeleteWorkOrder implements Command<Void> {
	private WorkOrderRepository repo = Factory.repository.forWorkOrder();
	private String wid;
	public DeleteWorkOrder(String dto) {
		ArgumentChecks.isNotBlank(dto);
		this.wid = dto;
	}

	@Override
	public Void execute() throws BusinessException {
		Optional<WorkOrder> w = repo.findById(wid);
		if(w.isEmpty())
			throw new BusinessException("No existe esa workorder");
		repo.remove(w.get());
		return null;
	}

}
