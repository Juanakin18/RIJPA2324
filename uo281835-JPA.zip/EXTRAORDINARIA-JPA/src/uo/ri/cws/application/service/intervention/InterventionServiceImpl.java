package uo.ri.cws.application.service.intervention;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.intervention.commands.AddIntervention;
import uo.ri.cws.application.service.intervention.commands.AddSubstitutionToIntervention;
import uo.ri.cws.application.util.command.CommandExecutor;

public class InterventionServiceImpl implements InterventionService {


	private CommandExecutor executor = Factory.executor.forExecutor();
	@Override
	public void addIntervention(InterventionDto idto) throws BusinessException {
		 executor.execute(new AddIntervention(idto));
		
	}

	@Override
	public void addSubstitutionToIntervention(SubstitutionDto sub, InterventionDto idto) throws BusinessException{
		 executor.execute(new AddSubstitutionToIntervention(sub, idto));
	}

}
