package uo.ri.cws.application.service.workorder.closew;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.workorder.CloseWorkOrderService;
import uo.ri.cws.application.service.workorder.close.commands.CloseWorkOrder;
import uo.ri.cws.application.util.command.CommandExecutor;

public class CloseWorkOrderServiceImpl implements CloseWorkOrderService {

	private CommandExecutor executor = Factory.executor.forExecutor();
	@Override
	public void close(String id) throws BusinessException{
		 executor.execute(new CloseWorkOrder(id));

	}

}
