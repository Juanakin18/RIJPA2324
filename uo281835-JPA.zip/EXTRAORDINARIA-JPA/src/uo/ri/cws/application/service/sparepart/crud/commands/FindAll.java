package uo.ri.cws.application.service.sparepart.crud.commands;

import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.SparePartRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.sparepart.SparePartDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;

public class FindAll implements Command<List<SparePartDto>> {


	private SparePartRepository gtw = Factory.repository.forSparePart();
	
	@Override
	public List<SparePartDto> execute() throws BusinessException {
		return DtoAssembler.toSparePartDtoList(gtw.findAll());
	}

}
