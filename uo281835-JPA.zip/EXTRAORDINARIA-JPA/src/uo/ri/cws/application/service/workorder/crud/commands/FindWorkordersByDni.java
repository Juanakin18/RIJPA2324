package uo.ri.cws.application.service.workorder.crud.commands;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.MechanicRepository;
import uo.ri.cws.application.repository.WorkOrderRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Mechanic;
import uo.ri.util.assertion.ArgumentChecks;

public class FindWorkordersByDni implements Command<List<WorkOrderDto>> {

	public FindWorkordersByDni(String object) {
		ArgumentChecks.isNotBlank(object);
		ArgumentChecks.isNotNull(date);
		this.dni = object;
	}

	
	
	private String dni;
	private LocalDateTime date;
	private WorkOrderRepository repo = Factory.repository.forWorkOrder();
	private MechanicRepository mrepo = Factory.repository.forMechanic();
	

	@Override
	public List<WorkOrderDto> execute() throws BusinessException {
		Optional<Mechanic> w = mrepo.findByDni(dni);
		if(w.isEmpty())
			throw new BusinessException("No existe el mecánico");
		return (DtoAssembler.toWorkOrderDtoList(repo.findByMechanic(dni)));
	}


}
