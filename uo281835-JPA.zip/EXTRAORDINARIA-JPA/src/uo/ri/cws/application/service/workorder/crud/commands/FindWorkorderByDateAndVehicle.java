package uo.ri.cws.application.service.workorder.crud.commands;

import java.time.LocalDateTime;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.WorkOrderRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.WorkOrder;
import uo.ri.util.assertion.ArgumentChecks;

public class FindWorkorderByDateAndVehicle implements Command<Optional<WorkOrderDto>> {

	private String plate;
	private LocalDateTime date;
	private WorkOrderRepository repo = Factory.repository.forWorkOrder();
	
	public FindWorkorderByDateAndVehicle(String plateNumber, LocalDateTime date) {
		ArgumentChecks.isNotBlank(plateNumber);
		ArgumentChecks.isNotNull(date);
		this.plate = plateNumber;
		this.date = date;
	}

	@Override
	public Optional<WorkOrderDto> execute() throws BusinessException {
		Optional<WorkOrder> w = repo.findByDateAndVehicle(plate, date);
		if(w.isEmpty())
			return Optional.empty();
		return Optional.of(DtoAssembler.toDto(w.get()));
	}

}
