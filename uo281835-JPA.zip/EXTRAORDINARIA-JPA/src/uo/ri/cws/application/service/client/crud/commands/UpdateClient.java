package uo.ri.cws.application.service.client.crud.commands;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Address;
import uo.ri.cws.domain.Client;
import uo.ri.util.assertion.ArgumentChecks;

public class UpdateClient implements Command<Void> {
	private ClientRepository gtw = Factory.repository.forClient();
	private ClientDto client;
	public UpdateClient(ClientDto client) {
		ArgumentChecks.isNotNull(client);
		this.client=client;
	}

	@Override
	public Void execute() throws BusinessException {
		Client c = gtw.findById(client.id).get();
		BusinessChecks.hasVersion(c, client.version);
		c.setName(client.name);
		c.setSurname(client.surname);
		c.setEmail(client.email);
		c.setAddress(new Address(client.addressCity, client.addressStreet, client.addressZipcode));
		return null;
	}
}