package uo.ri.cws.application.service.mechanic.crud.command;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.MechanicRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Mechanic;
import uo.ri.util.assertion.ArgumentChecks;

public class AddMechanic implements Command<MechanicDto> {

	private MechanicDto dto;
	private MechanicRepository repositorio = Factory.repository.forMechanic();

	public AddMechanic(MechanicDto dto) {
		ArgumentChecks.isNotNull(dto, "The mechanic can't be null");
		ArgumentChecks.isNotNull(dto.dni, "The mechanic dni can't be null");
		ArgumentChecks.isNotEmpty(dto.dni, "The mechanic dni can't be empty");
		ArgumentChecks.isNotBlank(dto.dni, "The mechanic dni can't be blank");
		ArgumentChecks.isNotNull(dto.name, "The mechanic name can't be null");
		ArgumentChecks.isNotEmpty(dto.name, "The mechanic name can't be empty");
		ArgumentChecks.isNotBlank(dto.name, "The mechanic name can't be blank");
		ArgumentChecks.isNotNull(dto.surname,
			"The mechanic surname can't be null");
		ArgumentChecks.isNotEmpty(dto.surname,
			"The mechanic surname can't be empty");
		ArgumentChecks.isNotBlank(dto.surname,
			"The mechanic surname can't be blank");
		this.dto = dto;
		
	}

	public MechanicDto execute() throws BusinessException {
		Optional<Mechanic> m = repositorio.findByDni(dto.dni);
		if (m.isPresent())
			throw new BusinessException("Ya existe ese DNI");
		Mechanic mecanico = new Mechanic(dto.dni, dto.name, dto.surname);
		dto.id = mecanico.getId();
		repositorio.add(mecanico);
		return dto;
	}

}
