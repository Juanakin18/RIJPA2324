package uo.ri.cws.application.service.invoice.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.InvoiceRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.invoice.InvoicingService.InvoiceDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Invoice;
import uo.ri.util.assertion.ArgumentChecks;

public class FindByNumber implements Command<Optional<InvoiceDto>> {

	private InvoiceRepository rep = Factory.repository.forInvoice();
	private long number;

	public FindByNumber(Long number) {
		ArgumentChecks.isTrue(number >= 0);
		this.number = number;
	}

	@Override
	public Optional<InvoiceDto> execute() throws BusinessException {
		Optional<Invoice> in = rep.findByNumber(number);
		if (in.isEmpty())
			return Optional.empty();

		return Optional.of(DtoAssembler.toDto(in.get()));
	}

}
