package uo.ri.cws.application.service.payroll.crud.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.MechanicRepository;
import uo.ri.cws.application.repository.PayrollRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Mechanic;
import uo.ri.cws.domain.Payroll;
import uo.ri.util.assertion.ArgumentChecks;

public class DeleteLastPayrollFor implements Command<Void> {
 
	private PayrollRepository payrollrepo = Factory.repository.forPayroll();
	private MechanicRepository mrepo = Factory.repository.forMechanic();
	
	private String dni ;
	public DeleteLastPayrollFor(String dni) {
		ArgumentChecks.isNotNull(dni, "The mechanic id can't be null");
		ArgumentChecks.isNotEmpty(dni, "The mechanic id can't be empty");
		ArgumentChecks.isNotBlank(dni, "The id can't be blank");
		this.dni = dni;
	}

	 @Override
	    public Void execute() throws BusinessException {
		Optional<Mechanic> mechanic = mrepo.findById(dni);
		BusinessChecks.isTrue(mechanic.isPresent(), "mechanic must exist");
		List<Payroll> payrolls = new ArrayList<>(
			mechanic.get().getContractInForce().get().getPayrolls());
		if (!payrolls.isEmpty())
		    deleteLastPayrolls(payrolls);
		return null;
	    }

	    private void deleteLastPayrolls(List<Payroll> payrolls) {
		Payroll last = findLastPayroll(payrolls);
		for (Payroll p : payrolls) {
		    if (p.getDate().getMonthValue() == last.getDate().getMonthValue()
			    && p.getDate().getYear() == last.getDate().getYear()) {
			payrollrepo.remove(p);
		    }
		}
	    }

	    private Payroll findLastPayroll(List<Payroll> payrolls) {
		Payroll payroll = payrolls.get(0);
		for (int i = 1; i < payrolls.size(); i++) {
		    Payroll p = payrolls.get(i);
		    if (p.getDate().compareTo(payroll.getDate()) > 0)
			payroll = p;
		}
		return payroll;
	    }
	

}
