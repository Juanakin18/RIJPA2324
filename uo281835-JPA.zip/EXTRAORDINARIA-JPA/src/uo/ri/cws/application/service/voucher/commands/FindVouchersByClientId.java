package uo.ri.cws.application.service.voucher.commands;

import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.paymentmean.VoucherService.VoucherDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.util.assertion.ArgumentChecks;

public class FindVouchersByClientId implements Command<List<VoucherDto>> {

	private String id;
	private PaymentMeanRepository repo = Factory.repository.forPaymentMean();
	public FindVouchersByClientId(String id) {
		ArgumentChecks.isNotBlank(id);
		this.id = id;
	}

	@Override
	public List<VoucherDto> execute() throws BusinessException {
		return DtoAssembler.toVoucherDtoList(repo.findVoucherByClientId(id));
	}

}
