package uo.ri.cws.application.service.client.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.util.assertion.ArgumentChecks;

public class FindClientsById implements Command<Optional<ClientDto>> {

	private String idClient; 
	private ClientRepository gtw = Factory.repository.forClient();
	public FindClientsById(String idClient) {
		ArgumentChecks.isNotEmpty(idClient);
		this.idClient = idClient;
	}

	@Override
	public Optional<ClientDto> execute() throws BusinessException {
		return Optional.of( DtoAssembler.toDto(gtw.findById(idClient).get()));
	}
 
}
