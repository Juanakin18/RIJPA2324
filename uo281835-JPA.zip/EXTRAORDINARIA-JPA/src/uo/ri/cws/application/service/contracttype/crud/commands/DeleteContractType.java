package uo.ri.cws.application.service.contracttype.crud.commands;

import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.repository.ContractTypeRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contract.ContractService.ContractDto;
import uo.ri.cws.application.service.contract.ContractService.ContractState;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.cws.domain.ContractType;
import uo.ri.util.assertion.ArgumentChecks;

public class DeleteContractType implements Command<Void> {
	private String name;
	private ContractTypeRepository gtw = Factory.repository.forContractType();
	private ContractRepository cgtw = Factory.repository.forContract();

	public DeleteContractType(String name) {
		ArgumentChecks.isNotNull(name);
		ArgumentChecks.isNotBlank(name);
		ArgumentChecks.isNotEmpty(name, "El nombre est� vac�o");
		this.name = name;
	}

	@Override
	public Void execute() throws BusinessException {
		ContractType c = checkIfExists(name);
		checkIfHasContracts(name);
		checkIfHasContractsTerminated(name);
		gtw.remove(c);
		return null;
	}

	private void checkIfHasContractsTerminated(String name2)
			throws BusinessException {
		List<ContractDto> dtos = DtoAssembler.toContractDtoList(
				cgtw.findTerminated());
		for (ContractDto dto : dtos) {
			if (dto.state != ContractState.TERMINATED)
				throw new BusinessException("Tiene contratos no terminados");
		}

	}

	private void checkIfHasContracts(String name2) throws BusinessException {
		List<Contract> c = cgtw.findByContractTypeId(name2);
		BusinessChecks.isTrue(c.size()==0);
	
	}

	private ContractType checkIfExists(String name2) throws BusinessException {
		Optional<ContractType> c = gtw.findByName(name2);
		if (c.isEmpty())
			throw new BusinessException("No existe ese tipo de contrato");
		return c.get();

	}

}
