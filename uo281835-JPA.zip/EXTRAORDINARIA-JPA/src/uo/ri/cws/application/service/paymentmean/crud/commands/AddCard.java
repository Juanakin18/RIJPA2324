package uo.ri.cws.application.service.paymentmean.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.paymentmean.PaymentMeanCrudService.CardDto;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.CreditCard;
import uo.ri.util.assertion.ArgumentChecks;

public class AddCard implements Command<CardDto> {

	private PaymentMeanRepository rep = Factory.repository.forPaymentMean();

	private CardDto dto;

	public AddCard(CardDto card) {
		ArgumentChecks.isNotNull(card);
		this.dto = card;
	}

	@Override
	public CardDto execute() throws BusinessException {
		Optional<CreditCard> a = rep.findCreditCardByNumber(dto.cardNumber);
		if (!a.isEmpty())
			throw new BusinessException("Esa tarjeta ya existe");
		CreditCard c = new CreditCard(dto.cardNumber, dto.cardType,
				dto.cardExpiration);
		rep.add(c);
		return null;
	}

}
