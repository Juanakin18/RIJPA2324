package uo.ri.cws.application.service.client.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.VehicleRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Client;
import uo.ri.cws.domain.Vehicle;
import uo.ri.util.assertion.ArgumentChecks;

public class FindClientsByPlate implements Command<Optional<ClientDto>> {

	private String nombre;
	private VehicleRepository rgtw = Factory.repository.forVehicle();
	
	public FindClientsByPlate(String nombre) {
		ArgumentChecks.isNotNull(nombre);
		ArgumentChecks.isNotBlank(nombre);
		this.nombre = nombre;
	}

	@Override
	public Optional<ClientDto> execute() throws BusinessException {
		Optional<Vehicle> v = rgtw.findByPlate(nombre);
		if(v.isPresent()) {
			Client c = (v.get().getClient());
			return Optional.of(DtoAssembler.toDto(c));
		}else {
			throw new BusinessException("No existe ese vehículo");
		}
		
	}

}
