package uo.ri.cws.application.service.contract.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contract.ContractService.ContractState;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.cws.domain.Mechanic;
import uo.ri.cws.domain.Payroll;
import uo.ri.cws.domain.WorkOrder;
import uo.ri.util.assertion.ArgumentChecks;

public class DeleteContract implements Command<Void> {
	private String id;
	private ContractRepository repo = Factory.repository.forContract(); 
	
	public DeleteContract(String id) {
		ArgumentChecks.isNotNull(id);
		ArgumentChecks.isNotBlank(id);
		this.id = id;
	}

	@Override
	public Void execute() throws BusinessException {
		Optional<Contract> c = repo.findById(id);
		BusinessChecks.exists(c);
		if(c.get().getState() == ContractState.TERMINATED) {
			repo.remove(c.get());
		}else {
		Optional<Mechanic> m = c.get().getMechanic();
		List<Payroll> pay = new ArrayList<>(c.get().getPayrolls());
		BusinessChecks.isTrue(pay.isEmpty());
		checkWorkOrders(m.get(), c.get());
		repo.remove(c.get());
		}
		/*if (c.isPresent()) {
			if(checkMechanic(c.get())) {
				repo.remove(c.get());
			}
		}else {
			throw new BusinessException("Ese contrato no existe");
		}*/
		return null;
	}

	

	private boolean checkWorkOrders(Mechanic m, Contract c) throws BusinessException {
		Set<WorkOrder> wo = m.getAssigned();
		for(WorkOrder w : wo) {
			if(w.getDate().isAfter(c.getStartDate().atStartOfDay()) && 
					w.getDate().isBefore(c.getEndDate().get().atStartOfDay())) {
				throw new BusinessException("Tiene workorders");
			}
		}
		return false;
	}

}
