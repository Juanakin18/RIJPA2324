package uo.ri.cws.application.service.mechanic.crud.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.MechanicRepository;
import uo.ri.cws.application.repository.ProfessionalGroupRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Mechanic;
import uo.ri.cws.domain.ProfessionalGroup;
import uo.ri.util.assertion.ArgumentChecks;

public class FindMechanicsInProfessionalGroups
		implements Command<List<MechanicDto>> {

	private MechanicRepository mr = Factory.repository.forMechanic();
	private ProfessionalGroupRepository p = Factory.repository.forProfessionalGroup();
	private String name;

	@Override
	public List<MechanicDto> execute() throws BusinessException {
		List<MechanicDto> dtos = new ArrayList<>();
		Optional<ProfessionalGroup> pro = p.findByName(name);
		if (pro.isEmpty())
			return dtos;
		for (Mechanic m : mr.findAllInProfessionalGroup(pro.get())) {
			dtos.add(DtoAssembler.toDto(m));
		}
		return dtos;
	}

	public FindMechanicsInProfessionalGroups(String name) {
		ArgumentChecks.isNotNull(name, "The group can't be null");
		ArgumentChecks.isNotEmpty(name, "The group can't be empty");
		ArgumentChecks.isNotBlank(name, "The group can't be blank");
		this.name = name;
	}

}
