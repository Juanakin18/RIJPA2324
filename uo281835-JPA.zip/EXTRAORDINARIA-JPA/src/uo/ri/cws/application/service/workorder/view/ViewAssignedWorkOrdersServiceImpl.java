package uo.ri.cws.application.service.workorder.view;

import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.workorder.ViewAssignedWorkOrdersService;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;
import uo.ri.cws.application.service.workorder.view.commands.FindByDni;
import uo.ri.cws.application.util.command.CommandExecutor;

public class ViewAssignedWorkOrdersServiceImpl implements ViewAssignedWorkOrdersService {

	private CommandExecutor executor = Factory.executor.forExecutor();
	@Override
	public List<WorkOrderDto> findByDni(String readString) throws BusinessException {
		return executor.execute(new FindByDni(readString));
	}

}
