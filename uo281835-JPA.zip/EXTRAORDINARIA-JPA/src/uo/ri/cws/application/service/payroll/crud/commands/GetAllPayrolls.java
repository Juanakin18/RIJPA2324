package uo.ri.cws.application.service.payroll.crud.commands;

import java.util.ArrayList;
import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.PayrollRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.payroll.PayrollService.PayrollSummaryBLDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Payroll;


public class GetAllPayrolls implements Command<List<PayrollSummaryBLDto>>{

	private PayrollRepository pgtw = Factory.repository.forPayroll();
	@Override
	public List<PayrollSummaryBLDto> execute() throws BusinessException {
		
		return toPayrollSummaryDto( pgtw.findAll());
	}
	private List<PayrollSummaryBLDto> toPayrollSummaryDto(List<Payroll> list) {
		List<PayrollSummaryBLDto> result = new ArrayList<PayrollSummaryBLDto>();
		PayrollSummaryBLDto psdto;
		for(Payroll dto : list) {
			psdto = DtoAssembler.toPayrollSummaryDto(dto);
			result.add(psdto);
		}
		return result;
	}

}
