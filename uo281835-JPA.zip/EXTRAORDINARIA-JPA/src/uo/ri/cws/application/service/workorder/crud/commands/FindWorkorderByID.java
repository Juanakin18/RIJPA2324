package uo.ri.cws.application.service.workorder.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.WorkOrderRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.WorkOrder;
import uo.ri.util.assertion.ArgumentChecks;

public class FindWorkorderByID implements Command<Optional<WorkOrderDto>> {

	public FindWorkorderByID(String id) {
		ArgumentChecks.isNotBlank(id);
		this.id = id;
	}

	
	private String id;
	private WorkOrderRepository repo = Factory.repository.forWorkOrder();
	

	@Override
	public Optional<WorkOrderDto> execute() throws BusinessException {
		Optional<WorkOrder> w = repo.findById(id);
		if(w.isEmpty())
			return Optional.empty();
		return Optional.of(DtoAssembler.toDto(w.get()));
	}

}
