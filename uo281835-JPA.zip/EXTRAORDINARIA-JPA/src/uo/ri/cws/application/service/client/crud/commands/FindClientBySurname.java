package uo.ri.cws.application.service.client.crud.commands;

import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.util.assertion.ArgumentChecks;

public class FindClientBySurname implements Command<List<ClientDto>> {

	private String nombre;
	private ClientRepository gtw = Factory.repository.forClient();
	
	public FindClientBySurname(String surname) {
		ArgumentChecks.isNotNull(surname);
		ArgumentChecks.isNotBlank(surname);
		this.nombre = surname;
	}

	@Override
	public List<ClientDto> execute() throws BusinessException {
		 return DtoAssembler.toClientDtoList(gtw.findBySurname(nombre));
	}

}
