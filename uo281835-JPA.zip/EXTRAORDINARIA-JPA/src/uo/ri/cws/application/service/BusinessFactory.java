package uo.ri.cws.application.service;

import uo.ri.cws.application.ServiceFactory;
import uo.ri.cws.application.service.client.ClientCrudService;
import uo.ri.cws.application.service.client.ClientHistoryService;
import uo.ri.cws.application.service.client.crud.ClientHistoryServiceImpl;
import uo.ri.cws.application.service.client.crud.ClientServiceImpl;
import uo.ri.cws.application.service.contract.ContractService;
import uo.ri.cws.application.service.contract.ContractServiceImpl;
import uo.ri.cws.application.service.contracttype.ContractTypeService;
import uo.ri.cws.application.service.contracttype.crud.ContractTypeServiceImpl;
import uo.ri.cws.application.service.intervention.InterventionService;
import uo.ri.cws.application.service.intervention.InterventionServiceImpl;
import uo.ri.cws.application.service.invoice.InvoicingService;
import uo.ri.cws.application.service.invoice.crud.InvoicingServiceImpl;
import uo.ri.cws.application.service.mechanic.MechanicCrudService;
import uo.ri.cws.application.service.mechanic.crud.MechanicCrudServiceImpl;
import uo.ri.cws.application.service.payroll.PayrollService;
import uo.ri.cws.application.service.payroll.crud.PayrollServiceImpl;
import uo.ri.cws.application.service.professionalgroup.ProfessionalGroupService;
import uo.ri.cws.application.service.professionalgroup.ProfessionalGroupServiceImpl;
import uo.ri.cws.application.service.sparepart.SparePartCrudService;
import uo.ri.cws.application.service.sparepart.SparePartCrudServiceImpl;
import uo.ri.cws.application.service.vehicle.VehicleCrudService;
import uo.ri.cws.application.service.vehicle.crud.VehicleCrudServiceImpl;
import uo.ri.cws.application.service.vehicletype.VehicleTypeCrudService;
import uo.ri.cws.application.service.vehicletype.crud.VehicleTypeServiceImpl;
import uo.ri.cws.application.service.workorder.CloseWorkOrderService;
import uo.ri.cws.application.service.workorder.ViewAssignedWorkOrdersService;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService;
import uo.ri.cws.application.service.workorder.closew.CloseWorkOrderServiceImpl;
import uo.ri.cws.application.service.workorder.crud.WorkOrderCrudServiceImpl;
import uo.ri.cws.application.service.workorder.view.ViewAssignedWorkOrdersServiceImpl;

public class BusinessFactory implements ServiceFactory {

	@Override
	public MechanicCrudService forMechanicCrudService() {
		return new MechanicCrudServiceImpl();
	}

	@Override
	public InvoicingService forCreateInvoiceService() {
		return new InvoicingServiceImpl();
	}

	@Override
	public VehicleCrudService forVehicleCrudService() {
		return new VehicleCrudServiceImpl();
	}

	@Override
	public CloseWorkOrderService forClosingBreakdown() {
		return new CloseWorkOrderServiceImpl();
	}

	@Override
	public VehicleTypeCrudService forVehicleTypeCrudService() {
		return new VehicleTypeServiceImpl();
	}

	@Override
	public SparePartCrudService forSparePartCrudService() {
		return new SparePartCrudServiceImpl();
	}

	@Override
	public ClientCrudService forClienteCrudService() {
		return new ClientServiceImpl();
	}

	@Override
	public ClientHistoryService forClientHistoryService() {
		return new ClientHistoryServiceImpl();
	}

	@Override
	public WorkOrderCrudService forWorkOrderCrudService() {
		return new WorkOrderCrudServiceImpl();
	}

	@Override
	public ViewAssignedWorkOrdersService forViewAssignedWorkOrdersService() {
		return new ViewAssignedWorkOrdersServiceImpl();
	}

	@Override
	public ContractService forContractService() {
		return new ContractServiceImpl();
	}

	@Override
	public ContractTypeService forContractTypeService() {
		return new ContractTypeServiceImpl();

	}

	@Override
	public PayrollService forPayrollService() {
		return new PayrollServiceImpl();
	}

	@Override
	public ProfessionalGroupService forProfessionalGroupService() {
		return new ProfessionalGroupServiceImpl();

	}

	@Override
	public InterventionService forIntervention() {
		return new InterventionServiceImpl();
	}

}
