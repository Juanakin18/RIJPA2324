package uo.ri.cws.application.service.vehicletype;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.service.BusinessException;

/**
 * This service is intended to be used by the Cashier
 * It follows the ISP principle (@see SOLID principles from RC Martin)
 */
public interface VehicleTypeCrudService {

	// ...

	public static class VehicleTypeDto {

		public String id;
		public long version;

		public String name;
		public double pricePerHour;
		public int minTrainigHours;

	}

	void addVehicleType(VehicleTypeDto dto) throws BusinessException;

	void deleteVehicleType(String dni) throws BusinessException;

	Optional<VehicleTypeDto> findById(String dni) throws BusinessException;

	void update(VehicleTypeDto dto) throws BusinessException;

	List<VehicleTypeDto> findAll() throws BusinessException;
}
