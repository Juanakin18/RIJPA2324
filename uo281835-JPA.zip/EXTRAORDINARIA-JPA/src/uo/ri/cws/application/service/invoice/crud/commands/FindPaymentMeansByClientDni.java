package uo.ri.cws.application.service.invoice.crud.commands;

import java.util.ArrayList;
import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.paymentmean.PaymentMeanCrudService.PaymentMeanDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.PaymentMean;
import uo.ri.util.assertion.ArgumentChecks;

public class FindPaymentMeansByClientDni
		implements Command<List<PaymentMeanDto>> {

	private PaymentMeanRepository rep = Factory.repository.forPaymentMean();
	private String dni;

	public FindPaymentMeansByClientDni(String dni) {
		ArgumentChecks.isNotEmpty(dni);
		this.dni = dni;
	}

	@Override
	public List<PaymentMeanDto> execute() throws BusinessException {
		List<PaymentMean> payment = rep.findByClientId(dni);
		List<PaymentMeanDto> dtos = new ArrayList<>();
		for (PaymentMean p : payment) {
			dtos.add(DtoAssembler.toDto(p));
		}
		return null;
	}

}
