package uo.ri.cws.application.service.workorder.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.WorkOrderRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.WorkOrder;
import uo.ri.cws.domain.WorkOrder.WorkOrderState;
import uo.ri.util.assertion.ArgumentChecks;

public class UpdateWorkOrder implements Command<Void> {

	private WorkOrderRepository gtw = Factory.repository.forWorkOrder();
	private WorkOrderDto plate;
	
	@Override
	public Void execute() throws BusinessException {
		Optional<WorkOrder> v = gtw.findById(plate.vehicleId);
		if(v.isEmpty())
			throw new BusinessException("No existe la workorder");
		WorkOrder w = v.get();
		w.setAmountForTesting(plate.total);
		w.setState(WorkOrderState.valueOf(plate.state));
		return null;
	}
	public UpdateWorkOrder(WorkOrderDto dto) {
		ArgumentChecks.isNotNull(plate);
		this.plate = dto;
	}


}
