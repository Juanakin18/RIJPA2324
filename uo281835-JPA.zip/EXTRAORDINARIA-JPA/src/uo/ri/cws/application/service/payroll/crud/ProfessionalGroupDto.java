package uo.ri.cws.application.service.payroll.crud;

public class ProfessionalGroupDto {

	public String name;
	public String id;
	public long version;
	public double trieniumSalary;
	public double productivityRate;

}
