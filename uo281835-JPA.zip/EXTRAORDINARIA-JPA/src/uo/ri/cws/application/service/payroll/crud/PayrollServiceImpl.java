package uo.ri.cws.application.service.payroll.crud;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.payroll.PayrollService;
import uo.ri.cws.application.service.payroll.crud.commands.DeleteLastPayrollFor;
import uo.ri.cws.application.service.payroll.crud.commands.DeleteLastPayrolls;
import uo.ri.cws.application.service.payroll.crud.commands.GenerateLastMonthPayrolls;
import uo.ri.cws.application.service.payroll.crud.commands.GeneratePayrolls;
import uo.ri.cws.application.service.payroll.crud.commands.GetAllPayrolls;
import uo.ri.cws.application.service.payroll.crud.commands.GetAllPayrollsForMechanic;
import uo.ri.cws.application.service.payroll.crud.commands.GetAllPayrollsForProfessionalGroup;
import uo.ri.cws.application.service.payroll.crud.commands.GetPayrollDetails;
import uo.ri.cws.application.util.command.CommandExecutor;

public class PayrollServiceImpl implements PayrollService {

	private CommandExecutor executor = Factory.executor.forExecutor();

	@Override
	public void deleteLastPayrollFor(String dni) throws BusinessException {
		executor.execute(new DeleteLastPayrollFor(dni));
	}

	@Override
	public void deleteLastPayrolls() throws BusinessException {
		executor.execute(new DeleteLastPayrolls());

	}

	@Override
	public Optional<PayrollBLDto> getPayrollDetails(String string)
			throws BusinessException {
		return executor.execute(new GetPayrollDetails(string));
	}

	@Override
	public List<PayrollSummaryBLDto> getAllPayrolls() throws BusinessException {
		return executor.execute(new GetAllPayrolls());
	}

	@Override
	public List<PayrollSummaryBLDto> getAllPayrollsForMechanic(String dni)
			throws BusinessException {
		return executor.execute(new GetAllPayrollsForMechanic(dni));
	}

	@Override
	public List<PayrollSummaryBLDto> getAllPayrollsForProfessionalGroup(
			String string) throws BusinessException {

		return executor.execute(new GetAllPayrollsForProfessionalGroup(string));
	}

	@Override
	public void generatePayrolls(LocalDate currentDate)
			throws BusinessException {
		executor.execute(new GeneratePayrolls(currentDate));

	}

	@Override
	public void generatePayrolls() throws BusinessException {
		executor.execute(new GenerateLastMonthPayrolls());

	}

}
