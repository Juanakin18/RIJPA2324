package uo.ri.cws.application.service.contract.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.MechanicRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contract.ContractService.ContractSummaryDto;
import uo.ri.cws.application.service.contract.assembler.ContractAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.cws.domain.Mechanic;
import uo.ri.util.assertion.ArgumentChecks;

public class FindContractsByMechanicDni implements Command<List<ContractSummaryDto>> {


	private String dto;
	private MechanicRepository repo2 = Factory.repository.forMechanic();
	
	public FindContractsByMechanicDni(String mechanicDni) {
		ArgumentChecks.isNotNull(mechanicDni, "No puede ser nulo");
		ArgumentChecks.isNotBlank(mechanicDni, mechanicDni);
		this.dto = mechanicDni;
	}

	@Override
	public List<ContractSummaryDto> execute() throws BusinessException {
		Optional<Mechanic> mech = repo2.findByDni(dto);
		if(mech.isEmpty())
			return new ArrayList<ContractSummaryDto>();
		List<Contract> list = new ArrayList<>(mech.get().getTerminatedContracts());
		if(mech.get().getContractInForce().isPresent())
			list.add(mech.get().getContractInForce().get());
		return ContractAssembler.toDtoList(list);
	}

}
