package uo.ri.cws.application.service.sparepart;

public class SparePartDto {

	public String id;
	public String code;
	public String description;
	public double price;
	public long version;

}
