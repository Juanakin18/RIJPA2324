package uo.ri.cws.application.service.voucher.commands;

import java.util.ArrayList;
import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.paymentmean.VoucherService.VoucherSummaryDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Client;

public class GetVoucherSummary implements Command<List<VoucherSummaryDto>> {

	private PaymentMeanRepository repo = Factory.repository.forPaymentMean();
	private ClientRepository repo2 = Factory.repository.forClient();
	
	@Override
	public List<VoucherSummaryDto> execute() throws BusinessException {
		
		List<Client> c = repo2.findAll();
		List<VoucherSummaryDto> result = new ArrayList<VoucherSummaryDto>();
		for(Client c1 : c) {
			result.add(DtoAssembler.toVoucherSummaryDtoList(repo.findAggregateVoucherDataByClientId(c1.getId())));
		}
		return result;
	}

}
