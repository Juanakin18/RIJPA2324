package uo.ri.cws.application.service.contract.commands;

import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contract.ContractService.ContractSummaryDto;
import uo.ri.cws.application.service.contract.assembler.ContractAssembler;
import uo.ri.cws.application.util.command.Command;

public class FindAllContracts implements Command<List<ContractSummaryDto>> {


	private ContractRepository repo = Factory.repository.forContract(); 
	
	@Override
	public List<ContractSummaryDto> execute() throws BusinessException {
		return ContractAssembler.toDtoList(repo.findAll());
	}

}
