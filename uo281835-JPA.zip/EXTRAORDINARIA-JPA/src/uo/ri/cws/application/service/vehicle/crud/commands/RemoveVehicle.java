package uo.ri.cws.application.service.vehicle.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.VehicleRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Vehicle;
import uo.ri.util.assertion.ArgumentChecks;

public class RemoveVehicle implements Command<Void> {

	private VehicleRepository repo = Factory.repository.forVehicle();
	private String plate;
	public RemoveVehicle(String plate) {
		ArgumentChecks.isNotNull(plate);
		ArgumentChecks.isNotEmpty(plate);
		ArgumentChecks.isNotBlank(plate);
		this.plate = plate;
	}

	@Override
	public Void execute() throws BusinessException {
		Optional<Vehicle> v = repo.findByPlate(plate);
		if(v.isPresent()) {
			Vehicle v1 = v.get();
			if(v1.getWorkOrders().size()<=0)
				repo.remove(v1);
			else
				throw new BusinessException("Este vehículo tiene workorders");
		}else {
			throw new BusinessException("No existe ese vehículo");
		}
		return null;
	}

}
