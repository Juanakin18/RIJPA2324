package uo.ri.cws.application.service.client.crud;

import uo.ri.cws.application.service.client.ClientHistoryService;

public class ClientHistoryServiceImpl implements ClientHistoryService {

}
