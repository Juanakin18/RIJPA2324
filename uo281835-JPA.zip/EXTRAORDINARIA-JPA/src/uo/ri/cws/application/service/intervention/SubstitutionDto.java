package uo.ri.cws.application.service.intervention;

public class SubstitutionDto {

	public String sparePartId;
	public int cantidad;
}
