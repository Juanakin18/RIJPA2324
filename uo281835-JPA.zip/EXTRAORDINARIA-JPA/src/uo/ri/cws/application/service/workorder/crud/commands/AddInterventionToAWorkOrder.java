package uo.ri.cws.application.service.workorder.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.InterventionRepository;
import uo.ri.cws.application.repository.MechanicRepository;
import uo.ri.cws.application.repository.WorkOrderRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.intervention.InterventionService.InterventionDto;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Intervention;
import uo.ri.cws.domain.Mechanic;
import uo.ri.cws.domain.WorkOrder;
import uo.ri.util.assertion.ArgumentChecks;

public class AddInterventionToAWorkOrder implements Command<Void> {

	private InterventionRepository irepo = Factory.repository.forIntervention();
	private WorkOrderRepository repo = Factory.repository.forWorkOrder();
	private MechanicRepository mrepo = Factory.repository.forMechanic();
	private String wid;
	private InterventionDto dto ;
	public AddInterventionToAWorkOrder(String workOrderId, InterventionDto idto) {
		ArgumentChecks.isNotBlank(workOrderId);
		ArgumentChecks.isNotNull(idto);
		this.wid = workOrderId;
		this.dto = idto;
	}

	@Override
	public Void execute() throws BusinessException {
		Optional<WorkOrder> w = repo.findById(wid);
		Optional<Mechanic> m = mrepo.findByDni(dto.mechanicId);
		if(w.isEmpty())
			throw new BusinessException("No existe esa workorder");
		if(m.isEmpty())
			throw new BusinessException("No existe ese mecánico");
		
		Intervention i = new Intervention(m.get(), w.get(), dto.minutes);
		irepo.add(i);
		return null;
	}

}
