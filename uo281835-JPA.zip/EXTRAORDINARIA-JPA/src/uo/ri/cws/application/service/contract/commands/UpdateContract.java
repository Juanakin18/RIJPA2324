package uo.ri.cws.application.service.contract.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contract.ContractService.ContractDto;
import uo.ri.cws.application.service.contract.ContractService.ContractState;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.util.assertion.ArgumentChecks;

public class UpdateContract implements Command<Void> {

	private ContractDto dto;
	private ContractRepository repo = Factory.repository.forContract(); 
	
	public UpdateContract(ContractDto dto) {
		ArgumentChecks.isNotNull(dto);
		ArgumentChecks.isNotNull(dto.id);
		ArgumentChecks.isNotEmpty(dto.id);
		ArgumentChecks.isNotBlank(dto.id);
		ArgumentChecks.isTrue(dto.annualBaseWage>0);
		
		this.dto = dto;
	}

	@Override
	public Void execute() throws BusinessException {
		Optional<Contract> c = repo.findById(dto.id);
		if(dto.contractTypeName.equals("FIXED_TERM")) {
			BusinessChecks.isNotNull(dto.endDate);
			BusinessChecks.isTrue(dto.endDate.isAfter(dto.startDate));
		}
		if(c.isPresent()) {
			
			Contract c1 = c.get();
			
			if(c1.getContractType().getName().equals("FIXED_TERM")) {
				BusinessChecks.isNotNull(c1.getEndDate());
				BusinessChecks.isTrue(c1.getEndDate().get().isAfter(c1.getStartDate()));
			}
			
			if(c1.getState() == ContractState.TERMINATED)
				throw new BusinessException("aa");
			c1.setWage(dto.annualBaseWage);
			if(dto.contractTypeName.equals("FIXED_TERM")) {
				c1.setEndDate(dto.endDate);
			}
				}else {
			throw new BusinessException("No existe ese contrato");
		}
		return null;
	}

}
