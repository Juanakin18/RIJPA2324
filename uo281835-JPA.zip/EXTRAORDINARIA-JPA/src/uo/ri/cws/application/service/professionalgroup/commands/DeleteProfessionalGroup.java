package uo.ri.cws.application.service.professionalgroup.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ProfessionalGroupRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.cws.domain.ProfessionalGroup;
import uo.ri.util.assertion.ArgumentChecks;

public class DeleteProfessionalGroup implements Command<Void> {

	private String dto;
	private ProfessionalGroupRepository repo = Factory.repository.forProfessionalGroup();
	
	public DeleteProfessionalGroup(String name) {
		ArgumentChecks.isNotNull(name);
		ArgumentChecks.isNotEmpty(name);
		ArgumentChecks.isNotBlank(name);
		this.dto = name;
	}

	@Override
	public Void execute() throws BusinessException {
		Optional<ProfessionalGroup> p = repo.findByName(dto);
		BusinessChecks.exists(p);
		List<Contract> cs = new ArrayList<>(p.get().getContracts());
		BusinessChecks.isTrue(cs.isEmpty(), "Still has contracts");
		repo.remove(p.get());
		return null;
	}

}
