package uo.ri.cws.application.service.payroll.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.PayrollRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.payroll.PayrollService.PayrollBLDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Payroll;
import uo.ri.util.assertion.ArgumentChecks;

public class GetPayrollDetails implements Command<Optional<PayrollBLDto>> {

	private PayrollRepository pgtw = Factory.repository.forPayroll();
	public String id;
	public GetPayrollDetails(String string) {
		ArgumentChecks.isNotNull(string, "The mechanic id can't be null");
		ArgumentChecks.isNotEmpty(string, "The mechanic id can't be empty");
		ArgumentChecks.isNotBlank(string, "The id can't be blank");
		
		this.id = string;
	}

	@Override
	public Optional<PayrollBLDto> execute() throws BusinessException {
		return DtoAssembler.toPayRollDto(CheckExists(id));
	}

	/**
	 * Comprueba que existe la payroll
	 * @param id2 el id
	 * @throws BusinessException Excepci�n
	 */
	private Optional<Payroll> CheckExists(String id2) throws BusinessException {
		Optional<Payroll> dto = pgtw.findById(id2);
		if(dto.isEmpty())
			return Optional.empty();
		return dto;
		
	}

}
