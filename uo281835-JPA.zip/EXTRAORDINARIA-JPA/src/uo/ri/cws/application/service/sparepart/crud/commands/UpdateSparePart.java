package uo.ri.cws.application.service.sparepart.crud.commands;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.SparePartRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.sparepart.SparePartDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.SparePart;
import uo.ri.util.assertion.ArgumentChecks;

public class UpdateSparePart implements Command<Void> {

	private SparePartRepository gtw = Factory.repository.forSparePart();
	private SparePartDto dto;
	public UpdateSparePart(SparePartDto dto) { 
		ArgumentChecks.isNotNull(dto);
		this.dto = dto;
	}
	@Override
	public Void execute() throws BusinessException {
		SparePart m =gtw.findById(dto.id).get();
		BusinessChecks.hasVersion(m, dto.version);
		m.setCode(dto.code);
		m.setDescription(dto.description); 
		m.setPrice(dto.price);
		return null;
	}

}
