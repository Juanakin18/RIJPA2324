package uo.ri.cws.application.service.client.crud.commands;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Client;
import uo.ri.util.assertion.ArgumentChecks;

public class DeleteClient implements Command<Void> {

	private ClientRepository gtw = Factory.repository.forClient();
	private String idClient;
	public DeleteClient(String idClient) {
		ArgumentChecks.isNotEmpty(idClient);
		this.idClient = idClient;
	}

	@Override
	public Void execute() throws BusinessException {
		dniExists();
		
		gtw.remove(new Client(idClient));
		return null;
	}

	private void dniExists() throws BusinessException {
		if(gtw.findById(idClient).isEmpty())
			throw new BusinessException("No existe ese cliente");
		
	}

}
