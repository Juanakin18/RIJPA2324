package uo.ri.cws.application.service.sparepart.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.SparePartRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.SparePart;
import uo.ri.util.assertion.ArgumentChecks;

public class DeleteSparePart implements Command<Void> {
	private SparePartRepository gtw = Factory.repository.forSparePart();
	private String dto;
	public DeleteSparePart(String dto) {
		ArgumentChecks.isNotNull(dto);
		this.dto = dto;
	}
	@Override
	public Void execute() throws BusinessException {
		
		Optional<SparePart> p = gtw.findById(dto);
		if(p.isEmpty())
			throw new BusinessException("No existe");
		gtw.remove(p.get());
		return null;
	}
}
