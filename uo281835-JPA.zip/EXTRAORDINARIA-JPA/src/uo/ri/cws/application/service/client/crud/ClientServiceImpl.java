package uo.ri.cws.application.service.client.crud;

import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.client.ClientCrudService;
import uo.ri.cws.application.service.client.crud.commands.AddClient;
import uo.ri.cws.application.service.client.crud.commands.DeleteClient;
import uo.ri.cws.application.service.client.crud.commands.FindAllClients;
import uo.ri.cws.application.service.client.crud.commands.FindClientByDNI;
import uo.ri.cws.application.service.client.crud.commands.FindClientByName;
import uo.ri.cws.application.service.client.crud.commands.FindClientBySurname;
import uo.ri.cws.application.service.client.crud.commands.FindClientsById;
import uo.ri.cws.application.service.client.crud.commands.FindClientsByPlate;
import uo.ri.cws.application.service.client.crud.commands.UpdateClient;
import uo.ri.cws.application.util.command.CommandExecutor;

public class ClientServiceImpl implements  ClientCrudService {

	private CommandExecutor executor = Factory.executor.forExecutor();

	

	@Override
	public void deleteClient(String idClient) throws BusinessException {
		executor.execute(new DeleteClient(idClient));

	}

	@Override
	public void updateClient(ClientDto client) throws BusinessException {
		executor.execute(new UpdateClient(client));
	}

	@Override
	public List<ClientDto> findAllClients() throws BusinessException {
		return executor.execute(new FindAllClients());
	}

	@Override
	public Optional<ClientDto> findClientById(String idClient)
			throws BusinessException {
		return executor.execute(new FindClientsById(idClient));
	}

	

	@Override
	public ClientDto addClient(ClientDto client) throws BusinessException {
		return executor.execute(new AddClient(client));
	}

	@Override
	public Optional<ClientDto> findClientByDNI(String dni) throws BusinessException {
		return executor.execute(new FindClientByDNI(dni));
	}

	@Override
	public List<ClientDto> findClientsByName(String nombre)  throws BusinessException {
		return executor.execute(new FindClientByName(nombre));
	}

	@Override
	public Optional<ClientDto> findClientsByPlate(String nombre)  throws BusinessException{
		return executor.execute(new FindClientsByPlate(nombre));
	}

	@Override
	public List<ClientDto> findClientsBySurname(String surname)  throws BusinessException{
		return executor.execute(new FindClientBySurname(surname));
	}

}
