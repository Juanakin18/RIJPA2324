package uo.ri.cws.application.service.sparepart.crud.commands;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.SparePartRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.sparepart.SparePartDto;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.SparePart;
import uo.ri.util.assertion.ArgumentChecks;

public class AddSparePart implements Command<Void> {

	private SparePartRepository gtw = Factory.repository.forSparePart();
	private SparePartDto dto;
	public AddSparePart(SparePartDto dto) {
		ArgumentChecks.isNotNull(dto);
		this.dto = dto;
	}
	@Override
	public Void execute() throws BusinessException {
		CheckIfExists();
		gtw.add(new SparePart(dto.code, dto.description, dto.price));
		return null;
	}
	private void CheckIfExists() throws BusinessException {
		if(gtw.findById(dto.id).isPresent())
			throw new BusinessException("Ya existe esa parte");
		
	}

}
