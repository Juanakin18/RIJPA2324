package uo.ri.cws.application.service.client.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Client;
import uo.ri.util.assertion.ArgumentChecks;

public class FindClientByDNI implements Command<Optional<ClientDto>> {

	private String dni = ""; 
	private ClientRepository repository = Factory.repository.forClient();
	public FindClientByDNI(String dni) {
		ArgumentChecks.isNotBlank(dni);
		this.dni= dni;
	}

	@Override
	public Optional<ClientDto> execute() throws BusinessException {
		Optional<Client> cl = repository.findByDni(dni);
		if(cl.isPresent())
			return Optional.of(DtoAssembler.toDto(cl.get()));
		return Optional.empty();
	}

}
