package uo.ri.cws.application.service.vehicle.crud.commands;

import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.VehicleRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.vehicle.VehicleCrudService.VehicleDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.util.assertion.ArgumentChecks;

public class FindVehicleByDni implements Command<List<VehicleDto>> {
	private String plate;
	private VehicleRepository repo = Factory.repository.forVehicle();
	
	public FindVehicleByDni(String plate) {
		ArgumentChecks.isNotEmpty( plate );
		this.plate = plate;
	}

	@Override
	public List<VehicleDto> execute() throws BusinessException {
		return DtoAssembler.toDtoList(repo.findByClient( plate )) ;
		
	}
	

}
