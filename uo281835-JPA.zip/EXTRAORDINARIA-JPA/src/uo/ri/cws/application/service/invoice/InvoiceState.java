package uo.ri.cws.application.service.invoice;

public enum InvoiceState {

}
