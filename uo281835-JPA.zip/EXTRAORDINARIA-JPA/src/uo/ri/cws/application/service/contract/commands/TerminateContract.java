package uo.ri.cws.application.service.contract.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contract.ContractService.ContractState;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.util.assertion.ArgumentChecks;

public class TerminateContract implements Command<Void> {
	private String dto;
	private ContractRepository repo = Factory.repository.forContract(); 
	
	public TerminateContract(String contractId) {
		ArgumentChecks.isNotNull(contractId);
		ArgumentChecks.isNotEmpty(contractId);
		ArgumentChecks.isNotBlank(contractId);
		this.dto = contractId;
	}

	@Override
	public Void execute() throws BusinessException {
		Optional<Contract> c = repo.findById(dto);
		BusinessChecks.exists(c);
		BusinessChecks.isTrue(c.get().getState() == ContractState.IN_FORCE);
		c.get().terminate();
		return null;
	}

}
