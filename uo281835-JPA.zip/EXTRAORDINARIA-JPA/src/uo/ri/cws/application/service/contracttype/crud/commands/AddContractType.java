package uo.ri.cws.application.service.contracttype.crud.commands;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractTypeRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contracttype.ContractTypeService.ContractTypeDto;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.ContractType;
import uo.ri.util.assertion.ArgumentChecks;

public class AddContractType implements Command<ContractTypeDto> {

	private ContractTypeDto dto;
	private ContractTypeRepository gtw = Factory.repository.forContractType();

	public AddContractType(ContractTypeDto dto2) {
		ArgumentChecks.isNotNull(dto2);
		ArgumentChecks.isNotEmpty(dto2.name);
		ArgumentChecks.isNotBlank(dto2.name);
		ArgumentChecks.isTrue(dto2.compensationDays >= 0f);

		this.dto = dto2;

	}

	@Override
	public ContractTypeDto execute() throws BusinessException {
		checkIfExists();
		ContractType dto1 = new ContractType(dto.name, dto.compensationDays);
		dto.id = dto1.getId();
		dto.version = dto1.getVersion();
		gtw.add(dto1);
		return dto;
	}

	private void checkIfExists() throws BusinessException {
		if (!gtw.findByName(dto.name).isEmpty())
			throw new BusinessException("Ya existe un tipo con ese nombre");

	}

}
