package uo.ri.cws.application.service.invoice.crud.commands;

import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.WorkOrderRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.invoice.InvoicingService.InvoicingWorkOrderDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.WorkOrder;
import uo.ri.util.assertion.ArgumentChecks;

public class FindNotInvoicedWorkOrdersByPlate implements Command<List<InvoicingWorkOrderDto>> {

	private String dni;
	private WorkOrderRepository wrkrsRepo = Factory.repository.forWorkOrder();
	
	public FindNotInvoicedWorkOrdersByPlate(String plate) {
		ArgumentChecks.isNotNull(dni);
		ArgumentChecks.isNotEmpty(dni);
		this.dni = plate;
	}

	@Override
	public List<InvoicingWorkOrderDto> execute() throws BusinessException {
		List<WorkOrder> dtos = wrkrsRepo.findNotInvoicedWorkOrdersByPlate(dni);
		return DtoAssembler.toWorkOrderForInvoicingDtoList(dtos);
	}

	
}
