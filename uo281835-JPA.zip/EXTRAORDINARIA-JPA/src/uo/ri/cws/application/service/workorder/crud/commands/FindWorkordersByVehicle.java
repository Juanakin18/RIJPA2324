package uo.ri.cws.application.service.workorder.crud.commands;

import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.VehicleRepository;
import uo.ri.cws.application.repository.WorkOrderRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Vehicle;
import uo.ri.util.assertion.ArgumentChecks;

public class FindWorkordersByVehicle implements Command<List<WorkOrderDto>> {

	

	
	
	private String dni;
	private WorkOrderRepository repo = Factory.repository.forWorkOrder();
	private VehicleRepository mrepo = Factory.repository.forVehicle();
	

	@Override
	public List<WorkOrderDto> execute() throws BusinessException {
		Optional<Vehicle> w = mrepo.findByPlate(dni);
		if(w.isEmpty())
			throw new BusinessException("No existe el mecánico");
		return (DtoAssembler.toWorkOrderDtoList(repo.findByVehicle(w.get().getId())));
	}
	public FindWorkordersByVehicle(String object) {
		ArgumentChecks.isNotBlank(object);
		this.dni = object;
	}

}
