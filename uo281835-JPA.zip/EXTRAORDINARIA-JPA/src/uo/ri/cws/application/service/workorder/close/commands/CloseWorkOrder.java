package uo.ri.cws.application.service.workorder.close.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.WorkOrderRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.WorkOrder;
import uo.ri.util.assertion.ArgumentChecks;

public class CloseWorkOrder implements Command<Void> {

	private String id;
	private WorkOrderRepository repo = Factory.repository.forWorkOrder();
	
	public CloseWorkOrder(String id) {
		ArgumentChecks.isNotBlank(id);
		this.id = id;
	}

	@Override
	public Void execute() throws BusinessException {

		Optional<WorkOrder> w = repo.findById(id);
		if(w.isEmpty())
			throw new BusinessException("No existe esa workorder");
		w.get().markAsFinished();
		return null;
	}

}
