package uo.ri.cws.application.service.payroll.crud.commands;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.repository.PayrollRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contract.ContractService.ContractState;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.cws.domain.Payroll;


public class GenerateLastMonthPayrolls implements Command<Void> {

	private ContractRepository cgtw = Factory.repository.forContract();
	private PayrollRepository pgtw = Factory.repository.forPayroll();

    private LocalDate date = LocalDate.now();
	@Override
	public Void execute() throws BusinessException {
		List<Contract> contratosEsteMes = cgtw.findAllInForceThisMonth(date);
		for(Contract cdto : contratosEsteMes) {
			if(cdto.getMechanic().isPresent()) {
				List<Payroll> payrolls = pgtw.findByContract(cdto.getId());
				Optional<Payroll> payroll = findPayroll(payrolls);
				// Si el contrato no tiene nóminas asignadas
				if (payroll == null) {
				    generateNewPayroll(cdto);
				}
			}else if (cdto.getState().equals(ContractState.TERMINATED)) {
			    if (cdto.getEndDate().isPresent()) {
					if (cdto.getEndDate().get().getMonthValue() == this.date
						.getMonthValue()
						&& cdto.getEndDate().get().getYear() == this.date
							.getYear()) {
					    Optional<Payroll> p = pgtw.findByDate(this.date);
					    if (p.isEmpty()) {
						generateNewPayroll(cdto);
					    }
					}
				    }
				}
		}
		return null;
	}
	
	

    private Optional<Payroll> findPayroll(List<Payroll> payrolls) {
	Optional<Payroll> payroll = null;
	for (Payroll p : payrolls) {
	    if (p.getDate().getMonthValue() == this.date.getMonthValue()
		    && p.getDate().getYear() == this.date.getYear())
		payroll = Optional.ofNullable(p);
	}
	return payroll;
    }

    private void generateNewPayroll(Contract c) {
	Payroll p = new Payroll(c, date);
	pgtw.add(p);
    }
}
