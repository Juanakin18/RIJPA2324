package uo.ri.cws.application.service.professionalgroup.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ProfessionalGroupRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.professionalgroup.ProfessionalGroupService.ProfessionalGroupBLDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.util.assertion.ArgumentChecks;

public class FindProfessionalGroupById implements Command<Optional<ProfessionalGroupBLDto>> {

	private String dto;
	private ProfessionalGroupRepository repo = Factory.repository.forProfessionalGroup();
	
	public FindProfessionalGroupById(String name) {
		ArgumentChecks.isNotNull(name);
		ArgumentChecks.isNotEmpty(name);
		ArgumentChecks.isNotBlank(name);
		this.dto = name;
	}

	@Override
	public Optional<ProfessionalGroupBLDto> execute() throws BusinessException {
		return Optional.of(DtoAssembler.toDto(repo.findById(dto).get())) ;
	}

}
