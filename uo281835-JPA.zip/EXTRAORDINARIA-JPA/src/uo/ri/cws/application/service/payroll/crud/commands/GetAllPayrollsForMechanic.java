package uo.ri.cws.application.service.payroll.crud.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.MechanicRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.payroll.PayrollService.PayrollSummaryBLDto;
import uo.ri.cws.application.service.payroll.assembler.PayrollAssembler;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Mechanic;
import uo.ri.cws.domain.Payroll;
import uo.ri.util.assertion.ArgumentChecks;

public class GetAllPayrollsForMechanic implements Command<List<PayrollSummaryBLDto>> {

	private MechanicRepository mgtw = Factory.repository.forMechanic();
	private String dni;
	public GetAllPayrollsForMechanic(String dni) {
		ArgumentChecks.isNotNull(dni, "The mechanic id can't be null");
		ArgumentChecks.isNotEmpty(dni, "The mechanic id can't be empty");
		ArgumentChecks.isNotBlank(dni, "The id can't be blank");
		
		this.dni = dni;
	}
	
	@Override
	public List<PayrollSummaryBLDto> execute() throws BusinessException {
		Optional<Mechanic> m =  mgtw.findById(dni);
		BusinessChecks.exists(m);
		List<Payroll> pdtos = new ArrayList<>(m.get().getContractInForce().get().getPayrolls());
		return PayrollAssembler.toBlSummaryDtoList(pdtos);
	}
	

	

}
