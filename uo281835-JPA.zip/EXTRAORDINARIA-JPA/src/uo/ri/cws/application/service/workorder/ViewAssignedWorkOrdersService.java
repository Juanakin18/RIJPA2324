package uo.ri.cws.application.service.workorder;

import java.util.List;

import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;

/**
 * This service is intended to be used by the Mechanic
 * It follows the ISP principle (@see SOLID principles from RC Martin)
 */
public interface ViewAssignedWorkOrdersService {

	List<WorkOrderDto> findByDni(String readString) throws BusinessException;

	// ...
	
}
