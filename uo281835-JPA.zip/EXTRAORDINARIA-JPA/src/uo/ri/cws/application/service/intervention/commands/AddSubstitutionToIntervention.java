package uo.ri.cws.application.service.intervention.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.InterventionRepository;
import uo.ri.cws.application.repository.SparePartRepository;
import uo.ri.cws.application.repository.SubstitutionRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.intervention.InterventionService.InterventionDto;
import uo.ri.cws.application.service.intervention.SubstitutionDto;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Intervention;
import uo.ri.cws.domain.SparePart;
import uo.ri.cws.domain.Substitution;
import uo.ri.util.assertion.ArgumentChecks;

public class AddSubstitutionToIntervention implements Command<Void> {

	private InterventionDto dto;
	private SubstitutionDto sdto;
	private InterventionRepository repo =  Factory.repository.forIntervention();
	private SparePartRepository sprepo = Factory.repository.forSparePart();
	private SubstitutionRepository srepo = Factory.repository.forSubstitution();

	public AddSubstitutionToIntervention(SubstitutionDto sub, InterventionDto idto) {
		ArgumentChecks.isNotNull(sub);
		ArgumentChecks.isNotNull(idto);
		this.dto = idto;
		this.sdto = sub;
	}

	@Override
	public Void execute() throws BusinessException {
		Optional<Intervention> inter = repo.findById(dto.id);
		if(inter.isPresent()) {
			Intervention i = inter.get();
			Optional<SparePart> sp = sprepo.findById(sdto.sparePartId);
			if(sp.isPresent()) {
				Substitution s = new Substitution(sp.get(), i, sdto.cantidad);
				srepo.add(s);
			}else {
				throw new BusinessException("No existe esa parte");
			}
			
		}else {
			throw new BusinessException("No existe esa intervención");
		}
		return null;
	}

}
