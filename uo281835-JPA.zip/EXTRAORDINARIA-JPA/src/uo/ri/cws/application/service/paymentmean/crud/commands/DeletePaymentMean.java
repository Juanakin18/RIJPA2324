package uo.ri.cws.application.service.paymentmean.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.PaymentMean;
import uo.ri.util.assertion.ArgumentChecks;

public class DeletePaymentMean implements Command<Void> {

	private PaymentMeanRepository rep = Factory.repository.forPaymentMean();
	private String id;

	public DeletePaymentMean(String id) {
		ArgumentChecks.isNotEmpty(id);
		this.id = id;
	}

	@Override
	public Void execute() throws BusinessException {
		Optional<PaymentMean> pm = rep.findById(id);
		if (pm.isEmpty())
			throw new BusinessException("No existe");
		rep.remove(pm.get());
		return null;
	}

}
