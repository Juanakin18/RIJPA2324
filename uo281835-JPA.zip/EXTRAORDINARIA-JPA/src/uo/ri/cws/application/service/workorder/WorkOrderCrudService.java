package uo.ri.cws.application.service.workorder;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.intervention.InterventionService.InterventionDto;

/**
 * This service is intended to be used by the Mechanic
 * It follows the ISP principle (@see SOLID principles from RC Martin)
 */
public interface WorkOrderCrudService {

	// ...
	List<WorkOrderDto> findWorkordersByVehicle(String plate) throws BusinessException;
    List<WorkOrderDto> findAllWO() throws BusinessException;


	public static class WorkOrderDto {

		public String id;
		public long version;

		public String vehicleId;
		public String description;
		public LocalDateTime date;
		public double total;
		public String state;

		// might be null
		public String mechanicId;
		public String invoiceId;

	}
	void addWorkOrder(WorkOrderDto dto) throws BusinessException;
	void deleteWorkOrder(String dto) throws BusinessException;
	void updateWorkOrder(WorkOrderDto dto) throws BusinessException;
	Optional<WorkOrderDto> findWorkorderByID(String id) throws BusinessException;
	Optional<WorkOrderDto> findWorkorderByDateAndVehicle(String plateNumber, LocalDateTime date) throws BusinessException;
	List<WorkOrderDto> findWorkOrdersByDni(String readString) throws BusinessException;
	void addInterventionToAWorkOrder(String workOrderId, InterventionDto idto) throws BusinessException;

}
