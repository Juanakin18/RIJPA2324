package uo.ri.cws.application.service.contracttype.crud.commands;

import java.util.ArrayList;
import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.repository.MechanicRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contract.ContractService.ContractDto;
import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.util.assertion.ArgumentChecks;

public class FindMechanicByContractType implements Command<List<MechanicDto>> {

	private MechanicRepository mgtw = Factory.repository.forMechanic();
	private ContractRepository cgtw = Factory.repository.forContract();
	private String contractTypeName;

	public FindMechanicByContractType(String name) {
		ArgumentChecks.isNotNull(name);
		ArgumentChecks.isNotEmpty(name);
		ArgumentChecks.isNotBlank(name);
		this.contractTypeName = name;
	}

	@Override
	public List<MechanicDto> execute() throws BusinessException {
		List<ContractDto> contracts = DtoAssembler.toContractDtoList(
				cgtw.findByContractTypeId(contractTypeName));
		List<MechanicDto> mechanics = new ArrayList<MechanicDto>();
		for (ContractDto c : contracts) {
			mechanics.add(DtoAssembler.toDto(mgtw.findByDni(c.dni).get()));
		}
		return mechanics;
	}

}
