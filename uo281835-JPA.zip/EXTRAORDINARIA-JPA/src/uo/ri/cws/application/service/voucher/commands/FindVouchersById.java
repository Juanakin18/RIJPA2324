package uo.ri.cws.application.service.voucher.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.paymentmean.VoucherService.VoucherDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Voucher;
import uo.ri.util.assertion.ArgumentChecks;

public class FindVouchersById implements Command<Optional<VoucherDto>> {

	public FindVouchersById(String id) {
		ArgumentChecks.isNotBlank(id);
		this.id = id;
	}

	private String id;
	private PaymentMeanRepository repo = Factory.repository.forPaymentMean();
	
	@Override
	public Optional<VoucherDto> execute() throws BusinessException {
		Optional<Voucher> v = repo.findVoucherById(id);
		if(v.isEmpty())
			return Optional.empty();
		else
			return Optional.of(DtoAssembler.toDto(v.get()));
		
	}

}
