package uo.ri.cws.application.service.professionalgroup.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ProfessionalGroupRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.professionalgroup.ProfessionalGroupService.ProfessionalGroupBLDto;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.ProfessionalGroup;
import uo.ri.util.assertion.ArgumentChecks;

public class AddProfessionalGroup implements Command<ProfessionalGroupBLDto> {

	private ProfessionalGroupBLDto dto;
	private ProfessionalGroupRepository repo = Factory.repository.forProfessionalGroup();
	
	public AddProfessionalGroup(ProfessionalGroupBLDto dto) {
		ArgumentChecks.isNotNull(dto, "The group can't be null");
		ArgumentChecks.isNotNull(dto.name, "The group name can't be null");
		ArgumentChecks.isNotEmpty(dto.name, "The group name can't be empty");
		ArgumentChecks.isNotBlank(dto.name, "The group name can't be blank");
		ArgumentChecks.isTrue(dto.trieniumSalary >= 0,
			"The triennium must be positive");
		ArgumentChecks.isTrue(dto.productivityRate >= 0,
			"The triennium must be positive");
		this.dto = dto;
	}

	@Override
	public ProfessionalGroupBLDto execute() throws BusinessException {
		Optional<ProfessionalGroup> pg = repo.findByName(dto.name);
		BusinessChecks.isTrue(pg.isEmpty(), "The group already exists");
		ProfessionalGroup p = new ProfessionalGroup(dto.name, dto.trieniumSalary, dto.productivityRate);
		repo.add(p);
		return DtoAssembler.toDto(p);
	}

}
