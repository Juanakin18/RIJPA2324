package uo.ri.cws.application.service.intervention.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.InterventionRepository;
import uo.ri.cws.application.repository.MechanicRepository;
import uo.ri.cws.application.repository.WorkOrderRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.intervention.InterventionService.InterventionDto;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Intervention;
import uo.ri.cws.domain.Mechanic;
import uo.ri.cws.domain.WorkOrder;
import uo.ri.util.assertion.ArgumentChecks;

public class AddIntervention implements Command<Void> {

	private InterventionDto dto;
	private InterventionRepository repo =  Factory.repository.forIntervention();
	private MechanicRepository mrepo = Factory.repository.forMechanic();
	private WorkOrderRepository wrepo = Factory.repository.forWorkOrder();
	
	public AddIntervention(InterventionDto idto) {
		ArgumentChecks.isNotNull(idto);
		ArgumentChecks.isNotNull(idto.date);
		dto = idto;
	}

	@Override
	public Void execute() throws BusinessException {
		
		Optional<WorkOrder> workorder = wrepo.findById(dto.workorderId);
		Optional<Mechanic> mech = mrepo.findById(dto.mechanicId);
		if(workorder.isEmpty())
			throw new BusinessException("No existe esa workorder");
		if(mech.isEmpty())
			throw new BusinessException("No existe ese mecánico");
		Intervention intervention = new Intervention(mech.get(),workorder.get(),dto.date, dto.minutes);
		repo.add(intervention);
		return null;
	}

}
