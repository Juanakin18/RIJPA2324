package uo.ri.cws.application.service.contract.commands;

import java.time.LocalDate;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ContractRepository;
import uo.ri.cws.application.repository.ContractTypeRepository;
import uo.ri.cws.application.repository.MechanicRepository;
import uo.ri.cws.application.repository.ProfessionalGroupRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.contract.ContractService.ContractDto;
import uo.ri.cws.application.service.contract.assembler.ContractAssembler;
import uo.ri.cws.application.util.BusinessChecks;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Contract;
import uo.ri.cws.domain.ContractType;
import uo.ri.cws.domain.Mechanic;
import uo.ri.cws.domain.ProfessionalGroup;
import uo.ri.util.assertion.ArgumentChecks;

public class AddContract implements Command<ContractDto> {

	private ContractDto dto;
	private ContractRepository repo = Factory.repository.forContract(); 
	private MechanicRepository repo2 = Factory.repository.forMechanic();
	private ContractTypeRepository repo3 = Factory.repository.forContractType();
	private ProfessionalGroupRepository repo4 = Factory.repository.forProfessionalGroup();
	public AddContract(ContractDto c) {
		ArgumentChecks.isNotNull(c);
		ArgumentChecks.isTrue(c.annualBaseWage>0);
		ArgumentChecks.isNotNull(c.contractTypeName);
		ArgumentChecks.isNotEmpty(c.contractTypeName);
		ArgumentChecks.isNotBlank(c.contractTypeName);
		ArgumentChecks.isNotNull(c.dni);
		ArgumentChecks.isNotEmpty(c.dni);
		ArgumentChecks.isNotBlank(c.dni);
		ArgumentChecks.isNotNull(c.professionalGroupName);
		ArgumentChecks.isNotEmpty(c.professionalGroupName);
		ArgumentChecks.isNotBlank(c.professionalGroupName);
		
		this.dto = c;
	}

	@Override
	public ContractDto execute() throws BusinessException {
		if(dto.contractTypeName.equals("FIXED_TERM")) {
			BusinessChecks.isNotNull(dto.endDate);
			BusinessChecks.isTrue(dto.endDate.isAfter(dto.startDate));
		}
		Optional<Mechanic> c = repo2.findByDni(dto.dni);
		if(c.isPresent()) {
			Optional<ContractType> type = repo3.findByName(dto.contractTypeName);
			if(type.isPresent()) {
				Optional<ProfessionalGroup> group = repo4.findByName(dto.professionalGroupName);
				if(group.isPresent()) {
					Optional<Contract> contract1 = repo.findAllInForceByMechanic(c.get().getDni());
					if(contract1.isPresent()) {
						Contract con = contract1.get();
						Contract con1 =  new Contract(dto.startDate, con.getMechanic().get(),con.getContractType(), con.getProfessionalGroup(), dto.annualBaseWage);
						con.terminate();
						repo.add(con1);
						return ContractAssembler.toDto(con1);
					
					}else {
						if(dto.endDate ==null)
							dto.endDate = LocalDate.of(LocalDate.now().getYear(), LocalDate.now().getMonth().plus(1), 1);
						Contract contract = new Contract(dto.startDate,c.get(),type.get(), group.get(),dto.endDate,dto.annualBaseWage );
						repo.add(contract);
						return ContractAssembler.toDto(contract);
					}
					
				}
				throw new BusinessException("No existe ese grupo");
				
			}
			throw new BusinessException("No existe ese tipo");
		}
		throw new BusinessException("No existe ese mecánico");
		
	}

}
