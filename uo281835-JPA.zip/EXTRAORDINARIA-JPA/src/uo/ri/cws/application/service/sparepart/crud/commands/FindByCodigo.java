package uo.ri.cws.application.service.sparepart.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.SparePartRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.sparepart.SparePartDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.util.assertion.ArgumentChecks;

public class FindByCodigo implements Command<Optional<SparePartDto>> {

	private SparePartRepository gtw = Factory.repository.forSparePart();
	private String code;
	
	public FindByCodigo(String nombre) {
		ArgumentChecks.isNotNull(nombre);
		ArgumentChecks.isNotEmpty(nombre);
		this.code = nombre;
		
	}

	@Override
	public Optional<SparePartDto> execute() throws BusinessException {
		return Optional.of(DtoAssembler.toDto(gtw.findByCode(code).get()) );
	}

}
