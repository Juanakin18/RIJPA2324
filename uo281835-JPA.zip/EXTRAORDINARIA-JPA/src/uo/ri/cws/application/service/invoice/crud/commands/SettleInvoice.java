package uo.ri.cws.application.service.invoice.crud.commands;

import java.util.Map;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.InvoiceRepository;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Invoice;
import uo.ri.cws.domain.PaymentMean;
import uo.ri.util.assertion.ArgumentChecks;

public class SettleInvoice implements Command<Void> {

	private InvoiceRepository invoice = Factory.repository.forInvoice();
	private PaymentMeanRepository p = Factory.repository.forPaymentMean();
	private String invoiceId;
	private Map<String, Double> charges;

	public SettleInvoice(String invoiceId, Map<String, Double> charges) {
		ArgumentChecks.isNotEmpty(invoiceId);
		ArgumentChecks.isNotNull(charges);
		this.invoiceId = invoiceId;
		this.charges = charges;
	}

	@Override
	public Void execute() throws BusinessException {

		Optional<Invoice> i = invoice.findById(invoiceId);
		if (i.isEmpty())
			throw new BusinessException("No existe");
		for (String s : charges.keySet()) {
			PaymentMean p1 = p.findById(s).get();
			p1.pay(charges.get(s));
		}
		return null;
	}
}
