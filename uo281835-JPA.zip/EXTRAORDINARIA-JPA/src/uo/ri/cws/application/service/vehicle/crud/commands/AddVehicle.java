package uo.ri.cws.application.service.vehicle.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.application.repository.VehicleRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.vehicle.VehicleCrudService.VehicleDto;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Client;
import uo.ri.cws.domain.Vehicle;
import uo.ri.util.assertion.ArgumentChecks;

public class AddVehicle implements Command<Void> {

	private VehicleDto dto;
	private VehicleRepository repo = Factory.repository.forVehicle();
	private ClientRepository repo2 = Factory.repository.forClient();
	public AddVehicle(VehicleDto dto) {
		ArgumentChecks.isNotNull(dto);
		this.dto = dto;
	}

	@Override
	public Void execute() throws BusinessException {
			Optional<Client> c = repo2.findByDni(dto.clientId);

			if(c.isEmpty())
				throw new BusinessException("Ese cliente no existe");
			else {
				Vehicle v = new Vehicle(dto.plate,dto.model, dto.make);
				Client c1 = c.get();
				c1.addVehicle(v);
				repo.add(v);
			}
		return null;
	}

}
