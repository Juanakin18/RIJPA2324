package uo.ri.cws.application.service.paymentmean.crud.commands;

import java.util.ArrayList;
import java.util.List;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.paymentmean.PaymentMeanCrudService.PaymentMeanDto;
import uo.ri.cws.application.util.DtoAssembler;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.PaymentMean;
import uo.ri.util.assertion.ArgumentChecks;

public class FindPaymentMeansByClientId
		implements Command<List<PaymentMeanDto>> {

	private PaymentMeanRepository rep = Factory.repository.forPaymentMean();
	private String id;

	public FindPaymentMeansByClientId(String id) {
		ArgumentChecks.isNotEmpty(id);
		this.id = id;
	}

	@Override
	public List<PaymentMeanDto> execute() throws BusinessException {
		List<PaymentMean> pm = rep.findPaymentMeansByClientId(id);

		List<PaymentMeanDto> dtos = new ArrayList<>();
		for (PaymentMean m : pm) {
			dtos.add(DtoAssembler.toDto(m));
		}
		return dtos;
	}

}
