package uo.ri.cws.application.service.vehicletype.crud;

import java.util.List;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.vehicletype.VehicleTypeCrudService;
import uo.ri.cws.application.service.vehicletype.crud.commands.AddVehicleType;
import uo.ri.cws.application.service.vehicletype.crud.commands.DeleteVehicleType;
import uo.ri.cws.application.service.vehicletype.crud.commands.FindAllVehicleType;
import uo.ri.cws.application.service.vehicletype.crud.commands.FindVHId;
import uo.ri.cws.application.service.vehicletype.crud.commands.UpdateVH;
import uo.ri.cws.application.util.command.CommandExecutor;

public class VehicleTypeServiceImpl implements VehicleTypeCrudService {

	private CommandExecutor exe = Factory.executor.forExecutor();

	@Override
	public void addVehicleType(VehicleTypeDto dto) throws BusinessException {
		exe.execute(new AddVehicleType(dto));

	}

	@Override
	public void deleteVehicleType(String dni) throws BusinessException {
		exe.execute(new DeleteVehicleType(dni));

	}

	@Override
	public Optional<VehicleTypeDto> findById(String dni) throws BusinessException {
		return exe.execute(new FindVHId(dni));

	}

	@Override
	public void update(VehicleTypeDto dto) throws BusinessException {
		exe.execute(new UpdateVH(dto));

	}

	@Override
	public List<VehicleTypeDto> findAll() throws BusinessException{
		return exe.execute(new FindAllVehicleType());
	}

}
