package uo.ri.cws.application.service.sparepart;

import java.util.List;
import java.util.Optional;

import uo.ri.cws.application.service.BusinessException;

/**
 * This service is intended to be used by the Mechanic It follows the ISP
 * principle (@see SOLID principles from RC Martin)
 */
public interface SparePartCrudService {

	void addSparePart(SparePartDto dto) throws BusinessException;

	void deleteSparePart(String dni) throws BusinessException;

	void updateSparePart(SparePartDto dto) throws BusinessException;

	List<SparePartDto> findAll() throws BusinessException;

	Optional<SparePartDto> findByCodigo(String nombre) throws BusinessException;

	Optional<SparePartDto> findByModel(String nombre) throws BusinessException;

	Optional<SparePartDto> findByMarca(String nombre) throws BusinessException;

	Optional<SparePartDto> findByDescription(String nombre) throws BusinessException;

}
