package uo.ri.cws.application.service.client;

public interface ClientHistoryService {

}
