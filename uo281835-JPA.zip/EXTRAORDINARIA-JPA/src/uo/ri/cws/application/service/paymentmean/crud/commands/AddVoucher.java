package uo.ri.cws.application.service.paymentmean.crud.commands;

import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.repository.PaymentMeanRepository;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.paymentmean.PaymentMeanCrudService.VoucherDto;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.domain.Voucher;
import uo.ri.util.assertion.ArgumentChecks;

public class AddVoucher implements Command<VoucherDto> {

	private PaymentMeanRepository rep = Factory.repository.forPaymentMean();

	private VoucherDto dto;

	public AddVoucher(VoucherDto voucher) {
		ArgumentChecks.isNotNull(voucher);
		this.dto = voucher;
	}

	@Override
	public VoucherDto execute() throws BusinessException {
		Optional<Voucher> a = rep.findVoucherByCode(dto.code);
		if (!a.isEmpty())
			throw new BusinessException("Ese bono ya existe");
		Voucher c = new Voucher(dto.code, dto.accumulated);
		rep.add(c);
		return null;
	}

}
