package uo.ri.cws.application;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.util.command.Command;
import uo.ri.cws.application.util.command.CommandExecutor;
import uo.ri.cws.infrastructure.persistence.jpa.util.Jpa;

public class Executor implements CommandExecutor {

	@Override
	public <T> T execute(Command<T> cmd) throws BusinessException {
		EntityManager em = Jpa.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		T returnValue ;
		try {
			returnValue = cmd.execute();
		}catch(Exception e) {
			if(tx.isActive())
				tx.rollback();
			throw e;
		
		}finally {
			em.close();
		
		}
		tx.commit();
		return returnValue;
	}

}
