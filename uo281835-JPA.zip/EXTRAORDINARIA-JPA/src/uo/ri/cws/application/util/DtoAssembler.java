package uo.ri.cws.application.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import uo.ri.cws.application.service.client.ClientCrudService.ClientDto;
import uo.ri.cws.application.service.contract.ContractService.ContractDto;
import uo.ri.cws.application.service.contracttype.ContractTypeService.ContractTypeDto;
import uo.ri.cws.application.service.invoice.InvoicingService.InvoiceDto;
import uo.ri.cws.application.service.invoice.InvoicingService.InvoicingWorkOrderDto;
import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;
import uo.ri.cws.application.service.paymentmean.PaymentMeanCrudService.CardDto;
import uo.ri.cws.application.service.paymentmean.PaymentMeanCrudService.CashDto;
import uo.ri.cws.application.service.paymentmean.PaymentMeanCrudService.PaymentMeanDto;
import uo.ri.cws.application.service.paymentmean.VoucherService.VoucherDto;
import uo.ri.cws.application.service.paymentmean.VoucherService.VoucherSummaryDto;
import uo.ri.cws.application.service.payroll.PayrollService.PayrollBLDto;
import uo.ri.cws.application.service.payroll.PayrollService.PayrollSummaryBLDto;
import uo.ri.cws.application.service.professionalgroup.ProfessionalGroupService.ProfessionalGroupBLDto;
import uo.ri.cws.application.service.sparepart.SparePartDto;
import uo.ri.cws.application.service.vehicle.VehicleCrudService.VehicleDto;
import uo.ri.cws.application.service.vehicletype.VehicleTypeCrudService.VehicleTypeDto;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService.WorkOrderDto;
import uo.ri.cws.domain.Cash;
import uo.ri.cws.domain.Client;
import uo.ri.cws.domain.Contract;
import uo.ri.cws.domain.ContractType;
import uo.ri.cws.domain.CreditCard;
import uo.ri.cws.domain.Invoice;
import uo.ri.cws.domain.Mechanic;
import uo.ri.cws.domain.PaymentMean;
import uo.ri.cws.domain.Payroll;
import uo.ri.cws.domain.ProfessionalGroup;
import uo.ri.cws.domain.SparePart;
import uo.ri.cws.domain.Vehicle;
import uo.ri.cws.domain.VehicleType;
import uo.ri.cws.domain.Voucher;
import uo.ri.cws.domain.WorkOrder;

public class DtoAssembler {

	public static ClientDto toDto(Client c) {
		ClientDto dto = new ClientDto();

		dto.id = c.getId();
		dto.version = c.getVersion(); 

		dto.dni = c.getDni();
		dto.name = c.getName();
		dto.surname = c.getSurname();

		return dto;
	}

	public static List<ClientDto> toClientDtoList(List<Client> clientes) {
		List<ClientDto> res = new ArrayList<>();
		for (Client c : clientes) {
			res.add(DtoAssembler.toDto(c));
		}
		return res;
	}

	public static MechanicDto toDto(Mechanic m) {
		MechanicDto dto = new MechanicDto();
		dto.id = m.getId();
		dto.version = m.getVersion();

		dto.dni = m.getDni();
		dto.name = m.getName();
		dto.surname = m.getSurname();
		return dto;
	}

	public static List<MechanicDto> toMechanicDtoList(List<Mechanic> list) {
		List<MechanicDto> res = new ArrayList<>();
		for (Mechanic m : list) {
			res.add(toDto(m));
		}
		return res;
	}

	public static List<VoucherDto> toVoucherDtoList(List<Voucher> list) {
		List<VoucherDto> res = new ArrayList<>();
		for (Voucher b : list) {
			res.add(toDto(b));
		}
		return res;
	}

	public static VoucherDto toDto(Voucher v) {
		VoucherDto dto = new VoucherDto();
		dto.id = v.getId();
		dto.version = v.getVersion();

		dto.clientId = v.getClient().getId();
		dto.accumulated = v.getAccumulated();
		dto.code = v.getCode();
		dto.description = v.getDescription();
		dto.available = v.getAvailable();
		return dto;
	}

	public static CardDto toDto(CreditCard cc) {
		CardDto dto = new CardDto();
		dto.id = cc.getId();
		dto.version = cc.getVersion();

		dto.clientId = cc.getClient().getId();
		dto.accumulated = cc.getAccumulated();
		dto.cardNumber = cc.getNumber();
		dto.cardExpiration = cc.getValidThru();
		dto.cardType = cc.getType();
		return dto;
	}

	public static CashDto toDto(Cash m) {
		CashDto dto = new CashDto();
		dto.id = m.getId();
		dto.version = m.getVersion();

		dto.clientId = m.getClient().getId();
		dto.accumulated = m.getAccumulated();
		return dto;
	}

	public static InvoiceDto toDto(Invoice invoice) {
		InvoiceDto dto = new InvoiceDto();
		dto.id = invoice.getId();
		dto.version = invoice.getVersion();

		dto.number = invoice.getNumber();
		dto.date = invoice.getDate();
		dto.total = invoice.getAmount();
		dto.vat = invoice.getVat();
		dto.state = invoice.getStatus().toString();
		return dto;
	}

	public static List<PaymentMeanDto> toPaymentMeanDtoList(
			List<PaymentMean> list) {
		return list.stream().map(mp -> toDto(mp)).collect(Collectors.toList());
	}

	public static PaymentMeanDto toDto(PaymentMean mp) {
		if (mp instanceof Voucher) {
			return toDto((Voucher) mp);
		} else if (mp instanceof CreditCard) {
			return toDto((CreditCard) mp);
		} else if (mp instanceof Cash) {
			return toDto((Cash) mp);
		} else {
			throw new RuntimeException("Unexpected type of payment mean");
		}
	}

	public static WorkOrderDto toDto(WorkOrder a) {
		WorkOrderDto dto = new WorkOrderDto();
		dto.id = a.getId();
		dto.version = a.getVersion();

		dto.vehicleId = a.getVehicle().getId();
		dto.description = a.getDescription();
		dto.date = a.getDate();
		dto.total = a.getAmount();
		dto.state = a.getStatus().toString();

		dto.invoiceId = a.getInvoice() == null ? null : a.getInvoice().getId();

		return dto;
	}

	public static VehicleDto toDto(Vehicle v) {
		VehicleDto dto = new VehicleDto();
		dto.id = v.getId();
		dto.version = v.getVersion();

		dto.plate = v.getPlateNumber();
		dto.clientId = v.getClient().getId();
		dto.make = v.getMake();
		dto.vehicleTypeId = v.getVehicleType().getId();
		dto.model = v.getModel();

		return dto;
	}

	public static List<WorkOrderDto> toWorkOrderDtoList(List<WorkOrder> list) {
		return list.stream().map(a -> toDto(a)).collect(Collectors.toList());
	}

	public static VehicleTypeDto toDto(VehicleType vt) {
		VehicleTypeDto dto = new VehicleTypeDto();

		dto.id = vt.getId();
		dto.version = vt.getVersion();

		dto.name = vt.getName();
		dto.pricePerHour = vt.getPricePerHour();

		return dto;
	}

	public static List<VehicleTypeDto> toVehicleTypeDtoList(
			List<VehicleType> list) {
		return list.stream().map(a -> toDto(a)).collect(Collectors.toList());
	}

	public static InvoicingWorkOrderDto toInvoicingDto(WorkOrder a) {
		InvoicingWorkOrderDto dto = new InvoicingWorkOrderDto();
		dto.id = a.getId();

		dto.description = a.getDescription();
		dto.date = a.getDate();
		dto.total = a.getAmount();
		dto.state = a.getStatus().toString();

		return dto;
	}

	public static List<InvoicingWorkOrderDto> toInvoicingWorkOrderDtoList(
			List<WorkOrder> list) {
		return list	.stream()
					.map(a -> toInvoicingDto(a))
					.collect(Collectors.toList());
	}

	public static List<InvoicingWorkOrderDto> toWorkOrderForInvoicingDtoList(
			List<WorkOrder> list) {
		List<InvoicingWorkOrderDto> result = new ArrayList<InvoicingWorkOrderDto>();
		for (WorkOrder w : list)
			result.add(toInvoicingDto(w));
		return result;
	}

	public static List<ContractDto> toContractDtoList(
			List<Contract> findTerminated) {
		List<ContractDto> dtos = new ArrayList<ContractDto>();

		for (Contract c : findTerminated) {
			ContractDto dto = toDto(c);new ContractDto();
			dto.id = c.getId();
			dto.version = c.getVersion();
			dto.contractTypeName = c.getContractType().getName();
			dto.professionalGroupName = c.getProfessionalGroup().getName();
			dto.startDate = c.getStartDate();
			if (c.getEndDate().isPresent())
				dto.endDate = c.getEndDate().get();
			else
				dto.endDate = null;
			dto.annualBaseWage = c.getAnnualBaseWage();
			dto.settlement = c.getSettlement();
			dto.state = c.getState();
			dtos.add(dto);

		}
		return dtos;
	}

	public static ContractTypeDto toDto(ContractType contractType) {
		ContractTypeDto dto = new ContractTypeDto();
		dto.id = contractType.getId();
		dto.version = contractType.getVersion();
		dto.name = contractType.getName();
		dto.compensationDays = contractType.getCompensationDays();
		return dto;
	}

	public static List<ContractTypeDto> toCTDtoList(
			List<ContractType> findAll) {
		List<ContractTypeDto> dtos = new ArrayList<ContractTypeDto>();
		for (ContractType c : findAll) {
			dtos.add(toDto(c));
		}

		return dtos;
	}

	public static PayrollSummaryBLDto toPayrollSummaryDto(Payroll dto) {
		PayrollSummaryBLDto dto1 = new PayrollSummaryBLDto();
		dto1.id = dto.getId();
		dto1.version = dto.getVersion();
		dto1.date = dto.getDate();
		dto1.netWage = dto.calculateNetWage();
		return dto1;
	}

	public static Optional<PayrollBLDto> toPayRollDto(
			Optional<Payroll> checkExists) {
		if (checkExists.isPresent()) {
			PayrollBLDto dto1 = new PayrollBLDto();
			Payroll dto = checkExists.get();
			dto1.id = dto.getId();
			dto1.version = dto.getVersion();
			dto1.date = dto.getDate();
			dto1.netWage = dto.calculateNetWage();
			dto1.contractId = dto.getContract().getId();
			dto1.monthlyWage = dto.getMonthlyWage();
			dto1.bonus = dto.getBonus();
			dto1.productivityBonus = dto.getProductivityBonus();
			dto1.trienniumPayment = dto.getTrienniumPayment();
			dto1.incomeTax = dto.getIncomeTax();
			dto1.nic = dto.getNIC();
			return Optional.of(dto1);
		}
		return Optional.empty();
	}

	public static ContractDto toDto(Contract c) {
		ContractDto dto = new ContractDto();
		dto.id = c.getId();
		dto.version = c.getVersion();
		dto.contractTypeName = c.getContractType().getName();
		dto.professionalGroupName = c.getProfessionalGroup().getName();
		dto.startDate = c.getStartDate();
		if (c.getEndDate().isPresent())
			dto.endDate = c.getEndDate().get();
		else
			dto.endDate = null;
		dto.annualBaseWage = c.getAnnualBaseWage();
		dto.settlement = c.getSettlement();
		dto.state = c.getState();
		return dto;
	}

	public static ProfessionalGroupBLDto toDto(ProfessionalGroup p) {

		ProfessionalGroupBLDto dto = new ProfessionalGroupBLDto();
		dto.name = p.getName();
		dto.version = p.getVersion();
		dto.id = p.getId();
		dto.productivityRate = p.getProductivityBonusPercentage();
		dto.trieniumSalary = p.getTrienniumPayment();
		return dto;
	}

	public static List<ProfessionalGroupBLDto> toProfessionalGroupList(List<ProfessionalGroup> findAll) {
		List<ProfessionalGroupBLDto> dtos = new ArrayList<ProfessionalGroupBLDto>();
		for(ProfessionalGroup d : findAll) {
			dtos.add(toDto(d));
		}
		return dtos;
	}

	public static List<SparePartDto> toSparePartDtoList(List<SparePart> findAll) {
		List<SparePartDto> dtos = new ArrayList<SparePartDto>();
		for(SparePart d : findAll) {
			dtos.add(toDto(d));
		}
		return dtos;
	}

	public static SparePartDto toDto(SparePart d) {
		SparePartDto dto = new SparePartDto();
		dto.id = d.getId();
		dto.code = d.getCode();
		dto.description = d.getDescription();
		dto.price = d.getPrice();
		dto.version = d.getVersion();
		return dto;
	}

	public static List<VehicleDto> toDtoList(List<Vehicle> findByClient) {
		List<VehicleDto> dtos = new ArrayList<VehicleDto>();
		for(Vehicle d : findByClient) {
			dtos.add(toDto(d));
		}
		return dtos;
	}

	public static VoucherSummaryDto toVoucherSummaryDtoList(
			Object[] findAggregateVoucherDataByClientId) {
		VoucherSummaryDto dto = new VoucherSummaryDto();
		dto.issued = (Integer)findAggregateVoucherDataByClientId[0];
		dto.availableBalance = (Double)findAggregateVoucherDataByClientId[1];
		dto.consumed = (Double)findAggregateVoucherDataByClientId[2];
		return dto;
	}

}
