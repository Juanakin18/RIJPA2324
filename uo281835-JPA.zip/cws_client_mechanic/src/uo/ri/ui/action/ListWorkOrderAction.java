package uo.ri.ui.action;

import uo.ri.conf.Factory;
import uo.ri.ui.util.Printer;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class ListWorkOrderAction implements Action {

	@Override
	public void execute() throws Exception {
		Printer.printWorkOrders(
				Factory.service.forViewAssignedWorkOrdersService().findByDni(
						Console.readString("Introduzca su dni")));
		
	}

}
