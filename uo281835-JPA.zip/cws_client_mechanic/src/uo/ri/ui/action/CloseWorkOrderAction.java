package uo.ri.ui.action;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.workorder.CloseWorkOrderService;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class CloseWorkOrderAction implements Action {

	@Override
	public void execute() throws Exception {
		String id = Console.readString("Introduzca el id");
		CloseWorkOrderService service = Factory.service.forClosingBreakdown();
		service.close(id);
	}

}
