package uo.ri.ui.action;

import java.time.LocalDateTime;
import java.util.Optional;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.BusinessException;
import uo.ri.cws.application.service.intervention.InterventionService;
import uo.ri.cws.application.service.intervention.SubstitutionDto;
import uo.ri.cws.application.service.intervention.InterventionService.InterventionDto;
import uo.ri.cws.application.service.sparepart.SparePartCrudService;
import uo.ri.cws.application.service.sparepart.SparePartDto;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class AddSparePartToRepairAction implements Action {

	@Override
	public void execute() throws Exception {
		InterventionService service = Factory.service.forIntervention();
		WorkOrderCrudService ws = Factory.service.forWorkOrderCrudService();
		String dni = Console.readString("Introduzca el dni");
		String workOrderId = Console.readString("Introduzca el id de la workorder");
		int minutes = Console.readInt("Introduzca la duraci�n");
		
		
		SparePartDto dto = null;
		if(Console.readString("�Quiere buscar por descripci�n?").equalsIgnoreCase("Si")) {
			String nombre = Console.readString("Introduzca la descripci�n");
			dto = buscarPorDescripcion(nombre);
		}else if(Console.readString("�Quiere buscar por marca?").equalsIgnoreCase("Si")) {
			String nombre = Console.readString("Introduzca la marca");
			dto =buscarPorMarca(nombre);
		}else if(Console.readString("�Quiere buscar por modelo?").equalsIgnoreCase("Si")) {
			String nombre = Console.readString("Introduzca el modelo");
			dto =buscarPorModelo(nombre);
		}else if(Console.readString("�Quiere buscar por c�digo?").equalsIgnoreCase("Si")) {
			String nombre = Console.readString("Introduzca el c�digo");
			dto =buscarPorCodigo(nombre);
		}
		int cantidad = Console.readInt("Introduzca la duraci�n");
		InterventionDto idto = new InterventionDto();
		idto.date = LocalDateTime.now();
		idto.mechanicId = dni;
		idto.workorderId=workOrderId;
		idto.minutes = minutes;
		service.addIntervention(idto);
		SubstitutionDto sub = new SubstitutionDto();
		sub.cantidad= cantidad;
		sub.sparePartId = dto.id;
		service.addSubstitutionToIntervention(sub,idto);
		ws.addInterventionToAWorkOrder(workOrderId, idto);
		
	}

	

	private SparePartDto buscarPorCodigo(String nombre) throws BusinessException {
		SparePartCrudService service = Factory.service.forSparePartCrudService();
		Optional<SparePartDto> dtos1 =(service.findByCodigo(nombre));
		if(dtos1.isPresent())
			return dtos1.get();
		else
			return null;
	}



	private SparePartDto buscarPorModelo(String nombre) throws BusinessException {
		SparePartCrudService service = Factory.service.forSparePartCrudService();
		Optional<SparePartDto> dtos1 =(service.findByModel(nombre));
		if(dtos1.isPresent())
			return dtos1.get();
		else
			return null;
	}



	private SparePartDto buscarPorMarca(String nombre) throws BusinessException {
		SparePartCrudService service = Factory.service.forSparePartCrudService();
		Optional<SparePartDto> dtos1 =(service.findByMarca(nombre));
		if(dtos1.isPresent())
			return dtos1.get();
		else
			return null;
	}



	private SparePartDto buscarPorDescripcion(String nombre) throws BusinessException {
		SparePartCrudService service = Factory.service.forSparePartCrudService();
		Optional<SparePartDto> dtos1 =(service.findByDescription(nombre));
		if(dtos1.isPresent())
			return dtos1.get();
		else
			return null;
	}


}
