package uo.ri.ui.action;

import uo.ri.util.menu.Action;

public class DeleteSparePartFromRepairAction implements Action {

	@Override
	public void execute() throws Exception {
		// TODO Auto-generated method stub

	}

}
