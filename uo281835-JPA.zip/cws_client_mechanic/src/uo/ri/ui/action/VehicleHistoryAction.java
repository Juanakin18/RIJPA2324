package uo.ri.ui.action;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.vehicle.VehicleCrudService;
import uo.ri.cws.application.service.vehicle.VehicleCrudService.VehicleDto;
import uo.ri.cws.application.service.workorder.WorkOrderCrudService;
import uo.ri.ui.util.Printer;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class VehicleHistoryAction implements Action {

	@Override
	public void execute() throws Exception {
		VehicleCrudService service = Factory.service.forVehicleCrudService();
		WorkOrderCrudService ws = Factory.service.forWorkOrderCrudService();
		String plate = Console.readString("Introduzca la matricula");
		VehicleDto v = service.findVehicleByPlate(plate).get();
		Printer.printWorkOrders(ws.findWorkordersByVehicle(v.id));
		
	}

	

}
