package uo.ri.ui;

import uo.ri.ui.action.AddInterventionToAWorkOrder;
import uo.ri.ui.action.AddSparePartToRepairAction;
import uo.ri.ui.action.CloseWorkOrderAction;
import uo.ri.ui.action.DeleteSparePartFromRepairAction;
import uo.ri.ui.action.ListWorkOrderAction;
import uo.ri.ui.action.VehicleHistoryAction;
import uo.ri.ui.action.WorkOrderDetailsAction;
import uo.ri.util.console.DefaultPrinter;
import uo.ri.util.menu.BaseMenu;

public class MechanicMain {

	private static class MainMenu extends BaseMenu {
		MainMenu() {
			menuOptions = new Object[][] { 
				{ "Mechanic", null },
				{ "List assigned work orders", 		ListWorkOrderAction.class }, 
				{ "Add Intervention to a workorder", 		AddInterventionToAWorkOrder.class }, 
				{ "Add parts to work order", 		AddSparePartToRepairAction.class },
				{ "Workorder details", 		WorkOrderDetailsAction.class },
				{ "Vehicle history", 		VehicleHistoryAction.class },
				{ "Remove parts from work order", 	DeleteSparePartFromRepairAction.class },
				{ "Close a work order", 			CloseWorkOrderAction.class },
			};
		}
	}

	private MainMenu menu = new MainMenu();
	
	public static void main(String[] args) {
		new MechanicMain()
			.config()
			.run()
			.close();
	}

	private MechanicMain config() {
		return this;
	}

	public MechanicMain run() {
		try {
			menu.execute();

		} catch (RuntimeException rte) {
			DefaultPrinter.printRuntimeException(rte);
		}
		return this;
	}

	private void close() {
	}

}
