package uo.ri.ui.cashier.action;

import java.util.HashMap;
import java.util.Map;

import uo.ri.conf.Factory;
import uo.ri.cws.application.service.invoice.InvoicingService.CardDto;
import uo.ri.cws.application.service.invoice.InvoicingService.CashDto;
import uo.ri.cws.application.service.invoice.InvoicingService.InvoiceDto;
import uo.ri.cws.application.service.invoice.InvoicingService.VoucherDto;
import uo.ri.cws.domain.Invoice.InvoiceState;
import uo.ri.ui.util.Printer;
import uo.ri.util.console.Console;
import uo.ri.util.menu.Action;

public class LiquidateInvoiceAction implements Action {

	@Override
	public void execute() throws Exception {
		Long invoice = Console.readLong("Invoice number");
		InvoiceDto dto = Factory.service.forCreateInvoiceService()
										.findInvoice(invoice)
										.get();
		Printer.printInvoice(dto);
		if (dto.state == InvoiceState.NOT_YET_PAID.toString()) {
			Console.println("You can pay with cash, vouchers and credit card");
			double total = 0;
			double cash = 0;
			double vouchers = 0;
			double credit = 0;
			while (Math.round(total - dto.total * 100.0) / 100.0 != 0) {
				total = 0;
				cash = Console.readDouble("cash");
				total += cash;
				vouchers = Console.readDouble("vouchers");
				total += vouchers;
				credit = Console.readDouble("credit");
				total += credit;
			}
			Map<String, Double> dtos = new HashMap<String, Double>();
			if (cash > 0) {
				CashDto dto1 = new CashDto();
				dto1.accumulated = cash;
				dtos.put(dto1.id, dto.total);
			}
			if (vouchers > 0) {
				VoucherDto dto2 = new VoucherDto();
				dto2.accumulated = vouchers;
				dtos.put(dto2.id, dto.total);

			}
			if (credit > 0) {
				CardDto dto3 = new CardDto();
				dto3.accumulated = credit;
				dtos.put(dto3.id, dto.total);
			}
			Factory.service	.forCreateInvoiceService()
							.settleInvoice(dto.id, dtos);

		}

	}
}
