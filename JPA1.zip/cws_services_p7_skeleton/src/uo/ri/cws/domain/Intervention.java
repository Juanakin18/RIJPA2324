package uo.ri.cws.domain;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Entity;

import uo.ri.util.assertion.ArgumentChecks;

@Entity

public class Intervention {
	// natural attributes
	private LocalDateTime date;
	private int minutes;

	public LocalDateTime getDate() {
		return date;
	}

	public int getMinutes() {
		return minutes;
	}

	// accidental attributes
	private WorkOrder workOrder;
	private Mechanic mechanic;
	private Set<Substitution> substitutions = new HashSet<>();

	public Intervention(Mechanic mechanic2, WorkOrder workOrder2, int minutes) {
		this(workOrder2, mechanic2, LocalDateTime.now(), minutes);
	}

	public Intervention(WorkOrder workOrder, Mechanic mechanic,
			LocalDateTime date, int minute) {
		super();
		ArgumentChecks.isNotNull(mechanic);
		ArgumentChecks.isNotNull(date);
		ArgumentChecks.isNotNull(workOrder);
		ArgumentChecks.isTrue(minute >= 0);
		this.date = date.truncatedTo(ChronoUnit.MILLIS);
		this.minutes = minute;

		Associations.Intervene.link(workOrder, this, mechanic);
	}



	@Override
	public int hashCode() {
		return Objects.hash(mechanic, workOrder);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Intervention other = (Intervention) obj;
		return Objects.equals(mechanic, other.mechanic)
				&& Objects.equals(workOrder, other.workOrder);
	}

	public WorkOrder getWorkOrder() {
		return workOrder;
	}

	public Mechanic getMechanic() {
		return mechanic;
	}

	void _setWorkOrder(WorkOrder workOrder) {
		this.workOrder = workOrder;
	}

	void _setMechanic(Mechanic mechanic) {
		this.mechanic = mechanic;
	}

	public Set<Substitution> getSubstitutions() {
		return new HashSet<>( substitutions );
	}

	Set<Substitution> _getSubstitutions() {
		return substitutions;
	}

}
