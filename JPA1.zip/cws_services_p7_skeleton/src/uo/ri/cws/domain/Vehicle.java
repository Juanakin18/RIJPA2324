package uo.ri.cws.domain;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table
public class Vehicle {

	@Column(unique = true)
	private String plateNumber;
	private String make;
	private String model;

	@ManyToOne
	private Client client;
	@ManyToOne
	private VehicleType type;

	@OneToMany
	private Set<WorkOrder> workOrders = new HashSet<>();

	@Transient
	public Set<WorkOrder> getWorkOrders() {
		return new HashSet<>(workOrders);
	}

	Set<WorkOrder> _getWorkOrders() {
		return workOrders;
	}
	public Vehicle(String plateNumber) {
		this(plateNumber, "no", "no");
	}

	public Vehicle(String plateNumber, String make, String model) {
		super();
		ArgumentChecks.isNotBlank(plateNumber);
		ArgumentChecks.isNotBlank(make);
		ArgumentChecks.isNotBlank(model);
		this.plateNumber = plateNumber;
		this.make = make;
		this.model = model;
	}

	public Client getClient() {
		return client;
	}

	public void _setClient(Client client) {
		this.client = client;
	}

	@Override
	public String toString() {
		return "Vehicle [plateNumber=" + plateNumber + ", make=" + make
				+ ", model=" + model + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(plateNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vehicle other = (Vehicle) obj;
		return Objects.equals(plateNumber, other.plateNumber);
	}

	public String getPlateNumber() {
		return plateNumber;
	}

	public String getMake() {
		return make;
	}

	public String getModel() {
		return model;
	}

	public VehicleType getType() {
		return type;
	}

	void _setType(VehicleType type) {
		this.type = type;
	}

	public VehicleType getVehicleType() {
		return getType();
	}

}
