package uo.ri.cws.domain;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import uo.ri.util.assertion.ArgumentChecks;

@Entity
@Table
public class Mechanic {
	// natural attributes

	private String dni;
	private String surname;
	private String name;

	// accidental attributes
	@Transient
	private Set<WorkOrder> assigned = new HashSet<>();
	@Transient
	private Set<Intervention> interventions = new HashSet<>();

	public Set<WorkOrder> getAssigned() {
		return new HashSet<>( assigned );
	}

	Set<WorkOrder> _getAssigned() {
		return assigned;
	}

	public Mechanic(String dni) {
		this(dni, "no", "no");
	}

	public String getDni() {
		return dni;
	}

	public String getSurname() {
		return surname;
	}

	public String getName() {
		return name;
	}

	public Mechanic(String dni, String surname, String name) {
		super();
		ArgumentChecks.isNotBlank(name);
		ArgumentChecks.isNotBlank(surname);
		ArgumentChecks.isNotBlank(dni);
		this.dni = dni;
		this.surname = surname;
		this.name = name;
	}

	@Override
	public int hashCode() {
		return Objects.hash(dni);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Mechanic other = (Mechanic) obj;
		return Objects.equals(dni, other.dni);
	}

	public Set<Intervention> getInterventions() {
		return new HashSet<>( interventions );
	}

	Set<Intervention> _getInterventions() {
		return interventions;
	}

	@Override
	public String toString() {
		return "Mechanic [dni=" + dni + ", surname=" + surname + ", name="
				+ name + ", assigned=" + assigned + ", interventions="
				+ interventions + "]";
	}

}
