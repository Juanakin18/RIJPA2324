package uo.ri.cws.domain;

public class Cash extends PaymentMean {


	public Cash(Client client) {
		super();
		Associations.Pay.link(client, this);

	}


}
