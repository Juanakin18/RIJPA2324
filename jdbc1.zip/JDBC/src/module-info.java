module JDBC {
	requires java.sql;
	requires c3p0;
}