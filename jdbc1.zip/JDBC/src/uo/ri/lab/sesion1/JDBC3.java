package uo.ri.lab.sesion1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JDBC3 {
	
	private static final String DB_URL = "jdbc:hsqldb:hsql://localhost";
	private static final String USER = "sa";
	private static final String PASS = "";
	
	public void comparar() {
		comparar1();
		comparar2();
	}
	public void comparar1() {
		long tiempo1 = System.currentTimeMillis();
		for(int i =0; i<100; i++) {
			Connection c = null;
			try {
				try {
					c = DriverManager.getConnection(DB_URL, USER,PASS);
					executePreparedStatement(c);
				}finally {
					if (c!=null)
						c.close();
					
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} 
		}
		long tiempoF1 = System.currentTimeMillis();
		System.out.println("PreparedStatement ha tardado"+(tiempoF1-tiempo1));

		
	}
	public void comparar2() {
		long tiempo1 = System.currentTimeMillis();
		Connection c = null;
		try {
			try {
				c = DriverManager.getConnection(DB_URL, USER,PASS);
				for(int i =0; i<100; i++) {
					executePreparedStatement(c);
				}
				
			}finally {
				if (c!=null)
					c.close();
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		
		long tiempoF1 = System.currentTimeMillis();
		System.out.println("PreparedStatement ha tardado"+(tiempoF1-tiempo1));
	}
	
	private void executePreparedStatement(Connection c) {
		
		PreparedStatement ps=null;
		try {
			try {
				ps = c.prepareStatement("Select count(*) from TVehicles");
				ps.execute();
				}finally {
				if(ps!=null)
					ps.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}
