package uo.ri.lab.sesion1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.DataSources;

public class JDBC2 {
	
	private static final String DB_URL = "jdbc:hsqldb:hsql://localhost";
	private static final String USER = "sa";
	private static final String PASS = "";
	DataSource ds_pooled;
	
	public void comparar() {
		comparar1();
		comparar2();
	}
	public void comparar1() {
		long tiempo1 = System.currentTimeMillis();
		for(int i =0; i<100; i++) {
			Connection c = null;
			try {
				try {
					c = DriverManager.getConnection(DB_URL, USER,PASS);
					executePreparedStatement(c);
				}finally {
					if (c!=null)
						c.close();
					
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} 
		}
		long tiempoF1 = System.currentTimeMillis();
		System.out.println("Sin pool ha tardado"+(tiempoF1-tiempo1));

		
	}
	public void comparar2() {
		long tiempo1 = System.currentTimeMillis();
		//ya est� inicializado 
		//Para obtener conexi�n 
		
			
		Connection c = null;
			try {
				try {
					DataSource ds_unpooled = DataSources.unpooledDataSource(DB_URL, USER, PASS); 
					Map overrides = new HashMap(); 
					overrides.put("minPoolSize", 3);
					overrides.put("maxPoolSize", 50);
					overrides.put("initialPoolSize", 3); 
					ds_pooled = DataSources.pooledDataSource(ds_unpooled, overrides ); 
					
					c = ds_pooled.getConnection();
					executePreparedStatement(c);
				}finally {
					if (c!=null)
						c.close();
					
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} 
		
		long tiempoF1 = System.currentTimeMillis();
		System.out.println("Con pool ha tardado"+(tiempoF1-tiempo1));

		
	}

	private void executePreparedStatement(Connection c) {
		
		PreparedStatement ps=null;
		try {
			try {
				ps = c.prepareStatement("Select count(*) from TVehicles");
				ps.execute();
				}finally {
				if(ps!=null)
					ps.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}
