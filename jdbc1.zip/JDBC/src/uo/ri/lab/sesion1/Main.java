package uo.ri.lab.sesion1;

public class Main {

	public static void main(String[] args) {
		JDBC jdbc = new JDBC();
		jdbc.comparar();
		JDBC2 jdbc2 = new JDBC2();
		jdbc2.comparar();
		JDBC3 jdbc3 = new JDBC3();
		jdbc3.comparar();
	}

}
