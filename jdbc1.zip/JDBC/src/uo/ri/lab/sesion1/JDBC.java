package uo.ri.lab.sesion1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBC {
	
	private static final String DB_URL = "jdbc:hsqldb:hsql://localhost";
	private static final String USER = "sa";
	private static final String PASS = "";
	
	public void comparar() {
		Connection c = null;
		try {
			try {
				c = DriverManager.getConnection(DB_URL, USER,PASS);
				executeStatement(c);
				executePreparedStatement(c);
			}finally {
				if (c!=null)
					c.close();
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} 
	}
	private void executeStatement(Connection c) {
		Statement s=null;
		try {
			try {
			s = c.createStatement();
			long tiempo = System.currentTimeMillis();
			for(int i =0; i<10000; i++) {
				s.executeUpdate("Update TInvoices set amount = 12 where id = "+i);
			}
			long tiempoF = System.currentTimeMillis();
			System.out.println("Statement ha tardado"+(tiempoF-tiempo));
			}finally {
				if(s!=null) {
					s.close();
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	private void executePreparedStatement(Connection c) {
		
		PreparedStatement ps=null;
		try {
			try {
				ps = c.prepareStatement("Update TInvoices set amount = 12 where id = ?");
				long tiempo1 = System.currentTimeMillis();
				for(int i =0; i<10000; i++) {
					ps.setString(1, i+"");
					ps.execute();
				}
				long tiempoF1 = System.currentTimeMillis();
				System.out.println("PreparedStatement ha tardado"+(tiempoF1-tiempo1));
			}finally {
				if(ps!=null)
					ps.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}
